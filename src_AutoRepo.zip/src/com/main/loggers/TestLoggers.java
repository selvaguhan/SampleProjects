package com.main.loggers;

import java.io.File;


import com.base.utils.PropUtils;


public class TestLoggers {
		 
	  //private final PropUtils propUtils=null;

	  public TestLoggers(PropUtils propUtils) {
	    try {
	    	propUtils.loadPropFile(new File("Automation.properties"), propUtils);
	    } catch (Exception e) {
	      e.printStackTrace();
	    }


	  }

	
	 
	 
}
