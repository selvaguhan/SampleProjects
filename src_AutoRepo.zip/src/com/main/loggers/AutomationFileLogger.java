package com.main.loggers;

public class AutomationFileLogger {

}
