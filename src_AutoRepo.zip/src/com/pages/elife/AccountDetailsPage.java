package com.pages.elife;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.configs.WaitConfigs;
import com.base.utils.BasePage;

public class AccountDetailsPage extends BasePage{
	
	private By accountFullNameEnglish = By.id("addNewActionForm:accountFullNameEn");
	
	private By accountFullNameArabic = By.id("addNewActionForm:accountFullNameAr");
	
	private By internetUsrNmeTxt = By.id("addNewActionForm:internetUsername");
	
	private By landLineNoTxt = By.id("addNewActionForm:landLineNo");
	
	private By custEnvContactNoTxt = By.id("addNewActionForm:envcustomercontactnumber");
	
	private By custEnvContactEmaiIdTxt = By.id("addNewActionForm:envcustomercontactemail");
	
	private By userNmeEdit = By.xpath("(//TBODY[@id='addNewActionForm:serviceSpecificId_data']/TR[1]//div[contains(@id,'addNewActionForm:serviceSpecificId:0')])[position()=3]");
	
	private String webTVUsrNmeTag ="addNewActionForm:serviceSpecificId:0:webTvUserName";
	private By webTvUserNmeTxt = By.id("addNewActionForm:serviceSpecificId:0:webTvUserName");
	
	
	private By emailIdEdit = By.xpath("//TBODY[@id='addNewActionForm:serviceSpecificId_data']/TR[2]//div[contains(@id,'addNewActionForm:serviceSpecificId:1:j_idt1818')]");
	private By webTvEmailIdTxt = By.xpath("//INPUT[@id='addNewActionForm:serviceSpecificId:1:emailValue']");
	
	private By mobileNoEdit = By.xpath("//TBODY[@id='addNewActionForm:serviceSpecificId_data']/TR[3]//div[contains(@id,'addNewActionForm:serviceSpecificId:2:j_idt1818')]");
	private By webTvMobileNoEditTxt = By.xpath("//INPUT[@id='addNewActionForm:serviceSpecificId:2:mobileNumber']");
	
	private By elifeInstantAccountChk = By.xpath("//div[contains(@id,'addNewActionForm:j') and contains(@class,'ui-chkbox ui-widget')]//input[contains(@id,'addNewActionForm:') and contains(@type,'checkbox')]");
	
	private By elifeInstGsmMblNoTxt = By.id("addNewActionForm:instGsmMblNo");
	
	//addNewActionForm:j_idt1827
	private By contactPersonTxt = By.id("addNewActionForm:a11");
	
	private By contactMobilePrimaryNoTxt = By.xpath("//INPUT[@id='addNewActionForm:a22']");
	
	
	private By installationCityLbl = By.id("addNewActionForm:instCity_label");
	
	public By getSelectedInstallationCity(String installationCity) {
		By installationCityOption= By.xpath("//div[contains(@id,'addNewActionForm:instCity_panel')]//li[@data-label='"+installationCity+"'"+"]");
		return installationCityOption;
	}
	
	private By confirmOrderBtn = By.id("addNewActionForm:submitbtnIdNew");
	private By confirmOrderBtn1 = By.id("addNewActionForm:submitbtnId1");
	
	private By flatDetailsLbl = By.id("addNewActionForm:selectedFlateDetails_label");
	public By getSelectedFlatNo(String flatNo) {
		//By flatDetailsOption= By.xpath("//div[contains(@id,'addNewActionForm:selectedFlateDetails_panel')]//li[contains(@data-label,'1001')]");
		By flatDetailsOption= By.xpath("//div[contains(@id,'addNewActionForm:selectedFlateDetails_panel')]//li[@data-label='"+flatNo+"'"+"]");
		return flatDetailsOption;
	}
	
	private By agreeBtn = By.id("addNewActionForm:agbtnId");
	
	private By subReqIdPopUpTitle = By.xpath("//DIV[@id='notifications:messagesInDialog']/DIV/UL/LI/SPAN");
	
	private By popUpOkBtn = By.id("notifications:j_idt46");
	
	public By popUpOkDeleteServicesBtn = By.id("notifications:j_idt47");
	
	
	public By companyNmeEng1Txt = By.id("addNewActionForm:companyNameEn");
	
	public By companyNmeArabic1Txt = By.id("addNewActionForm:companyNameAr");
	
	public AccountDetailsPage(WebDriver  driver) {
		super(driver);
	}
	
	public AccountDetailsPage enterAccountFNEnglish(String fullNameEng) {
		getWaitUtils().elementPresence(accountFullNameEnglish, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(accountFullNameEnglish);
		safeType(accountFullNameEnglish,fullNameEng);
		clickOnElementAndTabKey(accountFullNameEnglish);
		return this;
	}
	
	public AccountDetailsPage enterAccountFNArabic(String fullNameArabic) {
		getWaitUtils().elementPresence(accountFullNameArabic, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(accountFullNameArabic);
		safeType(accountFullNameArabic,fullNameArabic);
		clickOnElementAndTabKey(accountFullNameArabic);
		return this;
	}
	
	public AccountDetailsPage enterInternetUserName(String internetUsrNme) {
		getWaitUtils().elementPresence(internetUsrNmeTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(internetUsrNmeTxt);
		safeType(internetUsrNmeTxt,internetUsrNme);
		//onChangeEventFire(internetUsrNmeTxt);
		return this;
	}
	
	public AccountDetailsPage enterLandLineNo(String landLineNo) {
		getWaitUtils().elementPresence(landLineNoTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(landLineNoTxt);
		safeType(landLineNoTxt,landLineNo);
		return this;
	}
	
	public AccountDetailsPage enterCustEnvContactNo(String envContactNo) {
		getWaitUtils().elementPresence(custEnvContactNoTxt, WaitConfigs.elementVisibleWait);
			
		String tt= getAttributeValue(custEnvContactNoTxt,"value");

		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			scrollIntoViewTillElement(custEnvContactNoTxt);
			safeType(custEnvContactNoTxt,envContactNo);
		}
		return this;
	}
	
	
	public AccountDetailsPage enterCustEnvContactEmailId(String envContactEmailId) {
		getWaitUtils().elementPresence(custEnvContactEmaiIdTxt, WaitConfigs.elementVisibleWait);
		
		String tt= getAttributeValue(custEnvContactEmaiIdTxt,"value");

		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			scrollIntoViewTillElement(custEnvContactEmaiIdTxt);
			safeType(custEnvContactEmaiIdTxt,envContactEmailId);
		}
		
		return this;
	}
	
	public AccountDetailsPage editWebTvUsrName(String webTvUsrName) {
		
		getWaitUtils().elementPresence(userNmeEdit, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(userNmeEdit);
		clickByWebElement(userNmeEdit);
				
		getWaitUtils().elementPresence(webTvUserNmeTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(webTvUserNmeTxt);
		typeValueByJavaScript(webTVUsrNmeTag,webTvUsrName);
		clickOnElementAndTabKey(webTvUserNmeTxt);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public AccountDetailsPage editWebTvEmailId(String emailId) {
		
		getWaitUtils().elementPresence(emailIdEdit, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(emailIdEdit);
		clickByWebElement(emailIdEdit);
				
		getWaitUtils().elementPresence(webTvEmailIdTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(webTvEmailIdTxt);
		safeType(webTvEmailIdTxt,emailId);
		clickOnElementAndTabKey(webTvEmailIdTxt);
		clickOnElementAndTabKey(webTvEmailIdTxt);
		return this;
	}
	
	public AccountDetailsPage editWebTvMobileNo(String mobileNo) {
		
		getWaitUtils().elementPresence(mobileNoEdit, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(mobileNoEdit);
		clickByWebElement(mobileNoEdit);
				
		getWaitUtils().elementPresence(webTvMobileNoEditTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(webTvMobileNoEditTxt);
		safeType(webTvMobileNoEditTxt,mobileNo);
		clickOnElementAndTabKey(webTvMobileNoEditTxt);
		return this;
	}
	
	public AccountDetailsPage unCheckElifeInstantAccountChk() {
		getWaitUtils().elementPresence(elifeInstantAccountChk, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(elifeInstantAccountChk);
		clickByWebElement(elifeInstantAccountChk);
		//clickOnElementAndTabKey(elifeInstantAccountChk);
		return this;
	}
	
	
	
	public AccountDetailsPage enterElifeInstGsmMblNoTxt(String mobileNo) {
		getWaitUtils().elementPresence(elifeInstGsmMblNoTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(elifeInstGsmMblNoTxt);
		safeType(elifeInstGsmMblNoTxt,mobileNo);
		clickOnElementAndTabKey(contactPersonTxt);
		return this;
	}
	
	public AccountDetailsPage enterContactPersonName(String contactPersonNme) {
		getWaitUtils().elementPresence(contactPersonTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(contactPersonTxt);
		safeType(contactPersonTxt,contactPersonNme);
		clickOnElementAndTabKey(contactPersonTxt);
		return this;
	}
	
	public AccountDetailsPage enterContactPrimaryMobileNo(String contactMobNo) {
		getWaitUtils().elementPresence(contactMobilePrimaryNoTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(contactMobilePrimaryNoTxt);
		safeType(contactMobilePrimaryNoTxt,contactMobNo);
		clickOnElementAndTabKey(contactMobilePrimaryNoTxt);
		return this;
	}
	
	public AccountDetailsPage clickOnConfirmOrder() {
		getWaitUtils().elementPresence(confirmOrderBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(confirmOrderBtn);
		clickByWebElement(confirmOrderBtn);
		return this;
	}
	
	
	public AccountDetailsPage clickOnConfirmOrder1() {
		getWaitUtils().elementPresence(confirmOrderBtn1, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(confirmOrderBtn1);
		clickByWebElement(confirmOrderBtn1);
		return this;
	}
	
	public AccountDetailsPage clickOnFlatDetailsLbl() {
		
		getWaitUtils().elementPresence(flatDetailsLbl, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(flatDetailsLbl);
		clickByWebElement(flatDetailsLbl);
		return this;
	}
	
	public AccountDetailsPage selectFlatDetailsOption(String flatNo) {
		getWaitUtils().elementPresence(flatDetailsLbl, WaitConfigs.elementVisibleWait);
				
		String tt= getAttributeValue(flatDetailsLbl,"value");

		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			scrollIntoViewTillElement(getSelectedFlatNo(flatNo));
			safeClick(getSelectedFlatNo(flatNo));
		}
		
		return this;
	}
		
	
	public AccountDetailsPage clickInstallationCityLbl() {
		
		getWaitUtils().elementPresence(installationCityLbl, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(installationCityLbl);
		clickOnElementByJavaScriptExecutor(installationCityLbl);
		//clickOnElementAndTabKey(installationCityLbl);
		return this;
	}
	
	public AccountDetailsPage selectInstallationCityOption(String installationCity) {
		getWaitUtils().elementPresence(getSelectedInstallationCity(installationCity), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getSelectedInstallationCity(installationCity));
		clickOnElementByJavaScriptExecutor(getSelectedInstallationCity(installationCity));
		return this;
	}
	
	
	public AccountDetailsPage clickAgreeBtnFrmPopUp() {
		getWaitUtils().elementPresence(agreeBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(agreeBtn);
		clickElementUsingJavaScript(agreeBtn);
		return this;
	}
	
	public String getSubReqId() {
		
		getWaitUtils().elementPresence(subReqIdPopUpTitle, WaitConfigs.pageLoadWait);
		String subReqTitle = getDriver().findElement(subReqIdPopUpTitle).getText();
		System.out.println("the sub request title ::"+subReqTitle);
		String subReqId = subReqTitle.split(":")[1]; 
		System.out.println("the sub request Id ::"+subReqId);
		return subReqId;

	}
	
	public AccountDetailsPage clickOnOkBtnFrmPopUp() {
		getWaitUtils().elementPresence(popUpOkBtn, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(popUpOkBtn);
		clickElementUsingJavaScript(popUpOkBtn);
		return this;
	}
	
	public AccountDetailsPage enterCompanyNameEng1(String companyNameEng) {
		getWaitUtils().elementPresence(companyNmeEng1Txt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(companyNmeEng1Txt);
		safeType(companyNmeEng1Txt,companyNameEng);
		return this;
	}
	
	public AccountDetailsPage enterCompanyNameArabic1(String companyNameArabic) {
		getWaitUtils().elementPresence(companyNmeArabic1Txt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(companyNmeArabic1Txt);
		safeType(companyNmeArabic1Txt,companyNameArabic);
		return this;
	}
}
