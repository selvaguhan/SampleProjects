package com.pages.elife;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.automation.configs.WaitConfigs;
import com.base.utils.BasePage;

public class CustomerDetailsPage extends BasePage{
	
	private By custTitleLbl = By.id("addNewActionForm:engTitle_label");
	private By custTitleOption= By.xpath("//div[contains(@id,'addNewActionForm:engTitle_panel')]//li[contains(@data-label,'Mr.')]");
	
	private By custFNameTxt = By.id("addNewActionForm:firstName");
	private By custLNameTxt = By.id("addNewActionForm:lastName");
	
	
	private By custArabicFNameTxt = By.id("addNewActionForm:arabicFirstName");
	private By custArabicLNameTxt = By.id("addNewActionForm:arabicLastName");
	
	private By custDOBTxt = By.id("addNewActionForm:dateOfbirthId_input");
	
	private By nationalityLbl = By.id("addNewActionForm:nationality_label");
	
	private By contactPersonTxt = By.id("addNewActionForm:contactPerson");
	
	private By submitBtn = By.id("addNewActionForm:submitbtnId");
	
	private By submitDeleteBtn = By.id("addNewActionForm:submitbtnDelete");
	
	private By confirmCessBtn = By.id("addNewActionForm:cess_btn");
	
	private By getSelectedNationality(String nationalityToBeSelect) {
		
		//By nationalityOption= By.xpath("//div[contains(@id,'addNewActionForm:nationality_panel')]//li[contains(@data-label,'Albania')]");
		By nationalityOption= By.xpath("//div[contains(@id,'addNewActionForm:nationality_panel')]//li[@data-label='"+nationalityToBeSelect+"'"+"]");
		return nationalityOption;
	}
	
	private By languageLbl = By.id("addNewActionForm:preferredLanguage_label");
	private By languageOption= By.xpath("//div[contains(@id,'addNewActionForm:preferredLanguage_panel')]//li[contains(@data-label,'English')]");
	
	
	private By custSubTypeLbl = By.id("addNewActionForm:partySubTypeCode_label");
	
	
	private By getSelectedCustSubType(String custSubType) {
		
		//By custSubTypeOption= By.xpath("//div[contains(@id,'addNewActionForm:partySubTypeCode_panel')]//li[contains(@data-label,'Residential')]");
		By custSubTypeOption= By.xpath("//div[contains(@id,'addNewActionForm:partySubTypeCode_panel')]//li[@data-label='"+custSubType+"'"+"]");
		return custSubTypeOption;
	}
	
	private By cityLbl = By.id("addNewActionForm:city_label");
	
	public By getSelectedCity(String cityOption) {
		By selectedCity= By.xpath("//div[contains(@id,'addNewActionForm:city_panel')]//li[@data-label='"+cityOption+"'"+"]");
		return selectedCity;
	}
	
	public CustomerDetailsPage clickOnCityLbl() {
		getWaitUtils().elementPresence(cityLbl, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(cityLbl);
		clickByWebElement(cityLbl);
		return this;
	}

	public CustomerDetailsPage selectCity(String city) {
		getWaitUtils().elementPresence(getSelectedCity(city), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getSelectedCity(city));
		clickByWebElement(getSelectedCity(city));
		return this;
	}
	
	private By monthSclt = By.className("ui-datepicker-month");
	private By yearSclt = By.className("ui-datepicker-year");
	private By dateLnk = By.xpath("//a[contains(text(),'15')]");
	
	
	
	private By identityTypeLbl = By.id("addNewActionForm:identityType_label");
	private By identityTypeOption= By.xpath("//div[contains(@id,'addNewActionForm:identityType_panel')]//li[contains(@data-label,'Passport')]");
	
	private By issueDateTxt = By.id("addNewActionForm:issueDate_input");
	
	private String documentNoTagName="addNewActionForm:documentNo";
	private By documentNoTxt = By.id("addNewActionForm:documentNo");
	
	private By expiryDateTxt = By.id("addNewActionForm:expiryDate_input");
	
	private By visaIssueDateTxt = By.id("addNewActionForm:visaIssueDate_input");
	
	private By visaExpiryDateTxt = By.id("addNewActionForm:visaExpiryDate_input");
	
	private By visaIssueAuthorityTxt = By.id("addNewActionForm:visaIssuingAuthority");
	
	private String issueAuthorityTagNme="addNewActionForm:issuingAuthority";
	private By issuingAuthorityTxt = By.id("addNewActionForm:issuingAuthority");
	
	
	private By uniFiedNoTxt = By.id("addNewActionForm:unifiedNumber");
	
	private By visaNoTxt = By.id("addNewActionForm:visaNo");
	//private By docVerifiedChk = By.id("addNewActionForm:docVerifiedCB_input");
	private By docVerifiedChk = By.xpath("//div[contains(@id,'addNewActionForm:docVerifiedCB')]//input[contains(@id,'addNewActionForm:docVerifiedCB_input')]");
	
	private By docBypassReasonIDLbl = By.id("addNewActionForm:docBypassReasonID_label");
	private By docBypassReasonIDOption= By.xpath("//div[contains(@id,'addNewActionForm:docBypassReasonID_panel')]//li[contains(@data-label,'Passport renewed manually')]");
	
	public By getDocByPassReason(String reason) {
		By docBypassReasonIDOption1= By.xpath("//div[contains(@id,'addNewActionForm:docBypassReasonID_panel')]//li[contains(@data-label,"+"'"+reason+"'"+")]");
		return docBypassReasonIDOption1;
	}
	
	public By docVerifyLbl = By.id("addNewActionForm:docVerifyLabel");
	
	private By emirateLbl = By.id("addNewActionForm:emirate_label");
	private By emiratesOption= By.xpath("//div[contains(@id,'addNewActionForm:emirate_panel')]//li[contains(@data-label,'Dubai')]");
	
	private By englishAddress1Txt = By.id("addNewActionForm:englishAddress1");
	
	private By arabicAddress1Txt = By.id("addNewActionForm:arabicAddress1");
	
	private By custContactNumberTxt = By.id("addNewActionForm:customercontactnumber");

	private By poBoxTxt = By.id("addNewActionForm:pobox");
	
	private By custContactEmailTxt = By.id("addNewActionForm:customercontactemail");
	
	private By customerEmailIDTxt = By.id("addNewActionForm:emailAddress");
	
	public CustomerDetailsPage(WebDriver driver) {
		super(driver);
	}
	
	
	public CustomerDetailsPage clickOnCustTitleLbl() {
		getWaitUtils().isElementStaleNess(custTitleLbl, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(custTitleLbl);
		clickByWebElement(custTitleLbl);
		return this;
	}

	public CustomerDetailsPage selectCustTitleOption() {
		getWaitUtils().elementPresence(custTitleOption, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(custTitleOption);
		clickByWebElement(custTitleOption);
		return this;
	}
	
	public CustomerDetailsPage enterCustFname(String fName) {
		getWaitUtils().elementPresence(custFNameTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(custFNameTxt);

		String tt= getAttributeValue(custFNameTxt, "value");
		
		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			safeType(custFNameTxt, fName);
			onChangeEventFire(custFNameTxt);
		}
		return this;
	}
	
	public CustomerDetailsPage enterCustLname(String lName) {
		getWaitUtils().elementPresence(custLNameTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(custLNameTxt);
		
		String tt= getAttributeValue(custLNameTxt, "value");
		
		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			safeType(custLNameTxt, lName);
		}
		return this;
	}
	
	public CustomerDetailsPage enterCustArabicFname(String fName) {
		getWaitUtils().elementPresence(custArabicFNameTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(custArabicFNameTxt);

		String tt= getAttributeValue(custArabicFNameTxt, "value");
		
		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			safeType(custArabicFNameTxt, fName);
		}
		//clickOnElementAndTabKey(custArabicFNameTxt);
		return this;
	}
	
	public CustomerDetailsPage enterCustArabicLname(String lName) {
		getWaitUtils().elementPresence(custArabicLNameTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(custArabicLNameTxt);
		
		String tt= getAttributeValue(custArabicLNameTxt, "value");
		
		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			safeType(custArabicLNameTxt, lName);
		}
		return this;

	}
	
	public CustomerDetailsPage selectDOB(String date,String month,String year) {
		
		getWaitUtils().elementPresence(custDOBTxt, WaitConfigs.elementVisibleWait);
		
		String tt= getAttributeValue(custDOBTxt, "value");
		
		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			safeType(custDOBTxt, date+"-"+month+"-"+year);
			String dateXpath="//a[contains(text(),"+"'"+date+"')]";
			By dateLnk1 = By.xpath(dateXpath);
			 clickByWebElement(dateLnk1);
		}
					
		return this;
	}
	
	public CustomerDetailsPage clickOnCustNationalityLbl() {
		getWaitUtils().elementPresence(nationalityLbl, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(nationalityLbl);
		clickByWebElement(nationalityLbl);
		return this;
	}

	public CustomerDetailsPage selectCustNationalityOption(String nationalityToSelect) {
		getWaitUtils().elementPresence(getSelectedNationality(nationalityToSelect), WaitConfigs.elementVisibleWait);
		
		
		String tt= getText(nationalityLbl);
		
		if(tt.equalsIgnoreCase("Select")) {
			System.out.println("i am in the email id if block::"+tt);
			scrollIntoViewTillElement(getSelectedNationality(nationalityToSelect));
			clickByWebElement(getSelectedNationality(nationalityToSelect));
		}else {
			System.out.println("data populated based on the party id");
		}
		
		return this;
	}
	
	public CustomerDetailsPage clickOnCustSubTypeLbl() {
		getWaitUtils().elementPresence(custSubTypeLbl, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(custSubTypeLbl);
		clickByWebElement(custSubTypeLbl);
		return this;
	}

	public CustomerDetailsPage selectCustSubTypeOption(String custSubType) {
		getWaitUtils().elementPresence(getSelectedCustSubType(custSubType), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getSelectedCustSubType(custSubType));
		clickByWebElement(getSelectedCustSubType(custSubType));
		return this;
	}
	
	public CustomerDetailsPage clickOnIdentityTypeLbl() {
		getWaitUtils().elementPresence(identityTypeLbl, WaitConfigs.elementVisibleWait);
		//scrollIntoViewTillElement(identityTypeLbl);
		clickByWebElement(identityTypeLbl);
		return this;
	}

	public CustomerDetailsPage selectIdentityTypeOption() {
		getWaitUtils().elementPresence(identityTypeOption, WaitConfigs.elementVisibleWait);
		//scrollIntoViewTillElement(identityTypeOption);
		clickByWebElement(identityTypeOption);
		return this;
	}
	
	public CustomerDetailsPage selectIssueDate(String date,String month,String year) {
		String dateXpath="//a[contains(text(),"+"'"+date+"')]";
		By dateLnk1 = By.xpath(dateXpath);
		getWaitUtils().elementPresence(issueDateTxt, WaitConfigs.elementVisibleWait);
		clickByWebElement(issueDateTxt);
		//scrollIntoViewTillElement(monthSclt);
		selectValueFromDropDownByVisibleText(monthSclt, month);
		//scrollIntoViewTillElement(yearSclt);
		selectValueFromDropDownByVisibleText(yearSclt, year);
		clickByWebElement(dateLnk1);
		//clickOnTabKey(custDOBTxt);
		return this;
	}
	
	
	public CustomerDetailsPage enterVisaNo(String visNo) {
		getWaitUtils().elementPresence(visaNoTxt, WaitConfigs.elementVisibleWait);
		//scrollIntoViewTillElement(documentNoTxt);
		safeType(visaNoTxt,visNo);
		return this;
	}
	
	public CustomerDetailsPage enterDocumentNo(String docNo) {
		getWaitUtils().elementPresence(documentNoTxt, WaitConfigs.elementVisibleWait);

		
		String tt= getAttributeValue(documentNoTxt,"value");
		
		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			scrollIntoViewTillElement(documentNoTxt);
			safeType(documentNoTxt,docNo);
		}
		return this;
	}
	
	public CustomerDetailsPage selectExpiryDate(String date,String month,String year) {
		String dateXpath="//a[contains(text(),"+"'"+date+"')]";
		By dateLnk1 = By.xpath(dateXpath);
		
		getWaitUtils().elementPresence(expiryDateTxt, WaitConfigs.elementVisibleWait);
		
		String tt= getAttributeValue(expiryDateTxt,"value");
		
		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			
			clickByWebElement(expiryDateTxt);
			//scrollIntoViewTillElement(monthSclt);
			selectValueFromDropDownByVisibleText(monthSclt, month);
			//scrollIntoViewTillElement(yearSclt);
			selectValueFromDropDownByVisibleText(yearSclt, year);
			
			clickByWebElement(dateLnk1);
		}
		return this;
	}
	
	public CustomerDetailsPage selectVisaIssueDate(String date,String month,String year) {
		String dateXpath="//a[contains(text(),"+"'"+date+"')]";
		By dateLnk1 = By.xpath(dateXpath);
		getWaitUtils().elementPresence(visaIssueDateTxt, WaitConfigs.elementVisibleWait);
		
		
		String tt= getAttributeValue(visaIssueDateTxt,"value");
		
		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			
			clickByWebElement(visaIssueDateTxt);
			//scrollIntoViewTillElement(monthSclt);
			selectValueFromDropDownByVisibleText(monthSclt, month);
			//scrollIntoViewTillElement(yearSclt);
			selectValueFromDropDownByVisibleText(yearSclt, year);
			clickByWebElement(dateLnk1);
		}
		return this;
	}
	
	public CustomerDetailsPage selectVisaExpiryDate(String date,String month,String year) {
		String dateXpath="//a[contains(text(),"+"'"+date+"')]";
		By dateLnk1 = By.xpath(dateXpath);
		getWaitUtils().elementPresence(visaExpiryDateTxt, WaitConfigs.elementVisibleWait);

		String tt= getAttributeValue(visaExpiryDateTxt,"value");
		
		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			clickByWebElement(visaExpiryDateTxt);
			selectValueFromDropDownByVisibleText(monthSclt, month);
			selectValueFromDropDownByVisibleText(yearSclt, year);
			clickByWebElement(dateLnk1);
		}
		
		return this;
	}
	
	public CustomerDetailsPage enterVisaIssueAuthority(String visaIssueAuthority) {
		getWaitUtils().elementPresence(visaIssueAuthorityTxt, WaitConfigs.elementVisibleWait);
		
		String tt= getAttributeValue(visaIssueAuthorityTxt,"value");
		
		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			scrollIntoViewTillElement(visaIssueAuthorityTxt);
			safeType(visaIssueAuthorityTxt,visaIssueAuthority);
			
		}
		
		return this;
	}
	
	public CustomerDetailsPage enterIssuingAuthority(String issuingAuthority) {
		
		getWaitUtils().elementPresence(issuingAuthorityTxt, WaitConfigs.elementVisibleWait);
				
		String tt= getAttributeValue(issuingAuthorityTxt,"value");

		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			scrollIntoViewTillElement(issuingAuthorityTxt);
			safeType(issuingAuthorityTxt,issuingAuthority);
			
		}
		
		return this;
	}
	
	
	public CustomerDetailsPage enterUniFiedNo(String unifiedNo) {
		getWaitUtils().elementPresence(uniFiedNoTxt, WaitConfigs.elementVisibleWait);
		
		String tt= getAttributeValue(uniFiedNoTxt,"value");

		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			scrollIntoViewTillElement(uniFiedNoTxt);
			safeType(uniFiedNoTxt,unifiedNo);
			
		}
		return this;
	}
	
	public CustomerDetailsPage clickOnVerifiedDocChk() {
		getWaitUtils().elementPresence(docVerifiedChk, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(docVerifiedChk);
		clickByWebElement(docVerifiedChk);
		//onChangeEventFire(docVerifiedChk);
		//clickOnElementAndTabKey(docVerifiedChk);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public CustomerDetailsPage clickOnDocByPassReasonLbl() {
		getWaitUtils().elementPresence(docBypassReasonIDLbl, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(docBypassReasonIDLbl);
		clickByWebElement(docBypassReasonIDLbl);
		return this;
	}

	public CustomerDetailsPage selectDocByPassReasonOption() {
		getWaitUtils().elementPresence(docBypassReasonIDOption, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(docBypassReasonIDOption);
		clickByWebElement(docBypassReasonIDOption);
		return this;
	}
	
	public CustomerDetailsPage clickOnEmiratesLbl() {
		getWaitUtils().elementPresence(emirateLbl, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(emirateLbl);
		clickByWebElement(emirateLbl);
		return this;
	}

	public CustomerDetailsPage selectEmiratesOption() {
		getWaitUtils().elementPresence(emiratesOption, WaitConfigs.elementVisibleWait);
		
		String tt= getAttributeValue(emirateLbl,"value");

		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			scrollIntoViewTillElement(emiratesOption);
			clickByWebElement(emiratesOption);
		}
		return this;
	}
	
	public CustomerDetailsPage enterEnglishAddess1(String englishAddress1) {
		getWaitUtils().elementPresence(englishAddress1Txt, WaitConfigs.elementVisibleWait);
		
		String tt= getAttributeValue(englishAddress1Txt,"value");

		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			scrollIntoViewTillElement(englishAddress1Txt);
			safeType(englishAddress1Txt,englishAddress1);
		}
		
		
		return this;
	}
	
	public CustomerDetailsPage enterArabicAddess1(String arabicAddress1) {
		getWaitUtils().elementPresence(arabicAddress1Txt, WaitConfigs.elementVisibleWait);
		
		String tt= getAttributeValue(arabicAddress1Txt,"value");

		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("data populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			scrollIntoViewTillElement(arabicAddress1Txt);
			safeType(arabicAddress1Txt,arabicAddress1);
		}
		
		
		return this;
	}
	
	public CustomerDetailsPage enterCustMobileNo(String mobileNo) {
		getWaitUtils().elementPresence(custContactNumberTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(custContactNumberTxt);
		safeType(custContactNumberTxt,mobileNo);
		onChangeEventFire(custContactNumberTxt);
		//clickOnElementAndTabKey(custContactNumberTxt);
		return this;
	}
	
	
	
	public CustomerDetailsPage enterPOBoxNo(String mobileNo) {
		getWaitUtils().elementPresence(poBoxTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(poBoxTxt);
		safeType(poBoxTxt,mobileNo);
		//clickOnElementAndTabKey(custContactNumberTxt);
		return this;
	}
	
	public CustomerDetailsPage enterCustEmailId(String emailId) {
		getWaitUtils().isElementStaleNess(custContactEmailTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(custContactEmailTxt);
		safeType(custContactEmailTxt,emailId);
		onChangeEventFire(custContactEmailTxt);
		//clickOnElementAndTabKey(custContactNumberTxt);
		return this;
	}
	
	public CustomerDetailsPage enterCustDetailsEmailId(String emailId) {
		getWaitUtils().isElementStaleNess(customerEmailIDTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(customerEmailIDTxt);
		safeType(customerEmailIDTxt,emailId);
		return this;
	}
	
	
	public CustomerDetailsPage enterContactPerson(String conPerson) {
		getWaitUtils().isElementStaleNess(contactPersonTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(contactPersonTxt);
		safeType(contactPersonTxt,conPerson);
		//onChangeEventFire(contactPersonTxt);
		return this;
	}
	
	public CustomerDetailsPage clickOnSubmitBtn() {
		getWaitUtils().elementPresence(submitBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(submitBtn);
		clickByWebElement(submitBtn);
		return this;
	}
	
	public CustomerDetailsPage clickOnConfirmCessationBtn() {
		getWaitUtils().elementPresence(confirmCessBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(confirmCessBtn);
		clickByWebElement(confirmCessBtn);
		return this;
	}
	
	
	public CustomerDetailsPage clickOnSubmitDeleteBtn() {
		getWaitUtils().elementPresence(submitDeleteBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(submitDeleteBtn);
		clickByWebElement(submitDeleteBtn);
		return this;
	}
	
}
