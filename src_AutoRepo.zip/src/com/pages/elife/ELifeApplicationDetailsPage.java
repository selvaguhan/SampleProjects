package com.pages.elife;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.automation.configs.WaitConfigs;
import com.base.utils.BasePage;

public class ELifeApplicationDetailsPage extends BasePage{
	
	public By selectSeriveTypeLbl = By.id("addNewActionForm:serviceType_label");

	public By getServiceType(String serviceTypeOption) {
		//By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:serviceType_panel')]//li[contains(@data-label,'New Account')]");
		//By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:serviceType_panel')]//li[@data-label='"+serviceTypeOption+"'"+"]");
		By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:serviceType_panel')]//li[contains(@data-label,'"+serviceTypeOption+"')]");
		return serviceType;
	}
	
	
	
	
	public By seriveTypeFilterTxt = By.id("addNewActionForm:serviceType_filter");
	
	public By serivceRequiredLabel = By.id("addNewActionForm:serviceRequired_label");
	
	public By subRequestNoTxt = By.id("addNewActionForm:requestNo");
	
	public By accountNumberTxt = By.id("addNewActionForm:accountNumber");
	
	public String contactNumberTag = "addNewActionForm:contactNumber";
	public By contactNumberText = By.id("addNewActionForm:contactNumber");
	
	public By contactEmailIDTxt = By.id("addNewActionForm:emailAddress");
	
	public By productGrpDescription = By.xpath("//input[contains(@value,'eLife Product Group')]");
	
	
	public By closeCessationLoading = By.xpath("//div[contains(text(),'Re-calculating Exit Charges for the selected cessation reason....')]");
	
	private By mainRetentionOffersRdioBtn= By.id("addNewActionForm:retenTypesel:0");
	
	public By alshamilRPContinuePopUpBtn= By.id("addNewActionForm:j_idt1440");
	
	
	
	private By offerDescriptionDetailsRdioBtn= By.xpath("//TBODY[@id='addNewActionForm:retenIdDetails_data']/TR[1]/TD[1]/DIV/DIV[2]");
	
	//private By offerDescriptionDetailsRdioBtn= By.xpath("//TBODY[@id='addNewActionForm:retenIdDetails_data']/TR[3]//input[contains(@name,'addNewActionForm:retenIdDetails_radio')]");
	
	private By rejectRetentionOfferRadioBtn= By.xpath("//TABLE[@id='addNewActionForm:reteTypeFlag']/TBODY/TR/TD[4]/LABEL");
	//TABLE[@id='addNewActionForm:reteTypeFlag']/TBODY/TR/TD[3]/DIV/DIV[2]
	//TABLE[@id='addNewActionForm:reteTypeFlag']/TBODY/TR/TD[4]/LABEL
	private By alternateNoTxt= By.id("addNewActionForm:j_idt1157");
	//private By alternateNoTxt= By.xpath("(//input[contains(@name,'addNewActionForm:') and contains(@role,'textbox')])[position()=1]");
	
	private By noteTxt= By.id("addNewActionForm:j_idt1161");
	//private By noteTxt= By.xpath("(//textarea[contains(@name,'addNewActionForm:') and contains(@role,'textbox')])[position()=1]");
	
	
	private By enigmaRatePlanChk= By.xpath("//tbody[@id='addNewActionForm:deleteSrv_data']//td[text()='eLife Enigma service' or text()='RPENIGMA']");
	
	
	
	public By noOfInternetUsersLbl= By.id("addNewActionForm:noPeopleHI_label");
	public By getNoOfInternetUsers(String serviceOption) {
		//By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:serviceRequired_panel')]//li[contains(@data-label,'"+serviceOption+"'"+")]");
		By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:noPeopleHI_panel')]//li[@data-label='"+serviceOption+"'"+"]");
		return serviceType;
	}
	
	public By noOfRoomsInHouseLbl= By.id("addNewActionForm:noofroomidHI_label");
	public By getNoOfRoomsInHouse(String noOfRoomsInHouse) {
		//By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:serviceRequired_panel')]//li[contains(@data-label,'"+serviceOption+"'"+")]");
		By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:noofroomidHI_panel')]//li[@data-label='"+noOfRoomsInHouse+"'"+"]");
		return serviceType;
	}
	
	public By selectedCountryLbl = By.id("addNewActionForm:selectedCountryId2P_label");
	
		
	public By getSelectedCounty(String countyToBeSelect) {
		//By countryOption= By.xpath("//div[contains(@id,'addNewActionForm:selectedCountryId_panel')]//li[@data-label='Albania']");
		By countryOption= By.xpath("//div[contains(@id,'addNewActionForm:selectedCountryId2P_panel')]//li[@data-label='"+countyToBeSelect+"'"+"]");
		return countryOption;
	}
	public By proposePackageBtn = By.id("addNewActionForm:btnFormHI");
	
	public By getRequiredService(String serviceOption) {
		//By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:serviceRequired_panel')]//li[contains(@data-label,'"+serviceOption+"'"+")]");
		By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:serviceRequired_panel')]//li[@data-label='"+serviceOption+"'"+"]");
		return serviceType;
	}
	
		
	private By cessReasonLbl = By.id("addNewActionForm:cessreason_label");
	
	public By noRadioBtn = By.id("addNewActionForm:number_recycle_radio:1");
	
	
	public By getSelectedCessReason(String cessReasonOption) {
		//By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:serviceRequired_panel')]//li[contains(@data-label,'"+serviceOption+"'"+")]");
		By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:cessreason_panel')]//li[@data-label='"+cessReasonOption+"'"+"]");
		return serviceType;
	}
	
	public By getExistingCustomer(String existingCustomerOption) {
		//By serviceType= By.xpath("//div[contains(@id,'addNewActionForm:serviceRequired_panel')]//li[contains(@data-label,'"+serviceOption+"'"+")]");
		By existingCustomerRadioBtn= By.xpath("//table[contains(@id,'addNewActionForm:isServiceAvailable')]//input[contains(@id,'addNewActionForm:isServiceAvailable') and contains(@value,'"+existingCustomerOption+"')]");
		return existingCustomerRadioBtn;
	}
	
	
	public ELifeApplicationDetailsPage(WebDriver driver) {
		super(driver);
	}
	
	
	
	public ELifeApplicationDetailsPage clickOnMainRetentionOffersRadioBtn() {
		getWaitUtils().elementPresence(mainRetentionOffersRdioBtn, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(mainRetentionOffersRdioBtn);
		clickByWebElement(mainRetentionOffersRdioBtn);
		return this;
	}
	
	public ELifeApplicationDetailsPage clickOnOffersDescriptionRadioBtn() {
		getWaitUtils().elementPresence(offerDescriptionDetailsRdioBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(offerDescriptionDetailsRdioBtn);
		clickOnElementByJavaScriptExecutor(offerDescriptionDetailsRdioBtn);
		return this;
	}
	
	
	public ELifeApplicationDetailsPage clickOnRejectRetentionOffersRadioBtn() {
		getWaitUtils().elementPresence(rejectRetentionOfferRadioBtn, WaitConfigs.elementVisibleWait);
		//scrollIntoViewTillElement(rejectRetentionOfferRadioBtn);
		clickOnElementByJavaScriptExecutor(rejectRetentionOfferRadioBtn);
		return this;
	}
	
	public ELifeApplicationDetailsPage clickOnServiceTypeDropDownBtn() {
		
		getWaitUtils().elementPresence(selectSeriveTypeLbl, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(selectSeriveTypeLbl);
		clickByWebElement(selectSeriveTypeLbl);
		return this;
	}

	
	public ELifeApplicationDetailsPage selectSeriveTypeFilterAndclick(String serviceType) {
		getWaitUtils().elementPresence(getServiceType(serviceType), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getServiceType(serviceType));
		safeClick(getServiceType(serviceType));
		return this;
	}
	
	public ELifeApplicationDetailsPage clickOnCessReasonDropDownBtn() {
		getWaitUtils().elementPresence(cessReasonLbl, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(cessReasonLbl);
		clickElementUsingJavaScript(cessReasonLbl);
		return this;
	}
	
	public ELifeApplicationDetailsPage selectCessReasonAndClick(String cessReasonOption) {
		getWaitUtils().elementPresence(getSelectedCessReason(cessReasonOption), WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(getSelectedCessReason(cessReasonOption));
		safeClick(getSelectedCessReason(cessReasonOption));
		return this;
	}
	
	
	public ELifeApplicationDetailsPage clickOnServiceRequiredLabel() {
		
		getWaitUtils().elementPresence(serivceRequiredLabel, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(serivceRequiredLabel);
		clickByWebElement(serivceRequiredLabel);
		return this;
	}
	
	public ELifeApplicationDetailsPage selectServiceRequiredType(String selectReqService) {
		getWaitUtils().elementPresence(getRequiredService(selectReqService), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getRequiredService(selectReqService));
		clickByWebElement(getRequiredService(selectReqService));
		return this;
	}
	
	
	public ELifeApplicationDetailsPage clickOnExistingCustRadioBtn(String existinCustOption) {
		
		getWaitUtils().elementPresence(getExistingCustomer(existinCustOption), WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(getExistingCustomer(existinCustOption));
		clickByWebElement(getExistingCustomer(existinCustOption));
		return this;
	}
	
	public ELifeApplicationDetailsPage enterSubRequestNo(String subReqNo) throws InterruptedException {
		getWaitUtils().elementPresence(subRequestNoTxt, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(subRequestNoTxt);
		safeType(subRequestNoTxt, subReqNo);
		onChangeEventFire(subRequestNoTxt);
		return this;
	}
	
	public ELifeApplicationDetailsPage enterAccountNo(String accountNo) throws InterruptedException {
		getWaitUtils().elementPresence(accountNumberTxt, WaitConfigs.elementVisibleWait);
		//scrollIntoViewTillElement(accountNumberTxt);
		safeType(accountNumberTxt, accountNo);
		onChangeEventFire(accountNumberTxt);
		return this;
	}
	
	public ELifeApplicationDetailsPage enterContactNumber(String contactNo) throws InterruptedException {
		getWaitUtils().elementPresence(productGrpDescription, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(contactNumberText);
		typeText(contactNumberText, contactNo);
		return this;
	}
	
	public ELifeApplicationDetailsPage enterContactEmailId(String emailId) throws InterruptedException {
		getWaitUtils().elementPresence(contactEmailIDTxt, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(contactEmailIDTxt);
		
		String tt= getAttributeValue(contactEmailIDTxt, "value");
		
		if(tt != null && !tt.trim().isEmpty()) {
			System.out.println("email id populated based on the party id");
			
		}else {
			System.out.println("i am in the email id if block::"+tt);
			typeTextViaAction(contactEmailIDTxt, emailId);
		}
		
		return this;
	}
	
	public ELifeApplicationDetailsPage enterAlternateContactNumber(String alternateContactNo) throws InterruptedException {
		getWaitUtils().elementPresence(alternateNoTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(alternateNoTxt);
		safeType(alternateNoTxt, alternateContactNo);
		return this;
	}
	
	public ELifeApplicationDetailsPage enterNote(String notetXT) throws InterruptedException {
		getWaitUtils().elementPresence(noteTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(noteTxt);
		safeType(noteTxt, notetXT);
		return this;
	}
	
	
	public ELifeApplicationDetailsPage clickOnEngimaRatePlan() {
		
		getWaitUtils().elementPresence(enigmaRatePlanChk, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(enigmaRatePlanChk);
		clickElementUsingJavaScript(enigmaRatePlanChk);
		return this;
	}
	
	public void enterCustomerMobileNo1(String custMobNum) {
		String tt = getAttributeValue(contactNumberText, "value");
		System.out.println("the contact customer mobile number is:"+tt);
		if(tt!=null && !tt.trim().isEmpty()) {
			System.out.println("conctact number is populated based on the party id");
			
		}else {
			System.out.println("i am in the else block");
			typeText(contactNumberText,custMobNum);
		}
	}
	
	
}
