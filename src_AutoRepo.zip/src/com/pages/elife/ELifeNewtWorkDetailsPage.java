package com.pages.elife;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.configs.WaitConfigs;
import com.base.utils.BasePage;
import com.cbcm.singleSelectWindow.pages.AccountServicesWindowPage;

public class ELifeNewtWorkDetailsPage extends BasePage{
		
	
	private By eidRadioBtn= By.xpath("//table[contains(@id,'addNewActionForm:ftthCriteriaFlag')]//input[contains(@id,'addNewActionForm:ftthCriteriaFlag') and contains(@value,'eid')]");
	
	private String eidTagName ="addNewActionForm:EID";
	
	public By eidTxt = By.xpath("//input[contains(@id,'addNewActionForm:EID')]");	
	
	//public By eidTxt1 = By.id("addNewActionForm:EID1");
	
	private By partyIDTxt = By.id("addNewActionForm:partyID");

	
	private By checkAvaliablityLnk = By.xpath("//a[contains(@id,'addNewActionForm:checkForAvaliability')]");
	
	private By selectTVProgramLbl = By.id("addNewActionForm:selectedtvProg_label");
	
	
	public By packageValueAddedServiceChk = By.xpath("//TBODY[@id='addNewActionForm:homecon_data']/TR[2]/TD[1]/DIV/DIV[2]");
	
	private By getTVProgramOption(String tvPrgmOption) {
		//By tvProgramOption= By.xpath("//div[contains(@id,'addNewActionForm:selectedtvProg_panel')]//li[contains(@data-label,'Generic')]");
		By tvProgramOption= By.xpath("//div[contains(@id,'addNewActionForm:selectedtvProg_panel')]//li[@data-label='"+tvPrgmOption+"'"+"]");
		return tvProgramOption;
	}
	
	
	private By noOfRoomsInHouseLbl = By.id("addNewActionForm:noofroomid_label");

		
	private By getNoOfSelectedRooms(String noOfRooms) {
		//By threeRoomOptionSelect= By.xpath("//div[contains(@id,'addNewActionForm:noofroomid_panel')]//li[contains(@data-label,'3 Room')]");
		By threeRoomOptionSelect= By.xpath("//div[contains(@id,'addNewActionForm:noofroomid_panel')]//li[@data-label='"+noOfRooms+"'"+"]");
		return threeRoomOptionSelect;
	}
	
	private By noOfRoomsInUseLbl = By.id("addNewActionForm:noofroomidHI_label");

	private By getNoOfSelectedRoomsInUse(String noOfRooms) {

		By internetUserSelect= By.xpath("//div[contains(@id,'addNewActionForm:noofroomidHI_panel')]//li[@data-label='"+noOfRooms+"'"+"]");
		return internetUserSelect;
	}
	
	private By noOfInternetUserLbl = By.id("addNewActionForm:noPeopleHI_label");

	private By getNoOfSelectedInternetUsers(String noOfUsers) {

		By internetUserSelect= By.xpath("//div[contains(@id,'addNewActionForm:noPeopleHI_panel')]//li[@data-label='"+noOfUsers+"'"+"]");
		return internetUserSelect;
	}
	
	public By packageCodeDescLbl = By.id("addNewActionForm:homecon:1:packageCodeDesc1_label");
		
	public By getSelectedPackageCodeDesc(String packageCodeDesc) {
		By threeRoomOptionSelect= By.xpath("//div[contains(@id,'addNewActionForm:homecon:1:packageCodeDesc1_panel')]//li[@data-label='"+packageCodeDesc+"'"+"]");
		return threeRoomOptionSelect;
	}
	
	
	
	private By countryLbl = By.id("addNewActionForm:selectedCountryId_label");
	
	
	
	private By getSelectedCounty(String countyToBeSelect) {
		
		//By countryOption= By.xpath("//div[contains(@id,'addNewActionForm:selectedCountryId_panel')]//li[@data-label='Albania']");
		By countryOption= By.xpath("//div[contains(@id,'addNewActionForm:selectedCountryId_panel')]//li[@data-label='"+countyToBeSelect+"'"+"]");
		return countryOption;
	}
	
	//private By proposePackageBtn = By.id("addNewActionForm:btnForm");
	
	private By proposePackageBtn = By.xpath("//button[contains(@id,'addNewActionForm:btnForm') or contains(@id,'addNewActionForm:btnFormHI')]");
	
	private By recorderRadioBtn= By.xpath("//table[contains(@id,'addNewActionForm:stbTypeMain')]//input[contains(@id,'addNewActionForm:stbTypeMain:0')]");
	
	
	private By room1TelephoneChk = By.id("addNewActionForm:room1Telephone_input");
	private By room2TelephoneChk = By.id("addNewActionForm:room2Telephone_input");
	
	//private By vasServiceIdChk = By.xpath("//TH[@id='addNewActionForm:vasServiceId:j_idt652']/DIV/DIV[2]");
	private By vasServiceIdChk = By.xpath("//TH[contains(@id,'addNewActionForm:vasServiceId')]/DIV/DIV[2]");

	private By vasAddServiceIdChk = By.xpath("//TH[contains(@id,'addNewActionForm:vasServiceIdAdd:j_idt1281')]/DIV/DIV[2]");
	//private By vasServiceIdChk = By.className("ui-chkbox ui-chkbox-all ui-widget");
	
	
	private By proceedBtn = By.id("addNewActionForm:btnValidate");
	
	private By proceedBtn1 = By.id("addNewActionForm:btnValidate1");
	
	private By eidStatusLbl= By.xpath("//lable[contains(text(),'Eid Status:')]");
	
	public ELifeNewtWorkDetailsPage(WebDriver driver) {
		super(driver);
	}
		
	
	public ELifeNewtWorkDetailsPage clickOnEIDRadioBtn() {
		
		getWaitUtils().elementPresence(eidRadioBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(eidRadioBtn);
		clickByWebElement(eidRadioBtn);
		return this;
	}
	
	public ELifeNewtWorkDetailsPage enterEIDNumber(String eidNo) {
		getWaitUtils().elementPresence(eidTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(eidTxt);
		typeValueByJavaScript(eidTagName, eidNo);
		onChangeEventFire(eidTxt);
		return this;
	}
	
	public ELifeNewtWorkDetailsPage enterPartyID(String partyID) {
		getWaitUtils().elementPresence(partyIDTxt, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(partyIDTxt);
		safeType(partyIDTxt, partyID);
		onChangeEventFire(partyIDTxt);
		return this;
	}
	
	
	public ELifeNewtWorkDetailsPage clickOnCheckAvaliablityLnk() {
		getWaitUtils().elementPresence(checkAvaliablityLnk, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(checkAvaliablityLnk);
		clickOnElementByJavaScriptExecutor(checkAvaliablityLnk);
		//clickOnElementAndTabKey(checkAvaliablityLnk);
		return this;
	}
	
	public ELifeNewtWorkDetailsPage clickTVProgramLbl() {
		getWaitUtils().elementPresence(selectTVProgramLbl, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(selectTVProgramLbl);
		clickOnElementByJavaScriptExecutor(selectTVProgramLbl);
		return this;
	}
	
	public ELifeNewtWorkDetailsPage selectTVProramOptionAndClick(String tvProgramOption) {
		getWaitUtils().elementPresence(getTVProgramOption(tvProgramOption), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getTVProgramOption(tvProgramOption));
		clickOnElementByJavaScriptExecutor(getTVProgramOption(tvProgramOption));
		return this;
	}
	
	public ELifeNewtWorkDetailsPage clickOnNoOfRoomsInHouseLbl() {
		getWaitUtils().isElementClickable(noOfRoomsInHouseLbl, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(noOfRoomsInHouseLbl);
		clickOnElementByJavaScriptExecutor(noOfRoomsInHouseLbl);
		return this;
	}
	
	
	public ELifeNewtWorkDetailsPage selectTVRoomOptionAndClick(String noOfRooms) {
		getWaitUtils().elementPresence(getNoOfSelectedRooms(noOfRooms), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getNoOfSelectedRooms(noOfRooms));
		clickOnElementByJavaScriptExecutor(getNoOfSelectedRooms(noOfRooms));
		return this;
	}
	
	public ELifeNewtWorkDetailsPage clickOnNoOfInternetUsersLbl() {
		getWaitUtils().isElementClickable(noOfInternetUserLbl, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(noOfInternetUserLbl);
		clickOnElementByJavaScriptExecutor(noOfInternetUserLbl);
		return this;
	}
	
	
	public ELifeNewtWorkDetailsPage selectInternetUserAndClick(String noOfInternetUser) {
		getWaitUtils().elementPresence(getNoOfSelectedInternetUsers(noOfInternetUser), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getNoOfSelectedInternetUsers(noOfInternetUser));
		clickOnElementByJavaScriptExecutor(getNoOfSelectedInternetUsers(noOfInternetUser));
		return this;
	}
	
	
	public ELifeNewtWorkDetailsPage clickOnNoOfRoomsInUse() {
		getWaitUtils().isElementClickable(noOfRoomsInUseLbl, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(noOfRoomsInUseLbl);
		clickOnElementByJavaScriptExecutor(noOfRoomsInUseLbl);
		return this;
	}
	
	
	public ELifeNewtWorkDetailsPage selectRoomsInUseAndClick(String noOfInternetUser) {
		getWaitUtils().elementPresence(getNoOfSelectedRoomsInUse(noOfInternetUser), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getNoOfSelectedRoomsInUse(noOfInternetUser));
		clickOnElementByJavaScriptExecutor(getNoOfSelectedRoomsInUse(noOfInternetUser));
		return this;
	}
	
	public By getServicePlan(String typeOfService) {
		
		By internetUserSelect= By.xpath("//div[contains(@id,'addNewActionForm:completeVasServiceid_panel')]//li[@data-item-label='"+typeOfService+"'"+"]");
		return internetUserSelect;
	}
	public ELifeNewtWorkDetailsPage selectServicePlan(String noOfInternetUser) {
		getWaitUtils().elementPresence(getServicePlan(noOfInternetUser), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getServicePlan(noOfInternetUser));
		clickOnElementByJavaScriptExecutor(getServicePlan(noOfInternetUser));
		return this;
	}
	
	public By getAddServicePlan(String typeOfService) {
		
		By internetUserSelect= By.xpath("//div[contains(@id,'addNewActionForm:completeVasServiceidAdd_panel')]//li[@data-item-label='"+typeOfService+"'"+"]");
		return internetUserSelect;
	}
	
	public ELifeNewtWorkDetailsPage selectAddServicePlan(String noOfInternetUser) {
		getWaitUtils().elementPresence(getAddServicePlan(noOfInternetUser), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getAddServicePlan(noOfInternetUser));
		clickOnElementByJavaScriptExecutor(getAddServicePlan(noOfInternetUser));
		return this;
	}
	
	public By addBtn= By.id("addNewActionForm:j_idt606");
	
	public By addBtn1= By.id("addNewActionForm:j_idt1256");
	
	
	public ELifeNewtWorkDetailsPage clickOnCountryLbl() {
		getWaitUtils().elementPresence(countryLbl, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(countryLbl);
		clickOnElementByJavaScriptExecutor(countryLbl);
		return this;
	}
	
	
	public ELifeNewtWorkDetailsPage selectCountyOptionAndClick(String countryToBeSelect) {
		getWaitUtils().elementPresence(getSelectedCounty(countryToBeSelect), WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(getSelectedCounty(countryToBeSelect));
		clickOnElementByJavaScriptExecutor(getSelectedCounty(countryToBeSelect));
		return this;
	}
	
	public ELifeNewtWorkDetailsPage clickOnProposePackageBtn() {
		getWaitUtils().elementPresence(proposePackageBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(proposePackageBtn);
		clickByWebElement(proposePackageBtn);
		return this;
	}
	
	
	public ELifeNewtWorkDetailsPage clickOnRecorderRadioBtn() {
		getWaitUtils().isElementClickable(recorderRadioBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(recorderRadioBtn);
		clickByWebElement(recorderRadioBtn);
		return this;
	}
	
	public ELifeNewtWorkDetailsPage clickOnRoom1TelephoneChk() {
		getWaitUtils().isElementClickable(room1TelephoneChk, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(room1TelephoneChk);
		clickByWebElement(room1TelephoneChk);
		return this;
	}
	
	public ELifeNewtWorkDetailsPage clickOnRoom2TelephoneChk() {
		getWaitUtils().isElementClickable(room2TelephoneChk, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(room2TelephoneChk);
		clickByWebElement(room2TelephoneChk);
		return this;
	}
	

	public ELifeNewtWorkDetailsPage clickOnVasServiceIdChk() {
		getWaitUtils().isElementClickable(vasServiceIdChk, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(vasServiceIdChk);
		clickByWebElement(vasServiceIdChk);
		//scroll1(vasServiceIdChk);
		return this;
	}
	
	public ELifeNewtWorkDetailsPage clickOnVasAddServiceIdChk() {
		getWaitUtils().isElementClickable(vasAddServiceIdChk, WaitConfigs.pageLoadWait);
		scrollIntoViewTillElement(vasAddServiceIdChk);
		clickByWebElement(vasAddServiceIdChk);
		//scroll1(vasServiceIdChk);
		return this;
	}
	
	
	public ELifeNewtWorkDetailsPage clickOnProceedBtnk() {
		getWaitUtils().elementPresence(proceedBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(proceedBtn);
		clickElementUsingJavaScript(proceedBtn);
		return this;
	}
	
	
	public ELifeNewtWorkDetailsPage clickOnAddServiceProceedBtn() {
		getWaitUtils().elementPresence(proceedBtn1, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(proceedBtn1);
		clickElementUsingJavaScript(proceedBtn1);
		return this;
	}
	//private By noBtnFrmPopUp  = By.xpath("//div[contains(@id,'eLifeXpressDlgForm:eLifeXpressDlgId')]//button[contains(name,'eLifeXpressDlgForm:') and contains(text(),'No')]");
	
	private By noBtnFrmPopUp  = By.xpath("(//button[contains(@id,'eLifeXpressDlgForm:j_idt')])[position()=2]");
	
	private By yesBtnFrmPopUp  = By.xpath("(//button[contains(@id,'eLifeXpressDlgForm:j_id')])[position()=1]");
	
	private By yesBtnFrmPopUp1  = By.id("eLifePromoDialogForm:eLifePromoNobtnId");
	
	private By submitBtnFrmPartyIDDetailsPopUp  = By.id("partyDtlForm:partyIdDetails:partySubmit");
	
	public By partyIDDetailsRadioBtnFrmPopUp = By.name("partyDtlForm:partyIdDetails_radio");
	
	public By partyIDDetailsContinueFrmPopUp = By.xpath("//DIV[@id='pendingSubReqForm:pendingSubReqTable']/DIV[4]/button[contains(@id,'pendingSubReqForm:pendingSubReqTable:pendingSubReqContId')]");
	//public By partyIDDetailsContinueFrmPopUp = By.id("pendingSubReqForm:pendingSubReqTable:pendingSubReqContId");
	
	public ELifeNewtWorkDetailsPage clickPartyIDDetailsContinueFrmPopUp() {
		
			getWaitUtils().elementPresence(partyIDDetailsContinueFrmPopUp, WaitConfigs.elementVisibleWait);
			scrollIntoViewTillElement(partyIDDetailsContinueFrmPopUp);
			clickElementUsingJavaScript(partyIDDetailsContinueFrmPopUp);
			onClickEventFire(partyIDDetailsContinueFrmPopUp);
			return this;
		
	}
	
	public ELifeNewtWorkDetailsPage clickPartyIDDetailsRadioBtnFrmPopUp() {
		getWaitUtils().elementPresence(partyIDDetailsRadioBtnFrmPopUp, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(partyIDDetailsRadioBtnFrmPopUp);
		clickElementUsingJavaScript(partyIDDetailsRadioBtnFrmPopUp);
		return this;
	}
	
	public ELifeNewtWorkDetailsPage clickSubmitBtnFrmPartyIDDetailsFrmPopUp() {
		getWaitUtils().elementPresence(submitBtnFrmPartyIDDetailsPopUp, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(submitBtnFrmPartyIDDetailsPopUp);
		clickElementUsingJavaScript(submitBtnFrmPartyIDDetailsPopUp);
		return this;
	}
	
	public ELifeNewtWorkDetailsPage clickNoBtnFrmPopUp() {
		getWaitUtils().elementPresence(noBtnFrmPopUp, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(noBtnFrmPopUp);
		clickElementUsingJavaScript(noBtnFrmPopUp);
		return this;
	}
	
	public ELifeNewtWorkDetailsPage clickYesBtnFrmPopUp() {
		getWaitUtils().elementPresence(yesBtnFrmPopUp, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(yesBtnFrmPopUp);
		clickElementUsingJavaScript(yesBtnFrmPopUp);
		return this;
	}
	
	public ELifeNewtWorkDetailsPage clickYesBtnFrmPopUp1() {
		
		if(isElementDisplayed(yesBtnFrmPopUp1)) {
			getWaitUtils().elementPresence(yesBtnFrmPopUp1, WaitConfigs.elementVisibleWait);
			scrollIntoViewTillElement(yesBtnFrmPopUp1);
			clickElementUsingJavaScript(yesBtnFrmPopUp1);
		}
		return this;
	}
	
	
	private By noBtnFrmAlshamilPopUp  = By.name("eLifeXpressDlgForm:j_idt2553");

	public ELifeNewtWorkDetailsPage clickNoBtnFrmAlShamilPopUp() {
		getWaitUtils().elementPresence(noBtnFrmAlshamilPopUp, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(noBtnFrmAlshamilPopUp);
		clickElementUsingJavaScript(noBtnFrmAlshamilPopUp);
		return this;
	}
	
	private By noBtnFrmPopUp2  = By.id("eLifePromoDialogForm:eLifePromoNobtnId");
	
	public ELifeNewtWorkDetailsPage clickNoBtnFrmPopUp2() {
		getWaitUtils().elementPresence(noBtnFrmPopUp2, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(noBtnFrmPopUp2);
		clickElementUsingJavaScript(noBtnFrmPopUp2);
		return this;
	}
	
	
	private By engimaYesBtn  = By.id("enigmaYesbtnId");
	
	public ELifeNewtWorkDetailsPage clickEngimaYesBtnFrmPopUp3() {
		getWaitUtils().elementPresence(engimaYesBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(engimaYesBtn);
		clickElementUsingJavaScript(engimaYesBtn);
		return this;
	}
	
	public By searchWithCodeTxt  = By.id("addNewActionForm:completeVasServiceid_input");
	public By searchWithCodeTxt1  = By.id("addNewActionForm:completeVasServiceidAdd_input");
	
}
