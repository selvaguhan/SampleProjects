package com.base.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.automation.configs.RQMConfigs;

public class RQMUtils {
	
	public RQMUtils() {
		
	}
	
	 public void connectRQMandGetTestCaseName(String testCaseName) throws IOException {
		 		  
	     ProcessBuilder builder = new ProcessBuilder(
	     		new String[] {"cmd.exe", "/c",RQMConfigs.jarfile+RQMConfigs.getUserCmd(RQMConfigs.userName,RQMConfigs.passWord)+
	     				RQMConfigs.getFilePathCmd(RQMConfigs.responceTCName)+RQMConfigs.connectRQMAndGetTC(testCaseName)});
	     builder.redirectErrorStream(true);
	     Process p = builder.start();
	  	 BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
	     String line;
	     while (true) {
	         line = r.readLine();
	         if (line == null) { break; }
	         System.out.println(line);
	     }
	  }
	 
	 public void connectRQMandGetCurrentExecutionID(String webID) throws IOException {
		 
		 
		 System.out.println("the framed api call is  :::"+RQMConfigs.jarfile+RQMConfigs.getUserCmd(RQMConfigs.userName,RQMConfigs.passWord)+
	     				RQMConfigs.getFilePathCmd(RQMConfigs.responceTCName)+RQMConfigs.connectRQMAndGetCurrentExecutionID(webID));
		 
	     ProcessBuilder builder = new ProcessBuilder(
	     		new String[] {"cmd.exe", "/c",RQMConfigs.jarfile+RQMConfigs.getUserCmd(RQMConfigs.userName,RQMConfigs.passWord)+
	     				RQMConfigs.getFilePathCmd(RQMConfigs.responceTCName)+RQMConfigs.connectRQMAndGetCurrentExecutionID(webID)});
	     builder.redirectErrorStream(true);
	     Process p = builder.start();
	  	 BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
	     String line;
	     while (true) {
	         line = r.readLine();
	         if (line == null) { break; }
	         System.out.println(line);
	     }
	  }
	 
	 public void connectRQMandGetTempFile(String currentExeId) throws IOException {
		 
		 
		 System.out.println("the framed api call is  :::"+RQMConfigs.jarfile+RQMConfigs.getUserCmd(RQMConfigs.userName,RQMConfigs.passWord)+
	     				RQMConfigs.getFilePathCmd(RQMConfigs.responceTempFile)+RQMConfigs.connectRQMAndGetTempFile(currentExeId));
		 
	     ProcessBuilder builder = new ProcessBuilder(
	     		new String[] {"cmd.exe", "/c",RQMConfigs.jarfile+RQMConfigs.getUserCmd(RQMConfigs.userName,RQMConfigs.passWord)+
	     				RQMConfigs.getFilePathCmd(RQMConfigs.responceTempFile)+RQMConfigs.connectRQMAndGetTempFile(currentExeId)});
	     builder.redirectErrorStream(true);
	     Process p = builder.start();
	  	 BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
	     String line;
	     while (true) {
	         line = r.readLine();
	         if (line == null) { break; }
	         System.out.println(line);
	     }
	  }
	 
	 public void connectRQMandUpdateTestCaseStatus(String currentExeId) throws IOException {
		 
		 //java -jar "C:\\Users\\jekumar\\Desktop\\rqmIntgeration\\RQMUrlUtility\\RQMUrlUtility.jar" -command PUT -user hkhirodkar -password eatmydust@2018
		 //-filepath "C:\Users\jekumar\Desktop\testRQM\Temp.xml" -url  "https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/executionresult/urn:com.ibm.rqm:executionresult:845329"
		 
		 System.out.println("the framed api call is  :::"+RQMConfigs.jarfile+RQMConfigs.putUserCmd(RQMConfigs.userName,RQMConfigs.passWord)+
	     				RQMConfigs.getFilePathCmd(RQMConfigs.responceTempFile)+RQMConfigs.connectRQMAndUpdateTestCaseStatus(currentExeId));
		 
	     ProcessBuilder builder = new ProcessBuilder(
	     		new String[] {"cmd.exe", "/c",RQMConfigs.jarfile+RQMConfigs.putUserCmd(RQMConfigs.userName,RQMConfigs.passWord)+
	     				RQMConfigs.getFilePathCmd(RQMConfigs.responceTempFile)+RQMConfigs.connectRQMAndUpdateTestCaseStatus(currentExeId)});
	     builder.redirectErrorStream(true);
	     Process p = builder.start();
	  	 BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
	     String line;
	     while (true) {
	         line = r.readLine();
	         if (line == null) { break; }
	         System.out.println(line);
	     }
	  }
	 

}
