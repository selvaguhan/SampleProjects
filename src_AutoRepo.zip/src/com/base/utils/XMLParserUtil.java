package com.base.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;


import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XMLParserUtil {
	
	public XMLParserUtil() {
		
	}
	
	public String retrieveValueFrmResponceFile(String filepath, String tagName, int index) throws Exception {
		final DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	    docFactory.setNamespaceAware(true);
	    final DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	    final Document doc = docBuilder.parse(filepath);

	    System.out.println("the current execution tag length is :: " + doc.getElementsByTagName(tagName).getLength());
	    
	    System.out.println(" the current execution tag name text is::"+doc.getElementsByTagName(tagName).item(0).getLocalName());
	    final String text = doc.getElementsByTagName(tagName).item(index).getTextContent();
	    System.out.println("the tag value is::" + text);
	    return text;

	  }
	
	public String setTextToStateTag1(String filepath, String tagName,String tagName2,String testCaseStatus,String subRequestId, int index) throws Exception {
	    final File f = new File(filepath);
	    final DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	    docFactory.setNamespaceAware(true);
	    final DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	    final Document doc = docBuilder.parse(filepath);

	    
	    doc.getElementsByTagName(tagName).item(index).setTextContent(testCaseStatus);
	    
	    final String text1 = doc.getElementsByTagName(tagName).item(index).getTextContent();
	    System.out.println("the after chaning the state as passed::" + text1);
	    
	    doc.getElementsByTagName(tagName2).item(index).setTextContent(subRequestId);
	    
	    final String text2 = doc.getElementsByTagName(tagName2).item(index).getTextContent();
	    System.out.println("the after updating  the sub request id::" + text2);

	    
	    final TransformerFactory transformerFactory = TransformerFactory.newInstance();
	    final Transformer transformer = transformerFactory.newTransformer();
	    final DOMSource source = new DOMSource(doc);
	    final StreamResult result = new StreamResult(f);
	    transformer.transform(source, result);
	    
	    /*TransformerFactory transformerFactory = TransformerFactory.newInstance();
	    Transformer transformer = transformerFactory.newTransformer();
	    DOMSource source = new DOMSource(doc);
	    StreamResult result = new StreamResult(new File("C:\\Users\\jekumar\\Desktop\\testRQM\\Temp8.xml"));
	    transformer.transform(source, result);*/
	    
		System.out.println("Done");
	    
	    final String text = doc.getElementsByTagName(tagName).item(index).getTextContent();
	    System.out.println("the tag value is::" + text);
	    return getStringFromDocument(doc);

	  }
	
	public String setTextToStateTag(String filepath, String tagName,String testCaseStatus,int index) throws Exception {
	    final File f = new File(filepath);
	    final DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	    docFactory.setNamespaceAware(true);
	    final DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	    final Document doc = docBuilder.parse(filepath);

	    
	    doc.getElementsByTagName(tagName).item(index).setTextContent(testCaseStatus);
	    
	    final String text1 = doc.getElementsByTagName(tagName).item(index).getTextContent();
	    System.out.println("the after chaning the state as passed::" + text1);
	  
	    
	    final TransformerFactory transformerFactory = TransformerFactory.newInstance();
	    final Transformer transformer = transformerFactory.newTransformer();
	    final DOMSource source = new DOMSource(doc);
	    final StreamResult result = new StreamResult(f);
	    transformer.transform(source, result);
	    
	    /*TransformerFactory transformerFactory = TransformerFactory.newInstance();
	    Transformer transformer = transformerFactory.newTransformer();
	    DOMSource source = new DOMSource(doc);
	    StreamResult result = new StreamResult(new File("C:\\Users\\jekumar\\Desktop\\testRQM\\Temp8.xml"));
	    transformer.transform(source, result);*/
	    
		System.out.println("Done");
	    
	    final String text = doc.getElementsByTagName(tagName).item(index).getTextContent();
	    System.out.println("the tag value is::" + text);
	    return getStringFromDocument(doc);

	  }
	
	 public String getStringFromDocument(Document doc) throws ParserConfigurationException {
		    try {

		      final DOMSource domSource = new DOMSource(doc);
		      final StringWriter writer = new StringWriter();
		      final StreamResult result = new StreamResult(writer);
		      final TransformerFactory tf = TransformerFactory.newInstance();
		      final Transformer transformer = tf.newTransformer();
		      transformer.transform(domSource, result);
		      return writer.toString();
		    } catch (final TransformerException ex) {
		      ex.printStackTrace();
		      return null;
		    }
		  }
	
	 public void writeFile(String yourXML){
		    BufferedWriter out = null;
			try {
				out = new BufferedWriter(new FileWriter("C:\\Users\\jekumar\\Desktop\\testRQM\\abc.txt"));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    try { 
		        out.write(yourXML);
		    } catch (IOException e) {
		        e.printStackTrace();
		    } finally {
		        try {
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    }
		}
	 
	public String retrieveValueFrmResponceFileWithAttribute(String filepath, String tagName, String testPlanId) throws Exception {
		final DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	    docFactory.setNamespaceAware(true);
	    
	    final DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	    final Document doc = docBuilder.parse(filepath);

	    
	    String temp,temp1= null;
	    
	    String temp2 = null;
	   
	    System.out.println("the current test plan id ::"+doc.getElementsByTagName("ns2:testplan"));
	    
	    NodeList testPlanNodeList = doc.getElementsByTagName("ns2:testplan");
	    
	    System.out.println("temp node list length::"+testPlanNodeList.getLength());
	    
	    for (int count = 0; count < testPlanNodeList.getLength(); count++) {

			Node tempNode = testPlanNodeList.item(count);
			

			// make sure it's element node.
			if (tempNode.getNodeType() == Node.ELEMENT_NODE) {

				if (tempNode.hasAttributes()) {

					// get attributes names and values
					NamedNodeMap nodeMap = tempNode.getAttributes();

					for (int i = 0; i < nodeMap.getLength(); i++) {

						Node node = nodeMap.item(i);
										
						temp =node.getNodeValue();
						if(temp.contains("testplan:"+testPlanId)) {
							System.out.println("attr value : " + node.getNodeValue());
							temp1 =node.getNodeValue();
							System.out.println("the  am in test plan node and value"+temp1);
							
							Node configurationNode =tempNode.getNextSibling();
							System.out.println(":::pointing to the configuration node::::" + configurationNode.getNodeName());
							
							Node currentExeNode =configurationNode.getNextSibling();
							System.out.println(":::::current execution node:::::::" + currentExeNode.getNodeName());
							NamedNodeMap currentExeNodeMap = currentExeNode.getAttributes();
							Node currExeNode = currentExeNodeMap.item(0);
							System.out.println(":::current execution id::::" + currExeNode.getNodeValue());
							temp2=currExeNode.getNodeValue();
							
						}
						
						
					}

				}
			}
			
	    }
	    	    
	    String[] str = temp2.split(":");
	    String currentExeId = str[str.length-1];
	    return currentExeId;

	  }
	
	 public void test(String fileName) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
		// This will reference one line at a time
	        String line = null;

	        try {
	            // FileReader reads text files in the default encoding.
	            FileReader fileReader = 
	                new FileReader(fileName);

	            // Always wrap FileReader in BufferedReader.
	            BufferedReader bufferedReader = 
	                new BufferedReader(fileReader);

	            while((line = bufferedReader.readLine()) != null) {
	                System.out.println(line);
	            }   

	            // Always close files.
	            bufferedReader.close();         
	        }
	        catch(FileNotFoundException ex) {
	            System.out.println(
	                "Unable to open file '" + 
	                fileName + "'");                
	        }
	        catch(IOException ex) {
	            System.out.println(
	                "Error reading file '" 
	                + fileName + "'");                  
	            // Or we could just do this: 
	            // ex.printStackTrace();
	        }
	    }
	 
	
	 private static void printNote(NodeList nodeList) {

		    for (int count = 0; count < nodeList.getLength(); count++) {

			Node tempNode = nodeList.item(count);

			// make sure it's element node.
			if (tempNode.getNodeType() == Node.ELEMENT_NODE) {

				// get node name and value
				System.out.println("\nNode Name =" + tempNode.getNodeName() + "ns2:currentexecutionresult ");
				//System.out.println("Node Value =" + tempNode.getTextContent());

				if (tempNode.hasAttributes()) {

					// get attributes names and values
					NamedNodeMap nodeMap = tempNode.getAttributes();

					for (int i = 0; i < nodeMap.getLength(); i++) {

						Node node = nodeMap.item(i);
						System.out.println("attr name : " + node.getNodeName());
						System.out.println("attr value : " + node.getNodeValue());

					}

				}

				if (tempNode.hasChildNodes()) {

					// loop again if has child nodes
					printNote(tempNode.getChildNodes());

				}

				System.out.println("Node Name =" + tempNode.getNodeName() + " [CLOSE]");

			}

		    }

		  }

		}
	
	/*public String test(String filepath, String tagName) throws ParserConfigurationException, SAXException, IOException {
		
		final DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	    docFactory.setNamespaceAware(true);
	    final DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	    final Document doc = docBuilder.parse(filepath);
		
		 final int staff1 = doc.getElementsByTagName(tagName).getLength();
		 System.out.println("the node length is ::"+staff1);
		 final String text = doc.getElementsByTagName(tagName).item(staff1-0).getTextContent();
		 
		 System.out.println("the centent of the last node ::"+text);
		 
	    String text;
		 
		 final Node staff1 = doc.getElementsByTagName(tagName).item(0);
		    final NodeList list = staff1.getChildNodes();

		    for (int i = 0; i < list.getLength(); i++) {
		      final Node node = list.item(i);
		      
		      if ("ns2:currentexecutionresult".equals(node.getNodeName())) {
		        node.setTextContent(opexpressStatus);
		      }
		      
		    }
		 
		 return text;
	}*/


