package com.base.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.automation.configs.BaseAutoConfigs;


public class PropUtils extends BaseAutoConfigs{
	
	

    Properties properties = new Properties();
    final String fileName = "Automation.properties";
    final File currentDirectory = new File(new File("").getAbsolutePath());
    final String WORKING_DIR = currentDirectory.getAbsolutePath();
    public static String exeEnv = System.getProperty("env");
    public static String tenant = System.getProperty("tenant");
    public static String FILE_SEPARATOR = "/";
    
    public PropUtils() {    	
    }
    

    public void loadPropFile(File file, PropUtils propUtils) {
    	
    	if (!(new File(WORKING_DIR + "" + File.separator + "src" + File.separator + "resources" + File.separator + "Suites"
    	        + File.separator + "env_configs" + File.separator + fileName).exists())) {
    	      System.out
    	          .println("ERROR:There is no environment property file.Please specify the correct environment");
    	    }
    	    try {
				properties.load(new FileInputStream(new File(WORKING_DIR + File.separator + "src" + File.separator + "resources"
				    + File.separator + "Suites" + File.separator + "env_configs" + File.separator + fileName)));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	    
    	    if (exeEnv == null) {
    	      setEnvironment(properties.getProperty("Environment"));
    	   
    	    } else {
    	      setEnvironment(exeEnv);
    	    }
    	    

    	    

    	    // restApiUrl = properties.getProperty("application.url");

    	    if (!(new File(WORKING_DIR + File.separator + "" + File.separator + "src" + File.separator + "resources"
    	        + File.separator + "Environments" + File.separator + "" + getEnvironment() + ".properties").exists())) {
    	      System.out.println("ERROR:There is no environment property file named " + getEnvironment()
    	          + ".Please specify the correct environment");
    	    }
    	    
    	    try {
				properties.load(new FileInputStream(new File(WORKING_DIR + File.separator + "" + File.separator + "src" + File.separator
				        + "resources" + File.separator + "Environments" + File.separator + "" + getEnvironment() + ".properties")));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	 
    	    setApplication_url(properties.getProperty("application.url"));
    	    
    	    setBrowserType(properties.getProperty("BrowserType"));
    	    setDbName(properties.getProperty("application.dbname"));
    	    setDbSID(properties.getProperty("application.SID"));
    	    setDbUserId(properties.getProperty("application.username"));
    	    setDbPassword(properties.getProperty("application.password"));
    	    setDbLocalHost(properties.getProperty("application.localhost"));
    	    setDbPort(properties.getProperty("application.port"));
    	    
    	    setCssRc_dbName(properties.getProperty("application.CssRc_dbname"));
    	    setCssRc_dbSID(properties.getProperty("application.CssRc_SID"));
    	    setCssRc_dbUserId(properties.getProperty("application.CssRc_username"));
    	    setCssRc_dbPassword(properties.getProperty("application.CssRc_password"));
    	    setCssRc_dbLocalHost(properties.getProperty("application.CssRc_localhost"));
    	    setCssRc_dbPort(properties.getProperty("application.CssRc_port"));

    	    setDatafile_Location(WORKING_DIR + File.separator + "src" + File.separator + "resources" + File.separator + "Suites"
    	        + File.separator + "testdata");
     	   
    	     
    	  

    }
    
    
  

}
