package com.base.utils;

import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.automation.configs.WaitConfigs;
import com.cbcm.main.pages.HomePage;
import com.cbcm.main.pages.LoginPage;
import com.main.loggers.TestLoggers;





public class BaseTest {
	
	private  WebDriver driver;
	
	private JavascriptExecutor js ;
	public Actions buider;
	private HomePage homePage;
	
	PropUtils propUtils = new PropUtils();
	TestLoggers testLoggers = new TestLoggers(propUtils);
	DBUtilities dbUtil = new DBUtilities(propUtils);
	
	private SoftAssert softAssert = new SoftAssert();
	
	private ITestResult result;
	
	public ITestResult getCurrentTestCaseResult() {
		result = Reporter.getCurrentTestResult();
		return result;
	}
	
	public SoftAssert getSoftAssert() {
		return softAssert;
	}
	
	public DBUtilities getDBUtilities() {
		return dbUtil;
	}
	public  WebDriver getDriver() {
		return driver;
	}
	
	public JavascriptExecutor getJavaScriptExecutor() {
		js =(JavascriptExecutor)driver;	
		return js;
	}
	
	public PropUtils getPropUtils() {
		return new PropUtils();
	}
	
	public Actions getActions() {
		buider = new Actions(driver);
		return buider;
	}

	public  BasePage getBasePage() {
		return new BasePage(getDriver());
	}
	
	public HomePage getHomePage() {
		return homePage;
	}
	
	public WaitUtil getWaitUtil() {
		return new WaitUtil(getDriver());
	}
	
	


	/*public  WebDriver launchBrowser()    {
		try {
	    final DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
	    cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	    System.setProperty("webdriver.ie.driver", "D://jeevan//softwares//iedriver//IEDriverServer.exe");
	    cap.setBrowserName(DesiredCapabilities.internetExplorer().getBrowserName());
	    cap.setPlatform(Platform.VISTA);
	    driver = new InternetExplorerDriver(cap);
	    driver.manage().deleteAllCookies();
	    System.out.println("Launching browser");
	    driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
	    driver.get("http://au938:7005/cbcm/jsp/security/login/Login.jsp");
	    driver.manage().window().maximize();
	    Thread.sleep(400);
	    getBasePage().safeType(By.xpath("//input[contains(@id,'usernameforshow')]"), "regressioncrc");
	    getBasePage().safeType(By.xpath("//input[contains(@id,'passwordforshow')]"), "password@123");
	    getBasePage().safeClick(By.xpath("//input[contains(@class,'login-button')]"));
	    Thread.sleep(4000);
	    final String Parent_Window = driver.getWindowHandle();
	    final Set<String> a = driver.getWindowHandles();
	    System.out.println("The Size of Windows is " + a.size() + " and id is " + a);
	    Reporter.log("************The Size of Windows is ****************" + a.size() + " and id is " + a);
	    Reporter.log("************The total window handles ********************" + a);
	    System.out.println(a.size());
	    Thread.sleep(2000);
	    String chwindow = null;
	    for (final String Child_Window : a) {
	      if (!Child_Window.equalsIgnoreCase(Parent_Window)) {

	        chwindow = Child_Window;
	      }

	    }
	    //driver.switchTo().window(chwindow).manage().window().maximize();
	    driver.switchTo().window(chwindow);
	    driver.findElement(By.xpath("//body")).click();
	    Thread.sleep(1000);
	    System.out.println(driver.getTitle());
		driver.findElement(By.name("close")).click();
	    Thread.sleep(1000);
	    driver.switchTo().window(Parent_Window);
	    System.out.println(driver.getTitle());
	    System.out.println("driver is switched to parent window");
		Thread.sleep(2000);
	    Reporter.log("The Driver Instance is " + driver);
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("unable to create driver instance==>"+e);
		}
	    	
	    
	    return driver;
	  }*/
	
	
	public  WebDriver launchBrowser()    {
		try {
	   // final DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
	  /*  cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	    cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
	    cap.setCapability(InternetExplorerDriver.NATIVE_EVENTS,false);*/
	    //cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	    System.setProperty("webdriver.ie.driver", "D://jeevan//softwares//iedriver//IEDriverServer.exe");
	    
	    DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
        ieCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
        ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
        ieCapabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);  
        //ieCapabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS,false);
       ieCapabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.DISMISS);
//Accept unexpected alerts
        ieCapabilities.setCapability("requireWindowFocus", true);
        ieCapabilities.setCapability("enablePersistentHover", false);
        
	   /* cap.setBrowserName(DesiredCapabilities.internetExplorer().getBrowserName());
	    cap.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
	    cap.setPlatform(Platform.WINDOWS);*/
	    driver = new InternetExplorerDriver(ieCapabilities);
	    driver.manage().deleteAllCookies();
	    System.out.println("Launching browser" + propUtils.getApplication_url());
	    driver.get(propUtils.getApplication_url());
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(WaitConfigs.implictWaitTime, TimeUnit.SECONDS);
	    }catch (Exception e) {
			System.out.println("unable to create driver instance==>"+e);
		}
	    	
	    
	    return driver;
	  }
	
	public  WebDriver launchElifeApplication()    {
		try {
	  
	    System.setProperty("webdriver.ie.driver", "D://jeevan//softwares//iedriver//IEDriverServer.exe");
	    
	    DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
        ieCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
        ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
        ieCapabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);  
       ieCapabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.DISMISS);
       //Accept unexpected alerts
        ieCapabilities.setCapability("requireWindowFocus", true);
        ieCapabilities.setCapability("enablePersistentHover", false);
   
	    driver = new InternetExplorerDriver(ieCapabilities);
	    driver.manage().deleteAllCookies();
	    //System.out.println("Launching browser" + propUtils.getApplication_url());
	    driver.get("http://cbcmrc.etisalat.corp.ae:7779/eLife/RedirectServlet?username=jeevaneliferc&roles=elifeRoletoLinkCanlReqId,PassportReaderSuperRole,bypasInstElifeRole");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(WaitConfigs.implictWaitTime, TimeUnit.SECONDS);
	    }catch (Exception e) {
			System.out.println("unable to create driver instance==>"+e);
		}
	    	
	    
	    return driver;
	  }
	
	public  WebDriver launchComApp()    {
		try {
	    final DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
	    cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	    System.setProperty("webdriver.ie.driver", "D://jeevan//softwares//iedriver//IEDriverServer.exe");
	    cap.setBrowserName(DesiredCapabilities.internetExplorer().getBrowserName());
	    cap.setPlatform(Platform.VISTA);
	    driver = new InternetExplorerDriver(cap);
	    driver.manage().deleteAllCookies();
	    System.out.println("Launching browser" + "http://10.37.165.11:7016/COMS_Admin/faces/login/login.xhtml");
	    driver.get(propUtils.getApplication_url());
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(WaitConfigs.implictWaitTime, TimeUnit.SECONDS);
	    
	    
	    }catch (Exception e) {
			System.out.println("unable to create driver instance==>"+e);
		}
	    	
	    
	    return driver;
	  }
	
	
	public WebDriver launchFFBrowser() {
		 
		try {
			 	
			 	 System.setProperty("webdriver.gecko.driver", "D://jeevan//geckodriver-v0.20.1-win32//geckodriver.exe");
		        
			 	 DesiredCapabilities capabilities = new DesiredCapabilities();

			 	 capabilities = DesiredCapabilities.firefox();
			 	 capabilities.setBrowserName("firefox");
			 	 capabilities.setVersion("47.0.2");
			 	 capabilities.setPlatform(Platform.WINDOWS);
			 	 capabilities.setCapability("marionette", false);

		         driver = new FirefoxDriver(capabilities);
		        
		         driver.manage().deleteAllCookies();
		         driver.manage().window().maximize();
		        
		         System.out.println("Launching firfox browser");
		        
		      } catch (final Exception e) {
		        System.out.println(" Caught Exception in the launching Firefox browser" + e);
		      }
		 return driver;
	}
	
	public WebDriver launchChromeBrowser() {
		
		System.setProperty("webdriver.chrome.driver", "D://jeevan//softwares//chromedriver_win32//chromedriver_win32//chromedriver.exe");
		
	/*	final org.openqa.selenium.chrome.ChromeOptions options = new org.openqa.selenium.chrome.ChromeOptions();
		//options.addExtensions(new File("/path/to/extension.crx"));
        options.addArguments("--disable-web-security");
        options.addArguments("--allow-running-insecure-content");
        options.addArguments("--disable-extensions");
        options.addArguments("test-type");
        options.addArguments("--start-maximized");
        driver = new ChromeDriver(options);*/
        
		driver = new ChromeDriver();
		driver.get("https://10.37.247.91:8080/fsm/login.page");
		driver.manage().window().maximize();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return driver;
	}
	
	 public HomePage login(String username,String password) {
		    System.out.println("Login with username  :\t" + username+"the password is ==>"+password);
		    //getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		    homePage = new LoginPage(getDriver()).login(username,password);
		    return homePage;
	}
	
	public void  windowHandle() {
		try {
			Thread.sleep(1000);
			final String Parent_Window = driver.getWindowHandle();
		    final Set<String> a = driver.getWindowHandles();
		    System.out.println("The Size of Windows is " + a.size() + " and id is " + a);
		    Reporter.log("************The Size of Windows is ****************" + a.size() + " and id is " + a);
		    Reporter.log("************The total window handles ********************" + a);
		    System.out.println(a.size());
		    Thread.sleep(1000);
		    String chwindow = null;
		    for (final String Child_Window : a) {
		      if (!Child_Window.equalsIgnoreCase(Parent_Window)) {

		        chwindow = Child_Window;
		      }

		    }
		    driver.switchTo().window(chwindow);
		    driver.findElement(By.xpath("//body")).click();
		    Thread.sleep(500);
		    System.out.println(driver.getTitle());
		    Reporter.log("****the child  window title******" + driver.getTitle());
			driver.findElement(By.name("close")).click();
		    Thread.sleep(1000);
		    driver.switchTo().window(Parent_Window);
		    System.out.println(driver.getTitle());
		    Reporter.log("****the parent window title******" + driver.getTitle());
		    Reporter.log("****switched to parent window******");
			Thread.sleep(2000);
			
		}catch (Exception e) {
			System.out.printf("unable to switch window"+e.getStackTrace());
		}
	}
	
	
	public String switchToWindow() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Set<String> allHandles1 = driver.getWindowHandles();     
		String currentWindowHandle1 = allHandles1.iterator().next();
	    System.out.println("the current window handle is ==>"+currentWindowHandle1);
	    
	    allHandles1.remove(allHandles1.iterator().next());
	    
	    String lastHandle1 = allHandles1.iterator().next();
	    
	    System.out.println("the child window id==:"+lastHandle1);
	    
	    driver.switchTo().window(lastHandle1);
	    System.out.println("the child window title==>"+getDriver().getTitle());
	    //getBasePage().getWaitUtils().elementPresence(By.xpath("//body"),30);
	    
	    //WebElement value = (WebElement) ((JavascriptExecutor) getDriver()).executeScript("return document.evaluate( '//body' ,document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;");
	    
	    //WebElement body = null;
	    //body = (WebElement) ((JavascriptExecutor) getDriver()).executeScript("return document.getElementsByTagName('body');", body);
	   // getBasePage().clickOnElementByJavaScriptExecutor(By.xpath("//body"));
	    //driver.findElement(By.xpath("//body")).click();
	    //((JavascriptExecutor) driver).executeScript("window.focus();");
		
	    try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return currentWindowHandle1;
	}
	
	public String switchToWindow1() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Set<String> allHandles1 = driver.getWindowHandles();     
		String currentWindowHandle1 = allHandles1.iterator().next();
	    System.out.println("the current window handle is ==>"+currentWindowHandle1);
	    
	    allHandles1.remove(allHandles1.iterator().next());
	    
	    String lastHandle1 = allHandles1.iterator().next();
	    
	    System.out.println("the child window id==:"+lastHandle1);
	    
	    driver.switchTo().window(lastHandle1);
	    //((JavascriptExecutor) driver).executeScript("window.focus();");
		System.out.println("the child window title==>"+getDriver().getTitle());
	    try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return currentWindowHandle1;
	}
	
	  public static void captureScreenshot(WebDriver driver,String screenshotname) {
		    try {
		      final String timestamp = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
		      final String timeStamp1 = (timestamp.replaceAll("/", "_")).replaceAll(":", "_").replace(" ", "_");
		      final TakesScreenshot screenshot = (TakesScreenshot)driver;

		      final File source = screenshot.getScreenshotAs(OutputType.FILE);

		      FileUtils.copyFile(source, new File("./Screenshots/"+ screenshotname + timeStamp1 + ".png"));

		      System.out.println("Screenshot Taken");

		    } catch (final Exception excep) {
		      System.out.println("Throwing exception while taking screenshot" + excep.getMessage());
		    }

		  }
	  
	  
	  public void quiteIeBrowser() {
		  final Runtime rt = Runtime.getRuntime();
			try {
			Process p = rt.exec("C:\\Users\\jekumar\\Desktop\\ieclose\\ieClose.bat"); 
			} catch (final IOException e) {
			throw new RuntimeException("Failed to run bat file.");
			}
	  }
	  
	  public void mouseOver(By by) {
		  getActions().moveToElement(getDriver().findElement(by)).build().perform();
	  }
	  
	  public ArrayList<Integer> getWindowSize() {
		  ArrayList<Integer> windowSize = new ArrayList<Integer>();
		  Toolkit toolkit = Toolkit.getDefaultToolkit();
		  int width = (int) toolkit.getScreenSize().getWidth();
		  int height = (int)toolkit.getScreenSize().getHeight();
		  windowSize.add(width);
		  windowSize.add(height);
		  return windowSize;
	  }
	  
	  private Test testAnotation = null;
	  
	  @AfterMethod(alwaysRun = true)
	  public void afterMethod(ITestContext c, Method m, ITestResult itr) {
  
	    try {

	      final Method[] methods = this.getClass().getMethods();
	      for (final Method m1 : methods) {
	        if (m1.isAnnotationPresent(Test.class)) {
	          testAnotation = m1.getAnnotation(Test.class);
	          System.out.println(testAnotation.testName());
	        }
	      }

	      
	    } catch (final Exception e) {
	      e.printStackTrace();
	    }

	    if (itr.getStatus() == 1) {
	        itr.setStatus(ITestResult.SUCCESS);
	    } else {
	        itr.setStatus(ITestResult.FAILURE);
	    }
	    
	    if (ITestResult.FAILURE == itr.getStatus()) {
	      captureScreenshot(driver, itr.getName());
	    }
	  }
	  
	  public void windowMaximize(int width,int height) {
		  getDriver().manage().window().setSize(new Dimension(width,height));
	  }
	  
	  String testScrptName;
	  public String getTestScriptName() {
		  
			String className = getClass().getName();
			System.out.println(className);
			String[] tcName=className.split("\\.");
			testScrptName=tcName[tcName.length-1];
			System.out.println("the test script name is ::"+testScrptName);
			return testScrptName;
		  
	  }
	
}
