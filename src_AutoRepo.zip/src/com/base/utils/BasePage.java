package com.base.utils;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.automation.configs.WaitConfigs;
import com.main.loggers.TestLoggers;

public class BasePage {
	WebDriver driver;
	Actions buider;
	WaitUtil waitUtils;
	
	PropUtils propUtils = new PropUtils();
	TestLoggers testLoggers = new TestLoggers(propUtils);
	
	public BasePage(WebDriver driver) {
		this.driver=driver;
		buider = new Actions(driver);
		
	}
	
	public WebDriver getDriver() {
		return driver;
	}
	public Actions getActions() {
		return buider;
	}
	
	public WaitUtil getWaitUtils() {
		return new WaitUtil(getDriver());
	}
	
	public PropUtils getPropUtils() {
		return propUtils;
	}
	
	public void safeClick(By by) {
	    final WebDriverWait wait = new WebDriverWait(driver, WaitConfigs.elementVisibleWait);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	    getDriver().findElement(by).click();
	   }

	  public void safeClear(By by) {
	    final WebDriverWait wait = new WebDriverWait(driver, WaitConfigs.elementVisibleWait);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	    getDriver().findElement(by).clear();
	  }

	  public void safeType(By by, String Data) {
	    final WebDriverWait wait = new WebDriverWait(driver, WaitConfigs.elementVisibleWait);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	    getDriver().findElement(by).clear();
	    getDriver().findElement(by).sendKeys(Data);
/*	    //getActions().moveToElement(getDriver().findElement(by)).sendKeys(Data).build().perform();
	    WebElement wb = driver.findElement(by);
	    JavascriptExecutor jse = (JavascriptExecutor)driver;
	    jse.executeScript("arguments[0].value='"+Data+"';", wb);*/
	   /* try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	  }
	  
	  public boolean isElementDisplayed(By by) {
		  try {
		    driver.findElement(by);
		    return true;
		  }
		catch (org.openqa.selenium.NoSuchElementException e) {
		    return false;
		  }
		}
	  
	  public void onChangeEventFire(By by) {
		  WebElement wb = driver.findElement(by);
		  try {
			  JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			  jsExecutor.executeScript("$(arguments[0]).change();", wb);
			  Thread.sleep(100);
		  }catch (Exception e) {
			  System.out.println("the exception in the event handle method::"+e);
		}
		  
	  }
	  
	  public void onBlurEventFire(By by) {
		  WebElement wb = driver.findElement(by);
		  try {
			  JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			  jsExecutor.executeScript("$(arguments[0]).blur();", wb);
		  }catch (Exception e) {
			  System.out.println("the exception in the event handle method::"+e);
		}
		  
	  }
	  
	  public void onFocusEventFire(By by) {
		  WebElement wb = driver.findElement(by);
		  try {
			  JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			  jsExecutor.executeScript("$(arguments[0]).onfocus();", wb);
		  }catch (Exception e) {
			  System.out.println("the exception in the event handle method::"+e);
		}
		  
	  }
	  
	  public void onClickEventFire(By by) {
		  WebElement wb = driver.findElement(by);
		  try {
			  JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			  jsExecutor.executeScript("$(arguments[0]).onclick();", wb);
		  }catch (Exception e) {
			  System.out.println("the exception in the event handle method::"+e);
		}
		  
	  }
	  
	  public void onMouseOverEventFire(By by) {
		  WebElement wb = driver.findElement(by);
		  try {
			  JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			  jsExecutor.executeScript("$(arguments[0]).onmouseover();", wb);
		  }catch (Exception e) {
			  System.out.println("the exception in the event handle method::"+e);
		}
		  
	  }
	  
	  
	  public void waitForAjaxLoad(WebDriver driver) throws InterruptedException{
		    JavascriptExecutor executor = (JavascriptExecutor)driver;
		    if((Boolean) executor.executeScript("return window.jQuery != undefined")){
		        while(!(Boolean) executor.executeScript("return jQuery.active == 0")){
		            Thread.sleep(4000);
		        }
		    }
		    return;
		}
	  
	  public void typeText(By by, String Data) {
		 
		    getDriver().findElement(by).clear();
		    getDriver().findElement(by).sendKeys(Data);
		    
	  }
	  
	  public String getText(By by) {
			    
		    String eidNo=getDriver().findElement(by).getText();
		    return eidNo;
		    
	  }
	  
	  public void typeTextViaAction(By by, String Data) {
			 
		  	getDriver().findElement(by).clear();
		    getActions().moveToElement(getDriver().findElement(by)).sendKeys(Data).build().perform();
		    
	  }
	  public void typeValueByJavaScript(String tagName,String data) {
		  final JavascriptExecutor executor = (JavascriptExecutor) getDriver();
		  executor.executeScript("document.getElementById('"+tagName+"').value = '"+data+"';");
	  }
	 public String multipleWindowHandle() {
		 
		 	Set<String> allHandles = driver.getWindowHandles();     
			System.out.println("the all window handles==>"+allHandles);
		    String currentWindowHandle = allHandles.iterator().next();
		    System.out.println("the current window handle is ==>"+currentWindowHandle);
		    
		    allHandles.remove(allHandles.iterator().next());
		    
		    String lastHandle = allHandles.iterator().next();
		    
		    System.out.println("the child window handle==>"+lastHandle);
		    
		    driver.switchTo().window(lastHandle);
		    driver.findElement(By.xpath("//body")).click();
		    //((JavascriptExecutor) driver).executeScript("window.focus();");
		   
		    return currentWindowHandle;
		 
	 }
	 
	 public void switchWindow(){
		 
		 Set<String> allHandles = driver.getWindowHandles();     
			System.out.println("the all window handles==>"+allHandles);
		    String currentWindowHandle = allHandles.iterator().next();
		    System.out.println("the current window handle is ==>"+currentWindowHandle);
		    
		    allHandles.remove(allHandles.iterator().next());
		    
		    String lastHandle = allHandles.iterator().next();
		    
		    System.out.println("the child window handle==>"+lastHandle);
		    
		    driver.switchTo().window(lastHandle);
		    driver.findElement(By.xpath("//body")).click();
		    //((JavascriptExecutor) driver).executeScript("window.focus();");
		    
		    try {
				Thread.sleep(2000);
				 System.out.println(driver.getTitle());
				 driver.findElement(By.name("close")).click();
				 driver.switchTo().window(currentWindowHandle);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   
		    
	 }
	 
	 public void  switchwindowback(String parentWindowID){
         try {
             //String winHandleBefore = driver.getWindowHandle();
             System.out.println("the parent wind===>"+parentWindowID);
             driver.close(); 
             //Switch back to original browser (first window)
             driver.switchTo().window(parentWindowID);
             driver.findElement(By.xpath("//body")).click();
             
             //continue with original browser (first window)
         }catch(Exception e){
        	 System.out.println("unable to switch to window");
         }
        
         }
	 
	 
	 public void windowSwitch(String windowId) {
		 getDriver().switchTo().window(windowId);
		 
		 try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 
	 public void frameSwitch(String frameId) {
		 getDriver().switchTo().parentFrame();
		 getDriver().switchTo().frame(frameId);
		 
	 }
	 
	 public void clickElementUsingJavaScript(By locator) {
		    final JavascriptExecutor executor = (JavascriptExecutor) getDriver();
		    executor.executeScript("arguments[0].click();", getDriver().findElement(locator));
		   /* try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		  }
	 
	 public void selectValueFromDropDownByVisibleText(By locatorName, String valueToBeSelect) throws RuntimeException {
		    try {
		    	 Select paymentTypeSclt = new Select(driver.findElement(locatorName));
					paymentTypeSclt.selectByVisibleText(valueToBeSelect);
					Thread.sleep(500);
		    } catch (final Exception e) {
		      System.out.println("Error Occured in method 'selectValueFromDropDownByVisibleText' due to " + e);
		       e.printStackTrace();
		    }
	 }
	 
	 public void selectValueFromDropDownByIndex(By locatorName, String valueToBeSelect) throws RuntimeException {
		    try {
		    	 Select paymentTypeSclt = new Select(driver.findElement(locatorName));
					paymentTypeSclt.selectByIndex(1);
					Thread.sleep(500);
		    } catch (final Exception e) {
		      System.out.println("Error Occured in method 'selectValueFromDropDownByVisibleText' due to " + e);
		       e.printStackTrace();
		    }
	 }
	 
	 public void switchFrame(String frameName) {
		 getDriver().switchTo().defaultContent();
		 getDriver().switchTo().frame(frameName);
	 }
	 
	 public void clickByWebElement(By locator) {
		 	WebElement element = driver.findElement(locator);
		    element.click();
		    try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("unable to scoll element into view:==>"+e);
				e.printStackTrace();
			}
	 }

	 public void clickOnElementAndTabKey(By locator) {

		 
		 WebElement element = driver.findElement(locator);
		 element.click();

		 element.sendKeys(Keys.TAB);
		
		 //element.sendKeys(Keys.chord(Keys.CONTROL, "296892232"));
		 //element.sendKeys(Keys.TAB);
		 try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				System.out.println("unable to scoll element into view:==>"+e);
				e.printStackTrace();
			}
     }
	 
	 public void clickOnTabKey(By locator) {
		 WebElement element = driver.findElement(locator);
		 element.sendKeys(Keys.TAB);
     }
	 
	 public void switchToParentAndChildFrame(String parentFrame,String childFrame) {
		 driver.switchTo().defaultContent();
		 driver.switchTo().frame(parentFrame).switchTo().frame(childFrame);
	 }
	 
	 public void scrollIntoViewTillElement(By locator) {
		 ((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView();", getDriver().findElement(locator));
		 try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			System.out.println("unable to scoll element into view:==>"+e);
			e.printStackTrace();
		}
	 }
	 
	 //jse.executeScript("window.scrollBy(0,250)", "");
	 
	 public void pageScrollDown() {
		 
		 ((JavascriptExecutor)getDriver()).executeScript("window.scrollBy(0,500)", "");
	 }
	 
	public void clickOnElementByActions(By locator) {
		buider.moveToElement(driver.findElement(locator)).click().build().perform();
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			System.out.println("unable to scoll element into view:==>"+e);
			e.printStackTrace();
		}
	}
	
	public void clickOnElementByJavaScriptExecutor(By locator) {
		 ((JavascriptExecutor)getDriver()).executeScript("arguments[0].click();", driver.findElement(locator));
		 try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("unable to scoll element into view:==>"+e);
				e.printStackTrace();
			}
	}
	
	public void clickOnWebElementByJavaScriptExecutor(WebElement locator) {
		 ((JavascriptExecutor)getDriver()).executeScript("arguments[0].click();", locator);
	}
	
	public void scroll1(By locator) {
	    
	    getActions().sendKeys(Keys.PAGE_DOWN);
	    getWaitUtils().waitForPage(10);
	    clickOnElementByActions(locator);
	  }
	
	public String getAttributeValue(By by,String attribute) {
		String attributeValue=getDriver().findElement(by).getAttribute(attribute);
		return attributeValue;
	}
}
