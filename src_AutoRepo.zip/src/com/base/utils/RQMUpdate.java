package com.base.utils;

import org.testng.ITestResult;

import com.automation.configs.RQMConfigs;

public class RQMUpdate {
	
	
	static RQMUtils rqmUtils = new RQMUtils();
	static XMLParserUtil xmlParserUtil = new XMLParserUtil();
	
	public static void updateTestCaseStatusIntoRQM(String testScrptName,ITestResult result,String testPlan) {

		
		try {
			rqmUtils.connectRQMandGetTestCaseName(testScrptName);
			String webId = xmlParserUtil.retrieveValueFrmResponceFile(RQMConfigs.resFilePath+RQMConfigs.responceTCName,RQMConfigs.webIdTag,0);
			System.out.println("the parsed xml tag value::"+webId);
			
			rqmUtils.connectRQMandGetCurrentExecutionID(webId);
			
			String currentExecutionId=xmlParserUtil.retrieveValueFrmResponceFileWithAttribute(RQMConfigs.resFilePath+RQMConfigs.responceTCName,
					 RQMConfigs.currentExecutionTag,"6487");
			System.out.println("the parsed current execution id xml tag value::"+currentExecutionId);
				 
			rqmUtils.connectRQMandGetTempFile(currentExecutionId);
			
			String stateValue = xmlParserUtil.retrieveValueFrmResponceFile(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,RQMConfigs.stateTagName,0);
			System.out.println("current status of the Test Cases::"+stateValue);
			
			String subRequestId = xmlParserUtil.retrieveValueFrmResponceFile(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,RQMConfigs.actualResultTag,0);
			System.out.println("sub request id::"+subRequestId);
			
			
			
			//rqmUtils.connectRQMandUpdateTestCaseStatus(currentExecutionId);
			// String passed = xmlParserUtil.setTextToStateTag(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,RQMConfigs.stateTagName,RQMConfigs.actualResultTag,RQMConfigs.passedState,"498127295",0);
			 //System.out.println("i am in passed switch block::"+passed);
			
			/*if(stateValue.contains("passed")) {
				String inprogress = xmlParserUtil.setTextToStateTag(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,RQMConfigs.stateTagName,RQMConfigs.inProgressState,0);
				System.out.println("the after making inprogress::"+inprogress);
			}
			
			if(result.getStatus() == ITestResult.SUCCESS)
		    {

		        //Do something here
		        System.out.println("passed **********");
		        //String passed = xmlParserUtil.setTextToStateTag(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,RQMConfigs.stateTagName,RQMConfigs.passedState,0);
		        String passed = xmlParserUtil.setTextToStateTag1(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,RQMConfigs.stateTagName,RQMConfigs.actualResultTag,RQMConfigs.passedState,"Request Number - 498127298",0);
				System.out.println("i am in passed switch block::"+passed);
		    }

		    else if(result.getStatus() == ITestResult.FAILURE)
		    {
		         //Do something here
		        System.out.println("Failed ***********");
		        String failed = xmlParserUtil.setTextToStateTag(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,RQMConfigs.stateTagName,RQMConfigs.failedState,0);
		   		System.out.println("i am in failed switch block::"+failed);

		    }
			
			rqmUtils.connectRQMandUpdateTestCaseStatus(currentExecutionId);*/
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
