package com.base.utils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import com.automation.configs.DBQuerryConstants;

public class CBCMDbHelperClass extends BaseTest{
	
	ResultSet rs;
	public CBCMDbHelperClass() {
		
	}
	
	public ArrayList<String> getAccountNumbers(String querry)  {
		
		ArrayList<String> accountNumberList = new ArrayList<String>();
		
			rs=getDBUtilities().fetchDataFromCBCMDB(querry);
		
	
			try {
				while(rs.next()) {
					String accountNums = null;
					try {
						accountNums = rs.getString(DBQuerryConstants.guidingIDAttribute);
					} catch (SQLException e) {
						e.printStackTrace();
					}
					
					accountNumberList.add(accountNums);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			System.out.println("the account no lis::"+accountNumberList);
			
			return accountNumberList;
	}
	
	//get the free area code and product no from the cbcm db
	public ArrayList<String> getFreeAreaCodeAndProductNumFromCBCMDB()  {
		
		ArrayList<String> productNoList = new ArrayList<String>();
		ArrayList<String> areaCodeList = new ArrayList<String>();
		ArrayList<String> gsmNumberPoolIDList = new ArrayList<String>();
		
		ArrayList<String> finalUpdatedAreaCodeAndProductNo;
			rs=getDBUtilities().fetchDataFromCBCMDB(DBQuerryConstants.getFreeProductNumberAndAreaCodeFromCBCMDB);
		
	
			try {
				while(rs.next()) {
					String areaCode = null;
					try {
						areaCode = rs.getString(DBQuerryConstants.areaCodeAttribute);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					String productNumber = null;
					try {
						productNumber = rs.getString(DBQuerryConstants.productNumberAttribute);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					String gsmNumberPoolId = null;
					try {
						gsmNumberPoolId = rs.getString(DBQuerryConstants.gsmNumberPoolIDAttribute);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					areaCodeList.add(areaCode);
					productNoList.add(productNumber);
					gsmNumberPoolIDList.add(gsmNumberPoolId);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("the area code lis::"+areaCodeList);
			System.out.println("the product no list ::"+productNoList);
			System.out.println("the gsm pool id list ::"+gsmNumberPoolIDList);
			
			String areaCode=areaCodeList.get(DBQuerryConstants.getRandomNumbers());
			int randomNum =DBQuerryConstants.getRandomNumbers();
			String productNum=productNoList.get(randomNum);
			String gsmNumberPoolID=gsmNumberPoolIDList.get(randomNum);
			
			System.out.println("the gsm pool id ::"+gsmNumberPoolID);
			
			rs=getDBUtilities().fetchDataFromCBCMDB("select DELETION_STATUS from T_SOH_GSM_ASSOCIATION ass where ass.gsm_number_pool_id ="+"'"+gsmNumberPoolID+"'");
			
			try {
				while(rs.next()) {
					String deletionStatus = null;
					try {
						deletionStatus = rs.getString("DELETION_STATUS");
						if(!deletionStatus.isEmpty()) {
							System.out.println("the record found in the gsm_association table");
							getDBUtilities().updateValuesIntoCBCMDB("UPDATE T_SOH_GSM_ASSOCIATION SET DELETION_STATUS='Y' where gsm_number_pool_id ="+"'"+gsmNumberPoolID+"'");
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}catch (Exception e) {
				// TODO: handle exception
			}
			
			
			finalUpdatedAreaCodeAndProductNo=checkWithMsisdnNoIfExistsUpdateAndInsertIntoCSSDB(areaCode,productNum);
			
			return finalUpdatedAreaCodeAndProductNo;
	}
	
	public void updateDeletionStatusInCBCMBD(String areaCode,String productNum) {
		
		System.out.println("in cbcm db for updating the detetion status");
		
		rs=getDBUtilities().fetchDataFromCBCMDB("SELECT GSM_NUMBER_POOL_ID,AREA_CODE,PRODUCT_NUMBER FROM T_SOH_GSM_NUMBER_POOL NPP WHERE NPP.area_code="+areaCode+" and NPP.PRODUCT_NUMBER="+"'"+productNum+"'");
		String gsmNumberPoolId = null;
		try {
			while(rs.next()) {
			
				try {
					gsmNumberPoolId = rs.getString(DBQuerryConstants.gsmNumberPoolIDAttribute);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			System.out.println("the gsm pool id ::"+gsmNumberPoolId);

			
			rs=getDBUtilities().fetchDataFromCBCMDB("select DELETION_STATUS from T_SOH_GSM_ASSOCIATION ass where ass.gsm_number_pool_id ="+"'"+gsmNumberPoolId+"'");
			
			try {
				while(rs.next()) {
					String deletionStatus = null;
					try {
						deletionStatus = rs.getString("DELETION_STATUS");
						if(!deletionStatus.isEmpty()) {
							System.out.println("the record found in the gsm_association table");
							getDBUtilities().updateValuesIntoCBCMDB("UPDATE T_SOH_GSM_ASSOCIATION SET DELETION_STATUS='Y' where gsm_number_pool_id ="+"'"+gsmNumberPoolId+"'");
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}catch (Exception e) {
				// TODO: handle exception
			}
	}
	
	//if msisdnno is exists in the cssdb and then update into number table or else  insert into the number db	
	public ArrayList<String> checkWithMsisdnNoIfExistsUpdateAndInsertIntoCSSDB(String areaCode,String productNo){
		
		ArrayList<String> areaCodeAndProductNum = new ArrayList<String>();
						
		String areaCodeWithoutZero = DBQuerryConstants.getAreCodeWithoutZero(areaCode);
		
		System.out.println("the framed no==>"+DBQuerryConstants.getMsidnNo(areaCodeWithoutZero+productNo));
		
		//getMsisdnNofromCss db
		rs=getDBUtilities().fetchDataFromCSSDB(DBQuerryConstants.getMsidnNo(areaCodeWithoutZero+productNo));
		
		String msidnNo = null;
		try {
			while(rs.next()) {
					msidnNo=rs.getString(DBQuerryConstants.msisdnAttribute);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(msidnNo==null) {
			System.out.println("need to insert data into the table");
			try {
				//cssrc db
				getDBUtilities().insertValuesIntoCSSDB(DBQuerryConstants.getInserQuerryForMSISDN(areaCodeWithoutZero,areaCode,productNo));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			System.out.println("need to update the data in the table");
			try {
				// css rc db update
				getDBUtilities().updateValuesIntoCSSDB(DBQuerryConstants.getUpdateMsidnNoIntoNumbersDBQuerry(areaCodeWithoutZero,areaCode, productNo));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		areaCodeAndProductNum.add(areaCode);
		areaCodeAndProductNum.add(productNo);
		return areaCodeAndProductNum;
	}
			
			
	
	
	public ArrayList<String> getFreeAreaCodeAndProductNumFromCBCMDB1()  {
		
		ArrayList<String> productNoList = new ArrayList<String>();
		ArrayList<String> areaCodeAndProductNum = new ArrayList<String>();
		
			rs=getDBUtilities().fetchDataFromCBCMDB(DBQuerryConstants.getFreeProductNumberAndAreaCodeFromCBCMDB);
		
	
			try {
				while(rs.next()) {
					String areaCode = null;
					try {
						areaCode = rs.getString(DBQuerryConstants.areaCodeAttribute);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					String productNumber = null;
					try {
						productNumber = rs.getString(DBQuerryConstants.productNumberAttribute);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					productNoList.add(areaCode);
					productNoList.add(productNumber);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println(productNoList);
			String areaCode=productNoList.get(12);
			String productNum=productNoList.get(13);

			
			String areaCodeWithoutZero = DBQuerryConstants.getAreCodeWithoutZero(areaCode);
			
			System.out.println("the framed no==>"+DBQuerryConstants.getMsidnNo(areaCodeWithoutZero+productNum));
			
			//getMsisdnNofromCss db
			rs=getDBUtilities().fetchDataFromCSSDB(DBQuerryConstants.getMsidnNo(areaCodeWithoutZero+productNum));
			
			String msidnNo = null;
			try {
				while(rs.next()) {
						msidnNo=rs.getString(DBQuerryConstants.msisdnAttribute);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(msidnNo==null) {
				System.out.println("need to insert data into the table");
				try {
					//cssrc db
					getDBUtilities().insertValuesIntoCSSDB(DBQuerryConstants.getInserQuerryForMSISDN(areaCodeWithoutZero,areaCode,productNum));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else {
				System.out.println("need to update the data in the table");
				try {
					// css rc db update
					getDBUtilities().updateValuesIntoCSSDB(DBQuerryConstants.getUpdateMsidnNoIntoNumbersDBQuerry(areaCodeWithoutZero,areaCode, productNum));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			areaCodeAndProductNum.add(areaCode);
			areaCodeAndProductNum.add(productNum);
			return areaCodeAndProductNum;
			
	}
	
	public ArrayList<String> getFreeSerialNumberFromCBCMDB(int noOfSerialNo) {
		ArrayList<String> serialNoList = new ArrayList<String>();
		ArrayList<String> styleCodeList = new ArrayList<String>();
		ArrayList<String> serialNoList1 = new ArrayList<String>();
		ArrayList<String> updatedSerialNoList = new ArrayList<String>();
		ArrayList<String> cardTypeList = new ArrayList<String>();
		
		rs=getDBUtilities().fetchDataFromCBCMDB(DBQuerryConstants.getFreeSerialNumbersFromCBCMDB);
		
		try {
			while(rs.next()) {
				String serialNo=rs.getString(DBQuerryConstants.iccidNoAttribute);
				String style_code = rs.getString(DBQuerryConstants.styleCodeAttribute);
				String card_type=rs.getString(DBQuerryConstants.cardTypeAttribute);
				serialNoList.add(serialNo);
				styleCodeList.add(style_code);
				cardTypeList.add(card_type);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		}
		
		int randomNum1=DBQuerryConstants.getRandomNumbers();
		int randomNum2=DBQuerryConstants.getRandomNumbers();
		String styleCode1 = null,styleCode2=null;
		String serialNo1=null,serialNo2=null;
		if(noOfSerialNo==1) {
			serialNo1=serialNoList.get(DBQuerryConstants.getRandomNumbers());
			try {
				getDBUtilities().updateValuesIntoCBCMDB("UPDATE t_soh_gsm_resource_pool SET STYLE_CODE='99' where ICCID_NO ="+"'"+serialNo1+"'");
				} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			serialNoList1.add(serialNo1);
		}else if(noOfSerialNo==2) {
			serialNo1=serialNoList.get(randomNum1);
			styleCode1=styleCodeList.get(randomNum1);
			try {
				getDBUtilities().updateValuesIntoCBCMDB("UPDATE t_soh_gsm_resource_pool SET STYLE_CODE='03' where ICCID_NO ="+"'"+serialNo1+"'");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			serialNo2=serialNoList.get(randomNum2);
			styleCode2=styleCodeList.get(randomNum2);
			try {
				getDBUtilities().updateValuesIntoCBCMDB("UPDATE t_soh_gsm_resource_pool SET STYLE_CODE='99' where ICCID_NO ="+"'"+serialNo2+"'");
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			serialNoList1.add(serialNo1);
			serialNoList1.add(serialNo2);
			
		}else if(noOfSerialNo==3) {
			 serialNo1=serialNoList.get(DBQuerryConstants.getRandomNumbers());
			 serialNo2=serialNoList.get(DBQuerryConstants.getRandomNumbers());
			String serialNo3=serialNoList.get(DBQuerryConstants.getRandomNumbers());
			serialNoList1.add(serialNo1);
			serialNoList1.add(serialNo2);
			serialNoList1.add(serialNo3);
		}else if(noOfSerialNo==4) {
			 serialNo1=serialNoList.get(DBQuerryConstants.getRandomNumbers());
			 serialNo2=serialNoList.get(DBQuerryConstants.getRandomNumbers());
			String serialNo3=serialNoList.get(DBQuerryConstants.getRandomNumbers());
			String serialNo4=serialNoList.get(DBQuerryConstants.getRandomNumbers());
			serialNoList1.add(serialNo1);
			serialNoList1.add(serialNo2);
			serialNoList1.add(serialNo3);
			serialNoList1.add(serialNo4);
		}
		
		/*try {
			if(styleCode1.equals("04") && styleCode2.equals("04")) {
				getDBUtilities().updateValuesIntoCBCMDB("UPDATE t_soh_gsm_resource_pool SET STYLE_CODE='03' where ICCID_NO ="+"'"+serialNo1+"'");
				getDBUtilities().updateValuesIntoCBCMDB("UPDATE t_soh_gsm_resource_pool SET STYLE_CODE='99' where ICCID_NO ="+"'"+serialNo2+"'");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		updatedSerialNoList =updateSerialNumbersIntheCSSDB(serialNoList1);
		return updatedSerialNoList;
	}
	
	public void updateserilaNumStyleCode(ArrayList<String> arryLst) {
		
		if(arryLst.size()==1) {
			String serialNo2 = arryLst.get(0);
				try {
					getDBUtilities().updateValuesIntoCBCMDB("UPDATE t_soh_gsm_resource_pool SET STYLE_CODE='99' where ICCID_NO ="+"'"+serialNo2+"'");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}else {
			String serialNo1 = arryLst.get(0);
			String serialNo2 = arryLst.get(1);
				try {
					getDBUtilities().updateValuesIntoCBCMDB("UPDATE t_soh_gsm_resource_pool SET STYLE_CODE='03' where ICCID_NO ="+"'"+serialNo1+"'");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
				try {
					getDBUtilities().updateValuesIntoCBCMDB("UPDATE t_soh_gsm_resource_pool SET STYLE_CODE='99' where ICCID_NO ="+"'"+serialNo2+"'");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public ArrayList<String> updateSerialNumbersIntheCSSDB(ArrayList<String> serialNoList){
		ArrayList<String> updatedSerialNoList = new ArrayList<String>();
		Iterator<String> iterator = serialNoList.iterator();
		while (iterator.hasNext()) {
			String serialNo=iterator.next();
			getDBUtilities().fetchDataFromCBCMDB(DBQuerryConstants.getUpdateSerialNoQuerry(serialNo));
			updatedSerialNoList.add(serialNo);
		}
		
		return updatedSerialNoList;
	}
}
