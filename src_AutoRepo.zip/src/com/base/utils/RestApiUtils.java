package com.base.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.httpclient.HttpException;

import com.automation.configs.AutomationConstants;
import com.ibm.rqm.url.client.RQMUrlGET;
import com.ibm.rqm.url.client.RQMUrlUtlyJRSHttpsClient;
import com.ibm.rqm.url.client.RQMUrlUtlyLogin;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.client.urlconnection.HTTPSProperties;
import com.sun.jersey.core.util.FeaturesAndProperties;




public class RestApiUtils{

/*  private final AutomationConfig automationConfig;
  private XMLParserUtil xmlParser;*/
  private Client restClient;
  private WebResource webResource;
  public String output = null;
  public int status = 0;

  public RestApiUtils() {

  }

  public TrustManager[] createSslSocketFactory() throws Exception {
    final TrustManager[] byPassTrustManagers = new TrustManager[] { new X509TrustManager() {
      @Override
      public X509Certificate[] getAcceptedIssuers() {
        return new X509Certificate[0];
      }

      @Override
      public void checkClientTrusted(X509Certificate[] chain, String authType) {
      }

      @Override
      public void checkServerTrusted(X509Certificate[] chain, String authType) {
      }
    } };
    return byPassTrustManagers;
  }

  /*
   * create sales order by ResT API
   */

  public void getApi() {

    try {

    	final File currentDirectory = new File(new File("").getAbsolutePath());
    	final String WORKING_DIR = currentDirectory.getAbsolutePath();


      final TrustManager[] ss = createSslSocketFactory();
      final HostnameVerifier ff = new HostnameVerifier() {

        @Override
        public boolean verify(String hostname, SSLSession session) {
          // TODO Auto-generated method stub
          return false;
        }
      };

      final ClientConfig config = new DefaultClientConfig();
      final SSLContext ctx = SSLContext.getInstance("SSL");
      ctx.init(null, ss, null);
      config.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES, new HTTPSProperties(ff, ctx));

      restClient = Client.create(config);
      restClient.addFilter(new HTTPBasicAuthFilter("hkhirodkar", "eatmydust@2018"));
      
      String url="https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/testcase/TC_UDB_007_SOH_HIADSL_UpgradeDowngradeBundle";
      String u1=url.replaceAll(" ","%20");
      webResource = restClient.resource(u1);
      
      final String filepath = WORKING_DIR + File.separator + "src" + File.separator + "resources"
			     + File.separator + "ReqXml" + File.separator + "TCName.xml";
    	    final File f = new File(filepath);
      
      final ClientResponse resp = webResource.type("application/xml").entity(filepath).get(ClientResponse.class);
    	 
    	   // final ClientResponse resp = webResource.type("application/xml").get(ClientResponse.class);
      
      System.out.println(resp.getStatus());
      if (resp.getStatus() != 201 || resp.getStatus() != 200 ) {
        System.err.println("Unable to connect to the server");
      }
      final String output = resp.getEntity(String.class);
     
      System.out.println("------entity------" + output);
     

    } catch (final Exception e) {
      e.printStackTrace();
    }
  }
  
  public void getApi1() throws Exception {
	  
	 
	  final TrustManager[] ss = createSslSocketFactory();
      final HostnameVerifier ff = new HostnameVerifier() {

        @Override
        public boolean verify(String hostname, SSLSession session) {
          // TODO Auto-generated method stub
          return false;
        }
      };

      final SSLContext ctx = SSLContext.getInstance("SSL");
      ctx.init(null, ss, null);
      
      RQMUrlUtlyJRSHttpsClient client = new RQMUrlUtlyJRSHttpsClient("https", "rqmserver.etisalat.corp.ae", 9443);
	  
      client.registerTrustingSSL();
      
      // getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES, new HTTPSProperties(ff, ctx));
      
	  
	 
	  
	  RQMUrlUtlyLogin ll = new RQMUrlUtlyLogin("https","rqmserver.etisalat.corp.ae", 9443,"Etisalat Regression Suite - 2018");
	  
	  ll.login("hkhirodkar", "eatmydust@2018", "aa");
	  
	  System.out.println("the status of the connection is::"+ll);
	  
	  String url="https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/testcase/TC_UDB_007_SOH_HIADSL_UpgradeDowngradeBundle";
      
	  String u1=url.replaceAll(" ","%20");
	  
	  RQMUrlGET config = new RQMUrlGET(u1,"C:\\Users\\jekumar\\Desktop\\testRQM", client, ll, "RFC_2109");
	  
	  String aa = config.toString();
	  
	  System.out.println("the out put is ==:"+aa);
	  
  }
  
  public void  connectRQM() throws IOException {
	  
	  Process proc = null;

		//proc = Runtime.getRuntime().exec("C://Users/jekumar/Desktop/startRQM/testRQM.bat TC_CDQ_001_SOH_DualPlayProduct_ChangeDQInfo");
	  
	 //proc= Runtime.getRuntime().exec(new String[] {"C://Users/jekumar/Desktop/startRQM/testRQM.bat","TC_CDQ_001_SOH_DualPlayProduct_ChangeDQInfo"});
	 
	 
	 //java -jar "C:\Users\jekumar\Desktop\rqmIntgeration\RQMUrlUtility\RQMUrlUtility.jar" -command GET -user hkhirodkar -password eatmydust@2018 -filepath  "C:\Users\jekumar\Desktop\testRQM\TCName.xml" -url "https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/testcase/"
	
	 String jarfile = "java -jar"+" "+'"'+"C:\\Users\\jekumar\\Desktop\\rqmIntgeration\\RQMUrlUtility\\RQMUrlUtility.jar"+'"';
	 String userCmd =" "+"-command GET -user"+" "+"hkhirodkar"+" "+"-password eatmydust@2018"+" ";
	 String filepath = "-filepath"+" "+'"'+"C:\\Users\\jekumar\\Desktop\\testRQM\\TCName.xml"+'"'+" ";
	 String urlPath="-url"+" "+'"'+"https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/testcase/TC_CDQ_001_SOH_DualPlayProduct_ChangeDQInfo"+'"';
	 
	 //proc= Runtime.getRuntime().exec(new String[] {"cmd.exe","/c",jarfile,userCmd,filepath,urlPath});
	 proc= Runtime.getRuntime().exec(new String[] {jarfile,userCmd,filepath,urlPath});
	// Then retreive the process output
	InputStream in = proc.getInputStream();
	
	BufferedReader reader = new BufferedReader(new InputStreamReader(in));
    StringBuilder out = new StringBuilder();
    String line;
    while ((line = reader.readLine()) != null) {
        out.append(line);
    }
    System.out.println("the out of the file is:::&&&&&&&&&&&&"+out.toString());   
    reader.close();
	  
  	}
  
  public void connectRQM1(String testCaseName) throws IOException {
	  String jarfile = "java -jar"+" "+'"'+"C:\\Users\\jekumar\\Desktop\\rqmIntgeration\\RQMUrlUtility\\RQMUrlUtility.jar"+'"';
		 String userCmd =" "+"-command GET -user"+" "+"hkhirodkar"+" "+"-password eatmydust@2018"+" ";
		 String filepath = "-filepath"+" "+'"'+"C:\\Users\\jekumar\\Desktop\\testRQM\\TCName.xml"+'"'+" ";
		 String urlPath="-url"+" "+'"'+"https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/testcase/"+testCaseName+'"';

		 System.out.println(jarfile+userCmd+filepath+urlPath);
     ProcessBuilder builder = new ProcessBuilder(
     		new String[] {"cmd.exe", "/c",jarfile+userCmd+filepath+urlPath});
     builder.redirectErrorStream(true);
     Process p = builder.start();
  
     
     BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
     String line;
     while (true) {
         line = r.readLine();
         if (line == null) { break; }
         System.out.println(line);
  }
  }
}
  
  

