package com.base.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.Assert;


import oracle.jdbc.pool.OracleDataSource;

public class DBDemo {
	
	 	static String jdbcUrl = "jdbc:oracle:thin:@au931:1521:CSSRC";
	 	static String userid = "CSSRC";
	 	static String password = "cssproject$123"; 
	 	
	 	
	 	static Connection conn;
	 	static java.sql.Statement st;
	 	
	 	static String jdbcUrl2 = "jdbc:oracle:thin:@AU941:1527:CBCMRCDL";
	 	static String userid2 = "cbcm_customer";
	 	static String password2 = "cbcm54321"; 

	 	 
	    public static Connection getDBConnection() throws SQLException{
	     	
	    	System.out.println("fffff"+ jdbcUrl);

	        OracleDataSource ds;
	        ds = new OracleDataSource();
	        ds.setURL(jdbcUrl);
	        conn=ds.getConnection(userid,password);
	        
	        return conn;
	        
	    }
	    
	    public static Connection getDBcbcmConnection() throws SQLException{
	     	
	    	System.out.println("fffff"+ jdbcUrl2);

	        OracleDataSource ds;
	        ds = new OracleDataSource();
	        ds.setURL(jdbcUrl2);
	        conn=ds.getConnection(userid2,password2);
	        
	        return conn;
	        
	    }
	    
	    
	
	    public static ArrayList<String> executeQuerry1(String querry) {
	    	
			ArrayList<String> al = new ArrayList<String>();
		try {
			System.out.println("the db connection==>"+getDBcbcmConnection());
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(querry);
			while(rs.next()) {
				String areaCode=rs.getString("AREA_CODE");
				String productNumber=rs.getString("PRODUCT_NUMBER");
				al.add(areaCode);
				al.add(productNumber);
			}
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return al;
	}
	    
	    public static String executeCSSQuerry(String querry) {
	    	String temp = null;
		try {
			System.out.println("the db connection==>"+getDBConnection());
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(querry);
			while(rs.next()) {
				temp=rs.getString("MSISDN");
			}
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return temp;
	}

	public static void main(String args[]) {
		
		
		ArrayList<String> al1 =executeQuerry1("SELECT AREA_CODE,PRODUCT_NUMBER FROM T_SOH_GSM_NUMBER_POOL NPP WHERE ROWNUM <=5 and NPP.LOCATION_CODE='M' and NPP.ACCOUNT_SUFFIX=0 AND  NPP.PRODUCT_NUMBER_STATUS in (23) AND NPP.SERVICE_ID='1001' and NPP.Number_Category IS NULL");
		System.out.println("the array list elements are::"+al1);
		
		System.out.println("the array list 1st Index::"+al1.get(0));
		System.out.println("the array list 2nd Index::"+al1.get(1));
    	    	
		/*String al = executeCSSQuerry("select * from numbers where msisdn=971507057939");
		System.out.println("sim no==>"+al);*/

	}

}
