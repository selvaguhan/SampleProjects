package com.base.utils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import oracle.jdbc.pool.OracleDataSource;

public class DBUtilities {
	
	 Connection conn;
	 java.sql.Statement st; 
	 String jdbcUrl1;
	 String userid1;
	 String password1;
	 
	 String jdbcUrl2;
	 String userid2;
	 String password2;
	 
 	PropUtils propUtils;
 	ResultSet rs;
 	
	public DBUtilities(PropUtils propUtils) {
		this.propUtils=propUtils;
		jdbcUrl1 = "jdbc:oracle:thin:"+"@"+propUtils.getDbLocalHost()+":"+propUtils.getDbPort()+":"+propUtils.getDbSID();
		userid1= propUtils.getDbUserId();
		password1 = propUtils.getDbPassword();
		
		jdbcUrl2 = "jdbc:oracle:thin:"+"@"+propUtils.getCssRc_dbLocalHost()+":"+propUtils.getCssRc_dbPort()+":"+propUtils.getCssRc_dbSID();
		userid2= propUtils.getCssRc_dbUserId();
		password2 = propUtils.getCssRc_dbPassword();
	}
	
	
  	 
    public Connection getDBConnection() throws SQLException{
    	OracleDataSource ds;
        ds = new OracleDataSource();
        ds.setURL(jdbcUrl1);
        conn=ds.getConnection(userid1,password1);
        
        return conn;
        
    }
    
    public Connection getCSSDBConnection() throws SQLException{
    	OracleDataSource ds;
        ds = new OracleDataSource();
        ds.setURL(jdbcUrl2);
        conn=ds.getConnection(userid2,password2);
        
        return conn;
        
    }
    
    
    
  
    
    public ResultSet fetchDataFromCSSDB(String querry) {
		try {
			System.out.println("the db connection==>"+getCSSDBConnection());
			st = conn.createStatement();
			rs = st.executeQuery(querry);
				
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
    }

    public ResultSet fetchDataFromCBCMDB(String querry) {
		try {
			System.out.println("the db connection==>"+getDBConnection());
			st = conn.createStatement();
			rs = st.executeQuery(querry);
				
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
    }
    
    public void insertValuesIntoCSSDB(String querry) throws SQLException {
    	conn=getCSSDBConnection();
    	conn.setAutoCommit(false);
/*    	st = conn.createStatement();
    	st = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                ResultSet.CONCUR_READ_ONLY);*/
    	 PreparedStatement pstmt3 = conn.prepareStatement(querry);
    	 pstmt3.executeUpdate(querry);
    	 pstmt3.close();
    	   // Commit the effect of all both the INSERT and UPDATE 
    	   // statements together 
    	   conn.commit();
    	   conn.close();
    	//conn.commit();
    }
    
    public void updateValuesIntoCSSDB(String querry) throws SQLException {
    	conn=getCSSDBConnection();
    	conn.setAutoCommit(false);
    	 PreparedStatement pstmt3 = conn.prepareStatement(querry);
    	 pstmt3.executeUpdate(querry);
    	 pstmt3.close();
    	 conn.commit();
    	 conn.close();
    }
    
    public void updateValuesIntoCBCMDB(String querry) throws SQLException {
    	conn=getDBConnection();
    	conn.setAutoCommit(false);
    	 PreparedStatement pstmt3 = conn.prepareStatement(querry);
    	 pstmt3.executeUpdate(querry);
    	 pstmt3.close();
    	 conn.commit();
    	 conn.close();
    }
    
    public String executeQuerry(String querry) {
    		String result=null;;
    	try {
			System.out.println("the db connection==>"+getDBConnection());
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(querry);
			while(rs.next()) {
				System.out.println("the status of the result set is ==>"+rs.getString("STATUS"));
				result= rs.getString("STATUS");
			}
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return result;
    }
    
    public String executeQuerry2(String querry) {
		String result=null;;
	try {
		System.out.println("the db connection==>"+getDBConnection());
		st = conn.createStatement();
		ResultSet rs = st.executeQuery(querry);
		while(rs.next()) {
			System.out.println("the status of the result set is ==>"+rs.getString("INDICATOR"));
			result= rs.getString("INDICATOR");
		}
	
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return result;
}
    
    
    public ArrayList<String> executeQuerry1(String querry) {
		ArrayList<String> al = new ArrayList<String>();
	try {
		System.out.println("the db connection==>"+getDBConnection());
		st = conn.createStatement();
		ResultSet rs = st.executeQuery(querry);
		while(rs.next()) {
			String simNo=rs.getString("NEW_ICCID_NO");
			al.add(simNo);
		}
	
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return al;
}
    
    
    public boolean verifySubRequestStatus(String querry) throws Exception {

        boolean bFlag = false;
        int maxloopcounter = 150;
        int iCounter = 0;

        String closeStatus = executeQuerry(querry);
        System.out.println("in the verify sub request status method:"+closeStatus);
        if (closeStatus != null && closeStatus != "") {
         

          while (closeStatus.equalsIgnoreCase("49464") && (iCounter <= maxloopcounter)) {
            System.out.println("checking the sub request status:" + closeStatus + " Present Status is:"
                 + iCounter);
            closeStatus = executeQuerry(querry);
            iCounter++;
          }

          if (closeStatus.equalsIgnoreCase("90")) {
            bFlag = true;
          }
        } else {
          return false;
        }

        return bFlag;
      }
     	
    
    public String iterateResultSet(ResultSet rs,String columAttribute) {
		String result=null;;
		try {
				while(rs.next()) {
				System.out.println("the status of the result set is ==>"+rs.getString(columAttribute));
				result= rs.getString(columAttribute);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		return result;
    }
    
}
