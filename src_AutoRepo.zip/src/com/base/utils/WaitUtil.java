package com.base.utils;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.automation.configs.WaitConfigs;

public class WaitUtil {
	WebDriverWait wait;
	WebDriver driver;
	public WaitUtil(WebDriver driver) {
		this.driver = driver;
	}
	
	public void isElementPresent(By locator,int sec) {
		try {
			wait = new WebDriverWait(driver, sec);
			wait.until(ExpectedConditions.presenceOfElementLocated(locator)); 
		}catch (Exception e) {
			System.out.println("the element is not presence in the web page:"+e);
		}
		
	}
	
	public void isElementStaleNess(By locator,int sec) {
		try {
			wait = new WebDriverWait(driver, sec);
			wait.until(ExpectedConditions.stalenessOf(driver.findElement(locator))); 
		}catch (Exception e) {
			System.out.println("the element is not presence in the web page:"+e);
		}
		
	}
	
	public void isElementClickable(By locator,int sec) {
		try {
			wait = new WebDriverWait(driver, sec);
			wait.until(ExpectedConditions.elementToBeClickable(locator)); 
		}catch (Exception e) {
			System.out.println("the element is not clickable in the web page:"+e);
		}
		
	}
	
	public void isElementVisible(By locator,int sec) {
		try {
			wait = new WebDriverWait(driver, sec);
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator)); 
		}catch (Exception e) {
			System.out.println("the element is not visible in the web page:"+e);
		}
		
	}
	
	public void isElementInVisible(By locator,int sec) {
		try {
			wait = new WebDriverWait(driver, sec);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(locator)); 
		}catch (Exception e) {
			System.out.println("the element is not InVisible in the web page:"+e);
		}
		
	}
	
	public void isElementEnabled(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			element.isEnabled();
		}catch (Exception e) {
			System.out.println("the element is not enabled in the web page:"+e);
		}
		
	}
	
	public void isDisplayed(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			element.isDisplayed();
		}catch (Exception e) {
			System.out.println("the element is not displayed in the web page:"+e);
		}
		
	}
	
	public void implicitlyWait(int sec) {
		try {
			driver.manage().timeouts().implicitlyWait(sec, TimeUnit.SECONDS);
		}catch (Exception e) {
			System.out.println("the element is not implicitlyWait in the web page:"+e);
		}
	}
	
	public void implicitlyWait(By locator,int sec) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, sec);
		    wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		}catch (Exception e) {
			System.out.println("the element is not visibilityOfElementLocated in the web page:"+e);
		}
	}
	
	public void fluentWaitForElementTobeClickable(By by,int sec) {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).pollingEvery(sec, TimeUnit.SECONDS).ignoring(
				NoSuchElementException.class);
		boolean b = wait.until(ExpectedConditions.elementToBeClickable(by)) != null;
	}
	
	public void elementPresence(By by, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}
	
	public void elementPresenceWithAttribute(By by,int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		wait.until(ExpectedConditions.attributeToBe(by, "value", "ETISALAT QA AUTOMATION"));
	}
	
	
	
	public void waitForFrameToSwitch(String by,int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.name(by)));
	}
	
	 public void waitForPage(int sec) {
		    final JavascriptExecutor je = (JavascriptExecutor) driver;
		    final int waitTime = sec * 1000;
		    int counter = 0;
		    counter = 0;
		    Long ajaxCount = (long) -1;
		    do {
		      try {
		        Thread.sleep(1000);
		      } catch (final InterruptedException e1) {
		        e1.printStackTrace();
		      }
		      counter += 1000;
		      try {
		        ajaxCount = (Long) ((je)).executeScript("return window.dwr.engine._batchesLength");
		      } catch (final WebDriverException e) {

		      }
		    } while (ajaxCount.intValue() > 0 && counter < waitTime);
		  }
	 
	 public void waitForPageLoad(int sec) {

		    Wait<WebDriver> wait = new WebDriverWait(driver,sec);
		    wait.until(new Function<WebDriver, Boolean>() {
		        public Boolean apply(WebDriver driver) {
		            System.out.println("Current Window State       : "
		                + String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")));
		            return String
		                .valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState"))
		                .equals("complete");
		        }
		    });
		}
	 
	 public void waitForMins(int mins) {
		 try {
		     TimeUnit.MINUTES.sleep(mins);
		} catch (InterruptedException e) {
		    //Handle exception
		}
	 }
	 
	 public  ExpectedCondition<WebElement> oneOfElementsLocatedVisible(By... args)
	 {
	     final List<By> byes = Arrays.asList(args);
	     return new ExpectedCondition<WebElement>()
	     {
	    	  WebElement el;
	         @Override
	         public WebElement apply(WebDriver driver)
	         {
	             for (By by : byes)
	             {
	               
	                 try {el = driver.findElement(by);} catch (Exception r) {continue;}
	                 if (el.isDisplayed()) return el;
	             }
	             return el;
	         }
	     };
	 }
	 
	 public void frameSwithWithExpectedCondition(String frameName) {
			WebDriverWait wait = new WebDriverWait(driver,40);
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameName));
		}
	 
	 public void waitForTitle(String title) {
		 WebDriverWait wait = new WebDriverWait(driver, WaitConfigs.elementVisibleWait);
		 wait.until(ExpectedConditions.titleContains(title));
	 }
	 
	 public  ExpectedCondition<Boolean> invisibilityOfElementLocated(
		      final By locator) {
		    return new ExpectedCondition<Boolean>() {
		      @Override
		      public Boolean apply(WebDriver driver) {
		        try {
		          return !(driver.findElement(locator).isDisplayed());
		        } catch (NoSuchElementException e) {
		          // Returns true because the element is not present in DOM. The
		          // try block checks if the element is present but is invisible.
		          return true;
		        } catch (StaleElementReferenceException e) {
		          // Returns true because stale element reference implies that element
		          // is no longer visible.
		          return true;
		        }
		      }
		    };
	 }
}
