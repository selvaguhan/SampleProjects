package com.automation.configs;

public class RQMConfigs {
	
	  public static String jarfile = "java -jar"+" "+'"'+"C:\\Users\\jekumar\\Desktop\\rqmIntgeration\\RQMUrlUtility\\RQMUrlUtility.jar"+'"';
	  public static String userName ="hkhirodkar";
	  public static String passWord ="eatmydust@2018";
	  public static String responceTCName="TCName.xml";
	  public static String responceTempFile="Temp.xml";
	  public static String regressionSuitePlan="Etisalat Regression Suite - 2018/";
	  
	  
	  public static String stateTagName="ns5:state";
	  
	  public static String actualResultTag="ns16:actualResult";
	  
	  public static String passedState="com.ibm.rqm.execution.common.state.passed";
	  public static String failedState="com.ibm.rqm.execution.common.state.failed";
	  public static String inProgressState="com.ibm.rqm.execution.common.state.inprogress";
	  
	  //public static String userCmd =" "+"-command GET -user"+" "+"hkhirodkar"+" "+"-password eatmydust@2018"+" ";
	  
	  private static String rqmConnectorUrl="-url"+" "+'"'+"https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/";
	  
	  public static String resFilePath = "C:\\Users\\jekumar\\Desktop\\testRQM\\";
	  
	  //public static String urlPath="-url"+" "+'"'+"https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/testcase/"+testCaseName+'"';
	  
	  //java -jar "C:\Program Files (x86)\Test Magic Suite 2010\eZscript\RQMUrlUtility.jar" -command GET -user hkhirodkar -password eatmydust@2018 -filepath "C:\Program Files (x86)\Test Magic Suite 2010\eZscript\TCName.xml"
	  //-url  "https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/"
	  //"executionworkitem/?fields=feed/entry/content/executionworkitem/(*|testcase[@href='https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/testcase/urn:com.ibm.rqm:testcase:268118'])
	  
	  public static String getUserCmd(String userName,String passWord) {
	       String userNameAndPassWordCmd =" "+"-command GET -user"+" "+userName+" "+"-password"+" "+passWord+" ";
		   return userNameAndPassWordCmd;
	  }
	  
	  public static String putUserCmd(String userName,String passWord) {
	       String userNameAndPassWordCmd =" "+"-command PUT -user"+" "+userName+" "+"-password"+" "+passWord+" ";
		   return userNameAndPassWordCmd;
	  }
		  
	  public static String getFilePathCmd(String resFileName) {
		   String filepath = "-filepath"+" "+'"'+resFilePath+resFileName+'"'+" ";
		   return filepath;
		  
	  }
	  
	  public static String connectRQMAndGetTC(String testCaseName) {
		  
		  String rqmConnectUrl=rqmConnectorUrl+regressionSuitePlan+"/testcase/"+testCaseName+'"';
		  return rqmConnectUrl;
	  }
	  
	  
  
	  public static String connectRQMAndGetCurrentExecutionID(String webID) {
		  
		  String currentExecutionID="executionworkitem/?fields=feed/entry/content/executionworkitem/(*|testcase[@href="+"'"+"https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/testcase/urn:com.ibm.rqm:testcase:"+webID+"'"+"])";
		  		  
		  String getCurrentExecutionId=rqmConnectorUrl+regressionSuitePlan+currentExecutionID;
		  
		  return getCurrentExecutionId;
		  
	  }
	  //response tag names
	  
	  public static String webIdTag ="ns2:webId";
	  
	  public static String currentExecutionTag ="ns2:currentexecutionresult";
	  
	  //java -jar "C:\\Users\\jekumar\\Desktop\\rqmIntgeration\\RQMUrlUtility\\RQMUrlUtility.jar" -command GET -user hkhirodkar -password eatmydust@2018 -filepath "C:\\Users\\jekumar\\Desktop\\testRQM\\Temp.xml" -url  "https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/executionresult/urn:com.ibm.rqm:executionresult:633192"
	  
	  //java -jar "C:\Users\jekumar\Desktop\rqmIntgeration\RQMUrlUtility\RQMUrlUtility.jar" -command GET -user hkhirodkar -password eatmydust@2018 -filepath "C:\Users\jekumar\Desktop\testRQM\Temp.xml" -url "https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/executionresult/urn:com.ibm.rqm:executionresult:633192'])"
	  //		+ "
	  public static String connectRQMAndGetTempFile(String currentExecutionId) {
		  
		  String currentExecutionID="executionresult/urn:com.ibm.rqm:executionresult:"+currentExecutionId+'"';
		  		  
		  String getCurrentExecutionId=rqmConnectorUrl+regressionSuitePlan+currentExecutionID;
		  
		  return getCurrentExecutionId;
		  
	  }
	  
	  public static String connectRQMAndUpdateTestCaseStatus(String currentExecutionId) {
		  
		  String currentExecutionID="executionresult/urn:com.ibm.rqm:executionresult:"+currentExecutionId+'"';
		  		  
		  String getCurrentExecutionId=rqmConnectorUrl+regressionSuitePlan+currentExecutionID;
		  
		  return getCurrentExecutionId;
		  
	  }
}
