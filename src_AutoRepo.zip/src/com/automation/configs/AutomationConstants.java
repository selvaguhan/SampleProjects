package com.automation.configs;

public class AutomationConstants {
	
	public static String normalToclone="NormalToClone";
	
	//public static String cloneToNormal="CloneToNormal";
	public static String cloneType="Clone";
	public static String packageType ="Package";
	public static String ratePlanType ="Rate Plan";
	
	public static String successfulOperationtitle ="Successful Operation";
	
	public static String testInputFromDB ="Yes";
	public static String accountNoMulti="accountNoMultiMate";

}
