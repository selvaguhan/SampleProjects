package com.automation.configs;

public class WaitConfigs {
	
	public static int implictWaitTime=40;
	public static int elementVisibleWait=60;
	public static int pageLoadWait=200;

}
