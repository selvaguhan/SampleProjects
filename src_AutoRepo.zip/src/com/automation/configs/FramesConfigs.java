package com.automation.configs;

public class FramesConfigs {
	
	public static String treeFrame ="treeframe";
	public static String baseFrame ="basefrm";
	public static String secondFrame ="secondFrame";
	public static String detailsFrame ="details";
	
	
	

}
