package com.automation.configs;

import java.security.SecureRandom;
import java.util.ArrayList;

public class DBQuerryConstants {
	
	public static String areaCodeAttribute="AREA_CODE";
	public static String productNumberAttribute="PRODUCT_NUMBER";
	public static String gsmNumberPoolIDAttribute="GSM_NUMBER_POOL_ID";
	
	public static String guidingIDAttribute="GUIDING_ID";
	
	public static String accountNumberAttribute="ACCOUNT_NUMBER";
	
	public static String iccidNoAttribute="ICCID_NO";
	
	public static String styleCodeAttribute="STYLE_CODE";
	public static String cardTypeAttribute="CARD_TYPE";
	
	public static String msisdnAttribute="MSISDN";
	public static String areCode="056";
	public static String accountCategory="12";
	//public static String getFreeProductNumberAndAreaCodeFromCBCMDB ="SELECT AREA_CODE,PRODUCT_NUMBER FROM T_SOH_GSM_NUMBER_POOL NPP WHERE ROWNUM <=20 and NPP.LOCATION_CODE='M' and NPP.ACCOUNT_SUFFIX=0 AND  NPP.PRODUCT_NUMBER_STATUS in (23) AND NPP.SERVICE_ID='1001' and NPP.Number_Category IS NULL";
	
	public static String getFreeProductNumberAndAreaCodeFromCBCMDB ="SELECT GSM_NUMBER_POOL_ID, AREA_CODE,PRODUCT_NUMBER FROM T_SOH_GSM_NUMBER_POOL NPP WHERE ROWNUM <=20 and NPP.area_code="+areCode+" "+"and NPP.LOCATION_CODE='M' and NPP.ACCOUNT_SUFFIX=0 AND NPP.PRODUCT_NUMBER_STATUS in (23) AND NPP.SERVICE_ID='1001' and NPP.Number_Category IS NULL and NPP.Notes IS NULL";
	
	public static String getPostPaidAccountNumbers="select GUIDING_ID from t_soh_account ppl where ROWNUM <=3 and ppl.account_category_id="+accountCategory+"and ppl.product_id=1 and ppl.activation_date>sysdate-7";
	
	public static String getPrePaidAccountNumbers="select GUIDING_ID from t_soh_account ppl where ROWNUM <=10 and ppl.account_category_id="+accountCategory+"and ppl.product_id=13 and ppl.activation_date>sysdate-2";
	
	
	public static String getFreeSerialNumbersFromCBCMDB="SELECT ICCID_NO,STYLE_CODE,CARD_TYPE FROM t_soh_gsm_resource_pool reg WHERE ROWNUM <=20 and reg.imsi_no LIKE '%424021012%' AND reg.sim_card_status=23";
	
	public static String accountAndOwnerId ="768";
	public static String countryCode="971";
	
	
	//public static String updateSerialNo ="UPDATE PRODUCT SET MSISDN = NULL,STATUS=3,PROD_TYPE=1,ACTIVATION_DATE=NULL,DEACTIVATION_DATE=NULL,OWNER=768,TEMP_LOCK_EXPIRY=NULL WHERE SERIAL1 in ('8997112209670452314')";
	
	public static String insertQuerry ="INSERT INTO NUMBERS (MSISDN, CATEGORY, STATUS, ACCOUNT, ACCOUNT_CATEGORY,\r\n" + 
			"    CREATED, CREATED_BY, UPDATED, UPDATED_BY, CLASSIFIED, CLASSIFIED_DATE, CLASSFIED_BY, Msisdn_Prefix, Msisdn_Suffix)\r\n" + 
			"     VALUES (971504066188,2, 8, 768, 1, SYSDATE, -13, SYSDATE, -13, 0, SYSDATE, -13, 050,4066188)";
	
	public static String getUpdateSerialNoQuerry(String serialNo) {
		String updateSerialNo ="UPDATE PRODUCT SET MSISDN = NULL,STATUS=3,PROD_TYPE=1,ACTIVATION_DATE=NULL,DEACTIVATION_DATE=NULL,OWNER="+accountAndOwnerId+",TEMP_LOCK_EXPIRY=NULL WHERE SERIAL1 in"+" "+"('"+serialNo+"')";
		return updateSerialNo;
	}
	

	public static String getMsidnNo(String msidnNo) {
		String msidnNo1="select * from numbers where msisdn="+countryCode+msidnNo;
		return msidnNo1;
	}
	
	public static String getInserQuerryForMSISDN(String areaCodeWithoutZero,String areaCode,String productNumber) {
		String insertQuerry ="INSERT INTO NUMBERS (MSISDN, CATEGORY, STATUS, ACCOUNT, ACCOUNT_CATEGORY,CREATED, CREATED_BY, UPDATED, UPDATED_BY, CLASSIFIED, CLASSIFIED_DATE, CLASSFIED_BY, Msisdn_Prefix, Msisdn_Suffix) VALUES ("+countryCode+areaCodeWithoutZero+productNumber+","+"2, 8,"+accountAndOwnerId+", 1, SYSDATE, -13, SYSDATE, -13, 0, SYSDATE, -13,"+ areaCode+","+productNumber+")";
		System.out.println("the insert framed querry is::"+insertQuerry);
		return insertQuerry;
	}
	
	public static String getUpdateMsidnNoIntoNumbersDBQuerry(String areaCodeWithoutZero,String areaCode,String productNumber) {
		String updateMsidnNoQuerry ="UPDATE NUMBERS SET CATEGORY=1,ACCOUNT="+accountAndOwnerId+",STATUS=8,ACTIVATION_DATE=NULL,DEACTIVATION_DATE = NULL,TEMP_LOCK_EXPIRY  = NULL WHERE MSISDN in"+" "+"('"+countryCode+areaCodeWithoutZero+productNumber+"')";
		System.out.println("the update framed querry is::"+updateMsidnNoQuerry);
		return updateMsidnNoQuerry;
	}
	
	public static String getAreCodeWithoutZero(String areaCode) {
		String areaCode1 = areaCode.replaceFirst("(?:05)+", "5");
		return areaCode1;
	}
	
	public static int getRandomNumbers() {
		int random1 = (int )(Math.random() * 15 + 1);
		System.out.println(random1);
		return random1;
	}
	
	public static int get3DigitRandomNumbers() {
		int random1 = (int )(Math.random() * 1000);
		System.out.println(random1);
		return random1;
	}
	
	public static String get5DigitRandomNumbers() {
		SecureRandom random = new SecureRandom();
		int num = random.nextInt(100000);
		String formatted = String.format("%05d", num); 
		System.out.println(formatted);
		return formatted;
	}
	
	public static String get8DigitRandomNumbers() {
		SecureRandom random = new SecureRandom();
		int num = random.nextInt(100000);
		String formatted = String.format("%08d", num); 
		System.out.println(formatted);
		return formatted;
	}
	
	
	public static String getMultiMateAccountNo(String subRequestId) {
		
		String multiMateAccountNo="select"+" "+accountNumberAttribute+" "+"from t_soh_subrequest where subrequest_id ="+subRequestId;
		return multiMateAccountNo;
	}

}
