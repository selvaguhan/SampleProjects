package com.automation.configs;

public class BaseAutoConfigs {
	
	private String application_url;
	private String environment = null;
	private String browserType;
	protected static String datafile_Location = null;
	private String dbName;
	private String dbSID;
	private String dbUserId;
	private String dbPassword;
	private String dbLocalHost;
	private String dbPort;
	
	private String cssRc_dbName;
	private String cssRc_dbSID;
	public String getCssRc_dbSID() {
		return cssRc_dbSID;
	}

	public void setCssRc_dbSID(String cssRc_dbSID) {
		this.cssRc_dbSID = cssRc_dbSID;
	}

	public String getCssRc_dbUserId() {
		return cssRc_dbUserId;
	}

	public void setCssRc_dbUserId(String cssRc_dbUserId) {
		this.cssRc_dbUserId = cssRc_dbUserId;
	}

	public String getCssRc_dbPassword() {
		return cssRc_dbPassword;
	}

	public void setCssRc_dbPassword(String cssRc_dbPassword) {
		this.cssRc_dbPassword = cssRc_dbPassword;
	}

	public String getCssRc_dbLocalHost() {
		return cssRc_dbLocalHost;
	}

	public void setCssRc_dbLocalHost(String cssRc_dbLocalHost) {
		this.cssRc_dbLocalHost = cssRc_dbLocalHost;
	}

	public String getCssRc_dbPort() {
		return cssRc_dbPort;
	}

	public void setCssRc_dbPort(String cssRc_dbPort) {
		this.cssRc_dbPort = cssRc_dbPort;
	}

	private String cssRc_dbUserId;
	private String cssRc_dbPassword;
	private String cssRc_dbLocalHost;
	private String cssRc_dbPort;
	

	
	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	public String getDbSID() {
		return dbSID;
	}

	public void setDbSID(String dbSID) {
		this.dbSID = dbSID;
	}

	public String getDbUserId() {
		return dbUserId;
	}

	public void setDbUserId(String dbUserId) {
		this.dbUserId = dbUserId;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}

	public String getDbLocalHost() {
		return dbLocalHost;
	}

	public void setDbLocalHost(String dbLocalHost) {
		this.dbLocalHost = dbLocalHost;
	}

	public String getDbPort() {
		return dbPort;
	}

	public void setDbPort(String dbPort) {
		this.dbPort = dbPort;
	}
	
	public String getApplication_url() {
		return application_url;
	}

	public static String getDatafile_Location() {
		return datafile_Location;
	}

	public static void setDatafile_Location(String datafile_Location) {
		BaseAutoConfigs.datafile_Location = datafile_Location;
	}

	public void setApplication_url(String application_url) {
		this.application_url = application_url;
	}

	

	public String getEnvironment() {
		return environment;
	}

	public String getBrowserType() {
		return browserType;
	}

	public void setBrowserType(String browserType) {
		this.browserType = browserType;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getCssRc_dbName() {
		return cssRc_dbName;
	}

	public void setCssRc_dbName(String cssRc_dbName) {
		this.cssRc_dbName = cssRc_dbName;
	}

	

	  
}
