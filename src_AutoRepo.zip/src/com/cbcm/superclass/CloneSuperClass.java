package com.cbcm.superclass;

import java.util.ArrayList;

import org.testng.Assert;
import org.testng.Reporter;

import com.automation.configs.AutomationConstants;
import com.automation.configs.FramesConfigs;
import com.automation.configs.WaitConfigs;
import com.base.utils.BaseTest;
import com.cbcm.favoriteTab.pages.CaptureCustomerRequestPage;
import com.cbcm.favoriteTab.pages.FavoritePage;
import com.cbcm.favoriteTab.pages.RequestInquiryPage;
import com.cbcm.pages.MaintainRequestPage;
import com.cbcm.pages.SuccessfulOperationPage;
import com.cbcm.singleSelectWindow.pages.DocumentFrmProfileWindowPage;
import com.cbcm.singleSelectWindow.pages.SRTActionRegistrationWindowPage;

public class CloneSuperClass extends BaseTest{
	
	private CaptureCustomerRequestPage ccrPage;
	SRTActionRegistrationWindowPage srtActionRegWindPage;
	public  MaintainRequestPage mainTainReqPage;
	DocumentFrmProfileWindowPage docFrmProfileWindowPage;
	SuccessfulOperationPage successFullOperPage;
	RequestInquiryPage reqInquiryPage;
	FavoritePage favoritePage;
	
	public CloneSuperClass() {
		
	}
	
	public void selectNewMultiMateReqType(String subRequestType,String partyId) {
		try {
			
			getHomePage().navigateToFavoriteTab().navigateToCCRSubTab().selectSubRequestType(subRequestType).enterPartyIdAndClickOnTab(partyId);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void selectDeleteServices(String subRequestType,String accountNo) {
		try {
			
			getHomePage().navigateToFavoriteTab().navigateToCCRSubTab().selectSubRequestType(subRequestType).enterAccountNumber(accountNo).clickOnAccountNumberAndTab();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void clickOnTillSubRequestLabel(String subRequestType,String accountNo,String actionChngeReason) {
		
		ccrPage = new CaptureCustomerRequestPage(getDriver());
		srtActionRegWindPage = new SRTActionRegistrationWindowPage(getDriver());
		mainTainReqPage = new MaintainRequestPage(getDriver());
		successFullOperPage = new SuccessfulOperationPage(getDriver());
		reqInquiryPage = new RequestInquiryPage(getDriver());
						

			try {
			
				getHomePage().navigateToFavoriteTab().navigateToCCRSubTab().selectSubRequestType(subRequestType).enterAccountNumber(accountNo).
				clickOnAccountNumberAndTab();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
							
			ArrayList<Integer> windowSize=getWindowSize();
		//enter the action charge reason and then clicking on into action charge button
		getBasePage().switchToParentAndChildFrame(FramesConfigs.baseFrame, FramesConfigs.secondFrame);
		ccrPage.selectSalesChannel("CCC inbound");
		ccrPage.enterActionChrgReason(actionChngeReason).clickOnActionChargeBtn();
		
		
		
		
		//switching to child window and return parent window id
		String parentWindowId =switchToWindow();
		
		windowMaximize(windowSize.get(0), windowSize.get(1));
		
		
	    getWaitUtil().waitForTitle("SRT Action Registration");
	    //srtActionRegWindPage.clickOnCloneGSCReplacementRadioBtn().clickOnSelectBtn();
	    
	    srtActionRegWindPage.clickOnPrepaidRadioBtn().clickOnSelectBtn();
	    
	    getDriver().switchTo().window(parentWindowId);
	    
	    getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.secondFrame);
	    
		ccrPage.clickDoneBtn();
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame);
		try {
			ccrPage.clickContinueBtn();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/*getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
		mainTainReqPage.clickOnOverrideChkBox().enterRemarks("dsdsdf").clickOnOverrideBtn();*/
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame("basefrm");
		mainTainReqPage.clickOnSubReqIdLbl();
		
	}
	
	public void clickOnTillSubRequestLabel1(String subRequestType,String accountNo,String actionChngeReason) {
		
		ccrPage = new CaptureCustomerRequestPage(getDriver());
		srtActionRegWindPage = new SRTActionRegistrationWindowPage(getDriver());
		mainTainReqPage = new MaintainRequestPage(getDriver());
		successFullOperPage = new SuccessfulOperationPage(getDriver());
		reqInquiryPage = new RequestInquiryPage(getDriver());
						

			try {
			
				getHomePage().navigateToFavoriteTab().navigateToCCRSubTab().selectSubRequestType(subRequestType).enterAccountNumber(accountNo).
				clickOnAccountNumberAndTab();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		
		//enter the action charge reason and then clicking on into action charge button
		getBasePage().switchToParentAndChildFrame(FramesConfigs.baseFrame, FramesConfigs.secondFrame);
		ccrPage.enterActionChrgReason(actionChngeReason).clickOnActionChargeBtn();
		
		
		ArrayList<Integer> windowSize=getWindowSize();
		
		//switching to child window and return parent window id
				String parentWindowId =switchToWindow();
		
		windowMaximize(windowSize.get(0), windowSize.get(1));
		
		
	    getWaitUtil().waitForTitle("SRT Action Registration");
	    //srtActionRegWindPage.clickOnCloneGSCReplacementRadioBtn().clickOnSelectBtn();
	    
	    srtActionRegWindPage.clickOnPrepaidRadioBtn().clickOnSelectBtn();
	    
	    getDriver().switchTo().window(parentWindowId);
	    
	    getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.secondFrame);
	    
		ccrPage.clickDoneBtn();
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame);
		try {
			ccrPage.clickContinueBtn();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
/*		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
		mainTainReqPage.clickOnOverrideChkBox().enterRemarks("dsdsdf").clickOnOverrideBtn();*/
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame("basefrm");
		mainTainReqPage.clickOnSubReqIdLbl();
		
	}
	
	public String  clickOnVerifiedOrginalDocTillSearch() {
		
		ccrPage = new CaptureCustomerRequestPage(getDriver());
		srtActionRegWindPage = new SRTActionRegistrationWindowPage(getDriver());
		mainTainReqPage = new MaintainRequestPage(getDriver());
		docFrmProfileWindowPage = new DocumentFrmProfileWindowPage(getDriver());
		successFullOperPage = new SuccessfulOperationPage(getDriver());
		reqInquiryPage = new RequestInquiryPage(getDriver());
		
		//switching to date Single Select child window and return parent window id
	    String parentWindowId2 =switchToWindow1();
	    //getWaitUtil().waitForTitle("Party Documents");
	    docFrmProfileWindowPage.clickOnDocumentRadioBtn().clickOnSelectBtn();
	    
	    getDriver().switchTo().window(parentWindowId2);
	    getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
	    mainTainReqPage.clickOnSave();
	    	    
	    getWaitUtil().elementPresence(mainTainReqPage.completeLbl, WaitConfigs.pageLoadWait);
	    Reporter.log("Landed on to the Compete Page");
	    
	   /* getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame);
		mainTainReqPage.clickOnRequestActivitiesBtn();*/
		
		//getDriver().switchTo().defaultContent();
		//getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
		//mainTainReqPage.clickOnOverrideChkBox().enterRemarks("dsdsdf").clickOnOverrideBtn();
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame);
		mainTainReqPage.clickOnSaveButton2();
		
		getWaitUtil().elementPresence(successFullOperPage.successTitleLbl, WaitConfigs.pageLoadWait);
		Reporter.log("Landed on to the SuccessFull Operation Page");
		
		String successOperationTitle = successFullOperPage.getSuccessOperationTitle();
		Assert.assertEquals(successOperationTitle, "Successful Operation", "text is not matching");
				
		String subRequestId = successFullOperPage.getSubRequestId();
		System.out.println("the sub request id ==>"+subRequestId);
		String tt = subRequestId.split(":")[1];		
		Reporter.log("The sub request id::"+tt);
		System.out.println("the splited sub request id ==>"+tt);
		try {
			getHomePage().clickMenuTree().clickOnDocImg().navigateToFavoriteTab().navigateToRequestInquirySubTab().enterSubReqId(tt).clickOnSearch();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		return tt;
	}
	
public String  clickOnVerifiedOrginalDocTillSearch1() {
		
		ccrPage = new CaptureCustomerRequestPage(getDriver());
		srtActionRegWindPage = new SRTActionRegistrationWindowPage(getDriver());
		mainTainReqPage = new MaintainRequestPage(getDriver());
		docFrmProfileWindowPage = new DocumentFrmProfileWindowPage(getDriver());
		successFullOperPage = new SuccessfulOperationPage(getDriver());
		reqInquiryPage = new RequestInquiryPage(getDriver());
		
		//switching to date Single Select child window and return parent window id
	    String parentWindowId2 =switchToWindow1();
	    //getWaitUtil().waitForTitle("Party Documents");
	    docFrmProfileWindowPage.clickOnDocumentRadioBtn().clickOnSelectBtn();
	    
	    getDriver().switchTo().window(parentWindowId2);
	    getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
	    mainTainReqPage.clickOnSave();
	    	    
	    getWaitUtil().elementPresence(mainTainReqPage.completeLbl, WaitConfigs.pageLoadWait);
	    Reporter.log("Landed on to the Compete Page");
	    
	    getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame);
		mainTainReqPage.clickOnSaveButton2();
		
		
		
		getWaitUtil().elementPresence(successFullOperPage.successTitleLbl, WaitConfigs.pageLoadWait);
		Reporter.log("Landed on to the SuccessFull Operation Page");
		
		String successOperationTitle = successFullOperPage.getSuccessOperationTitle();
		Assert.assertEquals(successOperationTitle, "Successful Operation", "text is not matching");
				
		String subRequestId = successFullOperPage.getSubRequestId();
		System.out.println("the sub request id ==>"+subRequestId);
		String tt = subRequestId.split(":")[1];		
		Reporter.log("The sub request id::"+tt);
		System.out.println("the splited sub request id ==>"+tt);
		try {
			getHomePage().clickMenuTree().clickOnDocImg().navigateToFavoriteTab().navigateToRequestInquirySubTab().enterSubReqId(tt).clickOnSearch();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		return tt;
	}
	
	

}
