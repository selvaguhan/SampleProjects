package com.cbcm.favoriteTab.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.base.utils.BasePage;

public class FavoritePage extends BasePage{
	
	By captureCustRequestTab= By.xpath("//a[contains(@id,'itemIconLink5')]");
	
	By requestInquiryTab= By.xpath("//a[contains(@id,'itemIconLink3')]");
	
	By accountInquiryTab= By.xpath("//a[contains(@id,'itemTextLink2')]");
	
	//By eLifeTransformationTab= By.xpath("//a[contains(text(),'eLife transformation')]/parent/parent::*//a[contains(@id,'itemIconLink6')]");
	
	By eLifeTransformationTab= By.id("itemTextLink6");
	
	By eLifeTransformationTabUAT= By.id("itemIconLink9");
	
	//By eLifeTransformationTab= By.xpath("//a[contains(text(),'eLife Transformation')]");
	
	public FavoritePage(WebDriver driver) {
		super(driver);
	}
	
	public CaptureCustomerRequestPage navigateToCCRSubTab() throws InterruptedException {
		getWaitUtils().waitForPage(2);
		 clickElementUsingJavaScript(captureCustRequestTab);
		 Reporter.log("Clicked on CCR Sub Tab");
		 getWaitUtils().waitForPage(2);
		return new CaptureCustomerRequestPage(getDriver());
		
	}
	
	public RequestInquiryPage navigateToRequestInquirySubTab() throws InterruptedException {
		getWaitUtils().waitForPage(10); 
		clickElementUsingJavaScript(requestInquiryTab);
		 Reporter.log("Clicked on Request Inquiry Sub Tab");
		 getWaitUtils().waitForPage(2);
		return new RequestInquiryPage(getDriver());
		
	}
	
	public AccountInquiryPage navigateToAccountInquirySubTab() throws InterruptedException {
		 getWaitUtils().waitForPage(10);
		 clickElementUsingJavaScript(accountInquiryTab);
		 Reporter.log("Clicked on Account Inquiry Sub Tab");
		 getWaitUtils().waitForPage(2);
		return new AccountInquiryPage(getDriver());
		
	}
	
	public RequestInquiryPage navigateToeLifeTransformationSubTab() throws InterruptedException {
		getWaitUtils().waitForPage(2);
		
		 if (getPropUtils().getEnvironment().equals("CBCM_UAT")) {
			//scrollIntoViewTillElement(eLifeTransformationTab);
			 clickElementUsingJavaScript(eLifeTransformationTabUAT);
			}else {
				//scrollIntoViewTillElement(eLifeTransformationTab);
				clickElementUsingJavaScript(eLifeTransformationTab);
			}
		 Reporter.log("Clicked on eLifeTransformation Sub Tab");
		 getWaitUtils().waitForPage(2);
		return new RequestInquiryPage(getDriver());
		
	}

}
