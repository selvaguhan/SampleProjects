package com.cbcm.favoriteTab.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.automation.configs.FramesConfigs;
import com.automation.configs.WaitConfigs;
import com.base.utils.BasePage;

public class CaptureCustomerRequestPage extends BasePage{
	
	By subRequestTypeSclt= By.id("subRequestTypeId");
	public By ratePlanTypeSclt= By.id("ratePlanId");
	public By accountNumberTxt = By.xpath("//input[contains(@id,'accountNumber')]");
	public By actionChrgReasonTxt = By.name("actionChrgReason");
			//("//textarea[contains(@name,'actionChrgReason')]");
	public By actionChargeBtn = By.xpath("//input[contains(@name,'actionChargeIdBtn')]");
	public By doneBtn = By.xpath("//button[contains(@id,'doneId')]");
	public By continueBtn= By.xpath("//button[contains(@id,'btnContinue') or contains(@title,'Press to Continue')]");
	
	public By partyIdTxt = By.name("partyId");
	public By partyNameTxt = By.name("partyFullName");
	
	public By mobileNumberTxt = By.name("mobileNumber");
	
	public By emailAddessTxt = By.name("emailAddress");
	
	public By contactNameTxt = By.name("contactName");
	
	public By portalRefNumberTxt = By.name("portalRefNumber");
	
	public By addRatePlanRow = By.name("addRow");
	
	
	public By packageCodeTxt1 = By.xpath("//input[contains(@name,'dtlCode')]");
	
			
	private By packageCodeTxt2 = By.xpath("(//input[contains(@name,'dtlCode') and contains(@type,'text')])[position()=2]");
	
	private By ratePlanCodeTxt = By.xpath("(//input[contains(@name,'dtlCode') and contains(@type,'text')])[position()=3]");
	
	private By salesChannelSclt= By.name("salesChannel");
	
	private By doneBtnMultiMate= By.name("done");
	public By partySubTypeLbl=By.xpath("//b[contains(text(),'Party Sub Type:')]"); 
	
	private By accountServicesCodeListBtn = By.id("accountServiceCodeListBtn");
	
	private By doneBtnForServices=By.xpath("//input[contains(@value,'Done') and contains(@type,'submit')]");
	
	public CaptureCustomerRequestPage(WebDriver driver) {
		super(driver);
	}
	
	public CaptureCustomerRequestPage selectSubRequestType(String subReqType) {
		switchFrame(FramesConfigs.baseFrame);
		getWaitUtils().elementPresence(By.xpath("//td[contains(text(),'Sub Request Type:') or contains(@title,'Sub Request Type')]"),30);
		selectValueFromDropDownByVisibleText(subRequestTypeSclt, subReqType);
		 Reporter.log("selected the sub request type is::"+subReqType);
		return this;
	}
	
	
	public CaptureCustomerRequestPage enterAccountNumber(String accountNum) {
		 safeType(accountNumberTxt,accountNum);
		 Reporter.log("the account no entered is ::"+accountNum);
		return this;
	}
	
	public CaptureCustomerRequestPage enterPartyIdAndClickOnTab(String partyId) {
		safeType(partyIdTxt,partyId);
		getDriver().findElement(partyIdTxt).click();
		getDriver().findElement(partyIdTxt).sendKeys(Keys.TAB);
		Reporter.log("the party id entered is ::"+partyId);
		return this;
	}
	
	public CaptureCustomerRequestPage clickOnAccountNumberAndTab() {
		clickOnElementAndTabKey(accountNumberTxt);
		getWaitUtils().elementPresence(By.xpath("//b[contains(text(),'Account Region:')]"), WaitConfigs.pageLoadWait);
        /*try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			
			System.out.println("unable to populate the data from the db based on account no");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return this;
	}
	
	public CaptureCustomerRequestPage enterActionChrgReason(String actionChrgReason) {
		getWaitUtils().isElementVisible(actionChrgReasonTxt,WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(actionChrgReasonTxt);
		typeText(actionChrgReasonTxt,actionChrgReason);
		Reporter.log("the action reason for change is ::"+actionChrgReason);
		return this;
	}
	
	public CaptureCustomerRequestPage clickOnActionChargeBtn() {
		getWaitUtils().isElementVisible(actionChargeBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(actionChargeBtn);
		clickByWebElement(actionChargeBtn);
		Reporter.log("clicked on action charge button");
		/* try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				
				System.out.println("unable to open action charge single select window:==>"+e);
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		return this;
	}
	
	public CaptureCustomerRequestPage clickDoneBtn() {
		scrollIntoViewTillElement(doneBtn);
		clickOnElementByJavaScriptExecutor(doneBtn);
		Reporter.log("clicked on done button");
		 try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				
				System.out.println("unable to click on Done button"+e);
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return this;
	}
	
	public CaptureCustomerRequestPage clickContinueBtn() throws InterruptedException {
		scrollIntoViewTillElement(continueBtn);
		safeClick(continueBtn);
		Reporter.log("clicked on continue button");
		 return this;
	}
	
	
	public CaptureCustomerRequestPage selectRatePlanType(String subReqType) {
		selectValueFromDropDownByVisibleText(ratePlanTypeSclt, subReqType);
		Reporter.log("selected the sub request type is::"+subReqType);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public CaptureCustomerRequestPage clickOnAddRatePlanRow() throws InterruptedException {
		scrollIntoViewTillElement(addRatePlanRow);
		safeClick(addRatePlanRow);
		Thread.sleep(1000);
		Reporter.log("clicked on addRatePlanRow button");
		 return this;
	}
	
	public CaptureCustomerRequestPage enterPackageCode1(String packageCode) throws InterruptedException {
		getWaitUtils().isElementVisible(packageCodeTxt1,WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(packageCodeTxt1);
		safeType(packageCodeTxt1,packageCode);
		clickOnTabKey(packageCodeTxt1);
		Thread.sleep(500);
		Reporter.log("the selected package 1 is ::"+packageCodeTxt1);
		return this;
	}
	
	public CaptureCustomerRequestPage enterPackageCode2(String packageCode) throws InterruptedException {
		getWaitUtils().isElementPresent(packageCodeTxt2,WaitConfigs.elementVisibleWait);
		//scrollIntoViewTillElement(packageCodeTxt2);
		clickOnElementByActions(packageCodeTxt2);
		safeType(packageCodeTxt2,packageCode);
		clickOnTabKey(packageCodeTxt2);
		Thread.sleep(500);
		Reporter.log("the selected package 2 is ::"+packageCodeTxt2);
		return this;
	}
	
	public CaptureCustomerRequestPage enterRatePlan(String ratePlan) throws InterruptedException {
		getWaitUtils().isElementVisible(ratePlanCodeTxt,WaitConfigs.elementVisibleWait);
		//scrollIntoViewTillElement(ratePlanCodeTxt);
		clickOnElementByActions(ratePlanCodeTxt);
		safeType(ratePlanCodeTxt,ratePlan);
		clickOnTabKey(ratePlanCodeTxt);
		Thread.sleep(500);
		Reporter.log("the selected rate plan is ::"+ratePlan);
		return this;
	}
	
	public CaptureCustomerRequestPage enterRatePlanForAddService(String ratePlan) throws InterruptedException {
		getWaitUtils().isElementVisible(packageCodeTxt1,WaitConfigs.elementVisibleWait);
		//scrollIntoViewTillElement(ratePlanCodeTxt);
		clickOnElementByActions(packageCodeTxt1);
		safeType(packageCodeTxt1,ratePlan);
		clickOnTabKey(packageCodeTxt1);
		Thread.sleep(500);
		Reporter.log("the selected rate plan is ::"+ratePlan);
		return this;
	}
	
	public CaptureCustomerRequestPage selectSalesChannel(String channelType) {
		selectValueFromDropDownByIndex(salesChannelSclt, channelType);
		Reporter.log("selected the sales channel type is::"+channelType);
		return this;
	}
	
	public CaptureCustomerRequestPage clickOnDoneBtnForMultiMate() throws InterruptedException {
		scrollIntoViewTillElement(doneBtnMultiMate);
		safeClick(doneBtnMultiMate);
		Reporter.log("clicked on doneBtnMultiMate button");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			
			System.out.println("unable to click on Done button"+e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return this;
	}
	
	public CaptureCustomerRequestPage clickOnAccountServicesListBtn() {
		getWaitUtils().isElementVisible(accountServicesCodeListBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(accountServicesCodeListBtn);
		clickByWebElement(accountServicesCodeListBtn);
		Reporter.log("clicked on accountServicesCodeList button");
		/* try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				
				System.out.println("unable to open action charge single select window:==>"+e);
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		return this;
	}
	
	
	public CaptureCustomerRequestPage clickOnDoneBtnForServices() {
		getWaitUtils().isElementVisible(doneBtnForServices, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(doneBtnForServices);
		clickOnElementByJavaScriptExecutor(doneBtnForServices);
		Reporter.log("clicked on doneBtnForServices button");
		return this;
	}
	
}
