package com.cbcm.favoriteTab.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.configs.WaitConfigs;
import com.base.utils.BasePage;

public class AccountInquiryPage extends BasePage{
	
	public By accountNumberTxt = By.xpath("//input[contains(@id,'accountNumber')]");
	public By searchBtn = By.xpath("//button[contains(@id,'search')]");
	
	public AccountInquiryPage(WebDriver driver) {
		super(driver);
	}
	
	public AccountInquiryPage enterAccountNo(String accountNum) {
		switchFrame("basefrm");
		typeText(accountNumberTxt, accountNum);
		return this;
	}
	
	public AccountInquiryPage clickOnSearch() {
		safeClick(searchBtn);
		getWaitUtils().waitForPage(WaitConfigs.pageLoadWait);
		return this;
	}

}
