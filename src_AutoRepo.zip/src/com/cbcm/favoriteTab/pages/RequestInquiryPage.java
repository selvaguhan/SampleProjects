package com.cbcm.favoriteTab.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.configs.WaitConfigs;
import com.base.utils.BasePage;

public class RequestInquiryPage extends BasePage{

	
	public By subRequestIdTxt = By.xpath("//input[contains(@id,'subRequestId')]");
	public By searchBtn = By.xpath("//button[contains(@id,'search')]");
	public By closedLbl = By.xpath("//table[contains(@class,'tableWithTop1')]//td[contains(text(),'Closed)]");
	
	public RequestInquiryPage(WebDriver driver) {
		super(driver);
	}
	
	public RequestInquiryPage enterSubReqId(String subReqId) {
		switchFrame("basefrm");
		typeText(subRequestIdTxt, subReqId);
		return this;
	}
	
	public RequestInquiryPage clickOnSearch() {
		switchFrame("basefrm");
		safeClick(searchBtn);
		//waitForPage(60);
		getWaitUtils().waitForPage(WaitConfigs.pageLoadWait);
		return this;
	}
	
	
	
}
