package com.cbcm.clone.tests;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.Alert;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.automation.configs.AutomationConstants;
import com.automation.configs.DBQuerryConstants;
import com.automation.configs.FramesConfigs;
import com.base.utils.CBCMDbHelperClass;
import com.cbcm.DataProvider.CBCMDataProvider;
import com.cbcm.pages.MaintainRequestPage;
import com.cbcm.pages.SuccessfulOperationPage;
import com.cbcm.singleSelectWindow.pages.DocumentFrmProfileWindowPage;
import com.cbcm.superclass.CloneSuperClass;

public class PostPaidCloneTest extends CloneSuperClass {

	MaintainRequestPage mrPage;
	DocumentFrmProfileWindowPage docFrmProfileWindowPage;
	SuccessfulOperationPage successFullOperPage;
	CBCMDbHelperClass cbcmDbHelper;
	ArrayList<String> accNoList;
	ArrayList<String> serialNoList;

	@BeforeTest
	public void setUp() {
		launchBrowser();

	}

	@Test(dataProviderClass = CBCMDataProvider.class, dataProvider = "CloneTest001", testName = "CloneTest001", priority = 0)
	public void normalToCloneTestV1(String userName, String passWord, String subRequestType, String actionChngeReason, String accountNo, String simNo1, String simNo2, String fromDB) throws InterruptedException {

		login("jeevanrc", "Etisalat@123");

		windowHandle();

		cbcmDbHelper = new CBCMDbHelperClass();

		accNoList = cbcmDbHelper.getAccountNumbers(DBQuerryConstants.getPostPaidAccountNumbers);
		System.out.println("the account list from the cbcm db::" + accNoList);
		String accNo = accNoList.get(0);

		// the account list from the cbcm db::[0547056020, 0501804497, 0505558572]0564044534,0564044493,0564044489
		clickOnTillSubRequestLabel(subRequestType.toString().trim(), accNo, actionChngeReason);

		if (fromDB.equalsIgnoreCase(AutomationConstants.testInputFromDB)) {
			serialNoList = cbcmDbHelper.getFreeSerialNumberFromCBCMDB(2);
			simNo1 = serialNoList.get(0).toString().trim();
			simNo2 = serialNoList.get(1).toString().trim();
		} else {

			System.out.println("i am in the excel sheet:::::");
			ArrayList<String> serialNoListFromExcel = new ArrayList<String>();
			serialNoListFromExcel.add(simNo1);
			serialNoListFromExcel.add(simNo2);
			cbcmDbHelper.updateserilaNumStyleCode(serialNoListFromExcel);
			serialNoList = cbcmDbHelper.updateSerialNumbersIntheCSSDB(serialNoListFromExcel);
			simNo1 = serialNoList.get(0).toString().trim();
			simNo2 = serialNoList.get(1).toString().trim();
		}

		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
		mainTainReqPage.selectCardType(AutomationConstants.cloneType).clickOnAddBtn().enterResourceNo(simNo1).enterResourceCloneNo(simNo2).clickOnSave().clickOnVerifiedOrginalDocumentChkBox().clickOnDatButton();

		String subRquestId = clickOnVerifiedOrginalDocTillSearch();

		Reporter.log("the normal to clone sub request type::" + subRquestId);

		boolean stat = false;
		try {
			stat = getDBUtilities().verifySubRequestStatus("select status from t_soh_subrequest where subrequest_id =" + "'" + subRquestId.toString().trim() + "'");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// String status = dbUtil.executeQuerry("select status from t_soh_subrequest
		// where subrequest_id ="+"'"+tt.toString().trim()+"'");
		String status = null;
		if (stat) {
			status = "90";
		} else {
			status = "49464";
		}

		System.out.println("the status of the closed:==>" + status);
		Reporter.log("the status of the sub request is ::" + status);

		ArrayList<String> al = getDBUtilities().executeQuerry1("select NEW_ICCID_NO from t_soh_gsm_clone_sim_dtls where subrequest_id =" + "'" + subRquestId.toString().trim() + "'");
		System.out.println("sim no==>" + al);
		Reporter.log("the gsm clone sim dtls table sim numbers ::" + al);
		Assert.assertTrue(al.contains(simNo1));
		Reporter.log(simNo1 + "::should contain in the gsm clone sim dtls data base table ::" + al.contains(simNo1));
		Assert.assertTrue(al.contains(simNo2));
		Reporter.log(simNo2 + "::should contain in the gsm clone sim dtls data base table ::" + al.contains(simNo2));
		Assert.assertEquals(status, "90", "the request is closed");

	}

	// @Test(dataProviderClass = CBCMDataProvider.class, dataProvider ="CloneTest003", testName = "CloneTest003",priority=1)
	public void cloneToCloneTest(String userName, String passWord, String subRequestType, String actionChngeReason, String accountNo, String simNo1, String simNo2, String fromDB) throws InterruptedException {

		login("jeevanrc", "Etisalat@123");
		windowHandle();

		// String accNo = accountNo.trim();
		cbcmDbHelper = new CBCMDbHelperClass();
		// accNoList =
		// cbcmDbHelper.getAccountNumbers(DBQuerryConstants.getPostPaidAccountNumbers);

		clickOnTillSubRequestLabel(subRequestType.toString().trim(), "0564044492", actionChngeReason);

		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);

		if (fromDB.equalsIgnoreCase(AutomationConstants.testInputFromDB)) {
			serialNoList = cbcmDbHelper.getFreeSerialNumberFromCBCMDB(1);
			simNo2 = serialNoList.get(0).toString().trim();
		} else {

			System.out.println("i am in the excel sheet:::::");
			ArrayList<String> serialNoListFromExcel = new ArrayList<String>();
			serialNoListFromExcel.add(simNo2);
			cbcmDbHelper.updateserilaNumStyleCode(serialNoListFromExcel);
			serialNoList = cbcmDbHelper.updateSerialNumbersIntheCSSDB(serialNoListFromExcel);
			simNo2 = serialNoList.get(0).toString().trim();

		}

		System.out.println("the sim 2 no:" + simNo2);

		mainTainReqPage.enterCloneToCloneNo(simNo2.toString().trim());

		mainTainReqPage.clickOnSave().clickOnVerifiedOrginalDocumentChkBox().clickOnDatButton();

		String subRquestId = clickOnVerifiedOrginalDocTillSearch();

		Reporter.log("the clone to clone sub request type::" + subRquestId);

		boolean stat = false;
		try {
			stat = getDBUtilities().verifySubRequestStatus("select status from t_soh_subrequest where subrequest_id =" + "'" + subRquestId.toString().trim() + "'");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// String status = dbUtil.executeQuerry("select status from t_soh_subrequest
		// where subrequest_id ="+"'"+tt.toString().trim()+"'");
		String status = null;
		if (stat) {
			status = "90";
		} else {
			status = "49464";
		}

		System.out.println("the status of the closed:==>" + status);
		Reporter.log("the status of the sub request is ::" + status);

		/*
		 * ArrayList<String> al = getDBUtilities(). executeQuerry1("select NEW_ICCID_NO from t_soh_gsm_clone_sim_dtls where subrequest_id =" +"'"+subRquestId.toString().trim()+"'"); System.out.println("sim no==>"+al); Reporter.log("the gsm clone sim dtls table sim numbers ::"+al);
		 * 
		 * Reporter.log( simNo1+"::should contain in the gsm clone sim dtls data base table ::"+al. contains(simNo1)); Assert.assertTrue(al.contains(simNo1));
		 */

		// Reporter.log(simNo2+"::should contain in the gsm clone sim dtls data base
		// table ::"+al.contains(simNo2));
		Assert.assertEquals(status, "90", "the request is closed");

	}

	// @Test(dataProviderClass = CBCMDataProvider.class, dataProvider ="CloneTest002", testName = "CloneTest002",priority=2)
	public void cloneToNormal(String userName, String passWord, String subRequestType, String actionChngeReason, String accountNo, String simNo1, String simNo2) throws InterruptedException {

		login("jeevanrc", "Etisalat@123");
		windowHandle();

		String accNo = accountNo.trim();

		clickOnTillSubRequestLabel(subRequestType.toString().trim(), "0547059384", actionChngeReason);

		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
		mainTainReqPage.selectCardType("Normal");

		Alert alert = getDriver().switchTo().alert();
		alert.accept();

		mainTainReqPage.clickOnSave().clickOnVerifiedOrginalDocumentChkBox().clickOnDatButton();

		String subRquestId = clickOnVerifiedOrginalDocTillSearch();

		Reporter.log("the clone to normal sub request type::" + subRquestId);

		boolean stat = false;
		try {
			stat = getDBUtilities().verifySubRequestStatus("select status from t_soh_subrequest where subrequest_id =" + "'" + subRquestId.toString().trim() + "'");
		} catch (Exception e) {
			e.printStackTrace();
		}

		String status = null;
		if (stat) {
			status = "90";
		} else {
			status = "49464";
		}

		System.out.println("the status of the closed:==>" + status);
		Reporter.log("the status of the sub request is ==>" + status);

		String indicatorStatus = getDBUtilities().executeQuerry2("select INDICATOR from t_soh_gsm_clone_sim_dtls where subrequest_id =" + "'" + subRquestId.toString().trim() + "'");
		Reporter.log("the deactivated sim status is ==>" + indicatorStatus);

		ArrayList<String> al = getDBUtilities().executeQuerry1("select NEW_ICCID_NO from t_soh_gsm_clone_sim_dtls where subrequest_id =" + "'" + subRquestId.toString().trim() + "'");
		System.out.println("sim no==>" + al);
		Reporter.log("the deactivated sim no ==>" + al);

		Assert.assertEquals(indicatorStatus, "D", "the sim is  Deactivated");

		Assert.assertEquals(status, "90", "the request is closed");

		Assert.assertTrue(al.contains(simNo2), "the deactivated sim are same");

	}

	// @AfterTest(enabled=true)
	public void tearDown() {
		System.out.println("i am in after test method");
		final Runtime rt = Runtime.getRuntime();
		try {
			Process p = rt.exec("C:\\Users\\jekumar\\Desktop\\ieclose\\ieClose.bat");
		} catch (final IOException e) {
			throw new RuntimeException("Failed to run bat file.");
		}
	}

}
