package com.cbcm.backup;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.base.utils.BaseTest;
import com.base.utils.DBUtilities;
import com.cbcm.favoriteTab.pages.CaptureCustomerRequestPage;
import com.cbcm.favoriteTab.pages.RequestInquiryPage;
import com.cbcm.pages.MaintainRequestPage;
import com.cbcm.pages.SuccessfulOperationPage;
import com.cbcm.singleSelectWindow.pages.DocumentFrmProfileWindowPage;
import com.cbcm.singleSelectWindow.pages.SRTActionRegistrationWindowPage;

public class CloneRiplacementOfSimTest extends BaseTest {

		CaptureCustomerRequestPage ccrPage;
		SRTActionRegistrationWindowPage srtActionRegWindPage;
		MaintainRequestPage mainTainReqPage;
		DocumentFrmProfileWindowPage docFrmProfileWindowPage;
		SuccessfulOperationPage successFullOperPage;
		RequestInquiryPage reqInquiryPage;
		
		
		@Test()
		public void riplacementOfSimCloneTest() throws InterruptedException {
			launchBrowser();
			login("regressioncrc", "password@123");
			windowHandle();
			
			String accountNo ="0502997789";
			String simNo1 ="8997112209670453649";
			String simNo2="8997112209670453663";
			
			ccrPage = new CaptureCustomerRequestPage(getDriver());
			srtActionRegWindPage = new SRTActionRegistrationWindowPage(getDriver());
			mainTainReqPage = new MaintainRequestPage(getDriver());
			docFrmProfileWindowPage = new DocumentFrmProfileWindowPage(getDriver());
			successFullOperPage = new SuccessfulOperationPage(getDriver());
			reqInquiryPage = new RequestInquiryPage(getDriver());
			
			
			getHomePage().navigateToFavoriteTab().navigateToCCRSubTab().selectSubRequestType("Replacement of Sim Cards").enterAccountNumber(accountNo).
			clickOnAccountNumberAndTab();
			
			
			
			//enter the action charge reason and then clicking on into action charge button
			getBasePage().switchToParentAndChildFrame("basefrm", "secondFrame");
			ccrPage.enterActionChrgReason("asassa").clickOnActionChargeBtn();
			
			//switching to child window and return parent window id
		    String parentWindowId =switchToWindow();
		    
		    srtActionRegWindPage.clickOnCloneGSCReplacementRadioBtn().clickOnSelectBtn();
			
		    getDriver().switchTo().window(parentWindowId);
		    
		    getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("basefrm").switchTo().frame("secondFrame");
		    
			ccrPage.clickDoneBtn();
			
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("basefrm");
			ccrPage.clickContinueBtn();
			
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("basefrm").switchTo().frame("details");
			mainTainReqPage.clickOnOverrideChkBox().enterRemarks("dsdsdf").clickOnOverrideBtn();
			
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("basefrm");
			mainTainReqPage.clickOnSubReqIdLbl();
			
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("basefrm").switchTo().frame("details");
			mainTainReqPage.selectCardType("Clone").clickOnAddBtn().enterResourceNo(simNo1).enterResourceCloneNo(simNo2).
			clickOnSave().clickOnVerifiedOrginalDocumentChkBox().clickOnDatButton();
			
			//switching to date Single Select child window and return parent window id
		    String parentWindowId2 =switchToWindow();
		    docFrmProfileWindowPage.clickOnDocumentRadioBtn().clickOnSelectBtn();
		    
		    getDriver().switchTo().window(parentWindowId2);
		    getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("basefrm").switchTo().frame("details");
		    mainTainReqPage.clickOnSave();
		    
		    getWaitUtil().elementPresence(mainTainReqPage.completeLbl, 60);
		    
		    getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("basefrm");
			mainTainReqPage.clickOnSaveButton2();
			
			 getWaitUtil().elementPresence(successFullOperPage.successTitleLbl, 40);
			String successOperationTitle = successFullOperPage.getSuccessOperationTitle();
			Assert.assertEquals("text is not matching", "Successful Operation", successOperationTitle);
			
			String subRequestId = successFullOperPage.getSubRequestId();
			System.out.println("the sub request id ==>"+subRequestId);
			String tt = subRequestId.split(":")[1];		
			System.out.println("the splited sub request id ==>"+tt);
			getHomePage().clickMenuTree().clickOnDocImg().navigateToFavoriteTab().navigateToRequestInquirySubTab().enterSubReqId(tt).clickOnSearch();
			
			try {
			     TimeUnit.MINUTES.sleep(1);
			} catch (InterruptedException e) {
			    //Handle exception
			}
			
			getHomePage().navigateToFavoriteTab().navigateToRequestInquirySubTab().enterSubReqId(tt).clickOnSearch();
			
			String status = getDBUtilities().executeQuerry("select status from t_soh_subrequest where subrequest_id ="+"'"+tt.toString().trim()+"'");
			
			System.out.println("the status of the closed:==>"+status);
			
			Assert.assertEquals("the request is closed", "90", status);
				
			ArrayList<String> al = getDBUtilities().executeQuerry1("select NEW_ICCID_NO from t_soh_gsm_clone_sim_dtls where subrequest_id ="+"'"+tt.toString().trim()+"'");
			
			System.out.println("sim no==>"+al);
			Assert.assertTrue(al.contains(simNo1));
			Assert.assertTrue(al.contains(simNo2));
			
			getDriver().switchTo().defaultContent();
			getDriver().switchTo().frame("basefrm");
			
			(new WebDriverWait(getDriver(), 40)).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//html/frameset[@id='inqiryFrameSetId']/frame[@name='requestFrame']")));
			
			getWaitUtil().elementPresence(reqInquiryPage.closedLbl, 100);
			
			getWaitUtil().fluentWaitForElementTobeClickable(reqInquiryPage.closedLbl,30);
			String closedStatus =getDriver().findElement(reqInquiryPage.closedLbl).getText();
			System.out.println("the closed status is ===>"+closedStatus);
			getHomePage().navigateToFavoriteTab().navigateToAccountInquirySubTab().enterAccountNo(accountNo).clickOnSearch();			
			//successFullOperPage.clickOnOkBtn();
		}
}
