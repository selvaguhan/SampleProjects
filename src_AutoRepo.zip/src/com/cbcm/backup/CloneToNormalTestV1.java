package com.cbcm.backup;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.Alert;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.automation.configs.FramesConfigs;
import com.cbcm.DataProvider.CBCMDataProvider;
import com.cbcm.superclass.CloneSuperClass;

public class CloneToNormalTestV1 extends CloneSuperClass {
	
	@BeforeTest
	public void setUp() {
		launchBrowser();
		
	}
	
	@Test(dataProviderClass = CBCMDataProvider.class, dataProvider = "CloneTest002", testName = "CloneTest002",priority=1)
	public void cloneToNormalTest(String userName,String	passWord,String subRequestType
			,String actionChngeReason,String accountNo,String simNo1,String	simNo2) throws InterruptedException {
		
		login(userName,passWord);
		windowHandle();
		
		String accNo = accountNo.trim();
				
		//clickOnTillSubRequestLabel(subRequestType.toString().trim(),accNo,actionChngeReason,"");
		
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
		mainTainReqPage.selectCardType("Normal");
		
		Alert alert = getDriver().switchTo().alert();
		alert.accept();
		
		mainTainReqPage.clickOnSave().clickOnVerifiedOrginalDocumentChkBox().clickOnDatButton();
		
		String subRquestId=clickOnVerifiedOrginalDocTillSearch();
					
		
		boolean stat = false;
		try {
			stat = getDBUtilities().verifySubRequestStatus("select status from t_soh_subrequest where subrequest_id ="+"'"+subRquestId.toString().trim()+"'");
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		String status =null;
		if(stat) {
			status="90";
		}else {
			status="49464";
		}
		
		System.out.println("the status of the closed:==>"+status);
		Reporter.log("the status of the sub request is ==>"+status);
		
		String indicatorStatus = getDBUtilities().executeQuerry2("select INDICATOR from t_soh_subrequest where subrequest_id ="+"'"+subRquestId.toString().trim()+"'");
		Reporter.log("the deactivated sim status is ==>"+indicatorStatus);
		
		ArrayList<String> al = getDBUtilities().executeQuerry1("select NEW_ICCID_NO from t_soh_gsm_clone_sim_dtls where subrequest_id ="+"'"+subRquestId.toString().trim()+"'");
		System.out.println("sim no==>"+al);
		Reporter.log("the deactivated sim no ==>"+al);
		
		Assert.assertEquals(al.contains(simNo2), "the deactivated sim are same");
		
		Assert.assertEquals(indicatorStatus, "D", "the sim is  Deactivated");
		
		Assert.assertEquals(status,"90","the request is closed");
			
	}
	
	@AfterTest
	public void tearDown() {
		getDriver().quit();
		System.out.println("i am in after test method");
		quiteIeBrowser();
		/* final Runtime rt = Runtime.getRuntime();
			try {
			Process p=rt.exec("C:\\Users\\jekumar\\Desktop\\ieclose\\ieClose.bat"); 
			//p.destroyForcibly();
			} catch (final IOException e) {
			throw new RuntimeException("Failed to run bat file.");
			}*/
	}
}
