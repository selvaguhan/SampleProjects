package com.cbcm.backup;

import java.util.ArrayList;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.automation.configs.FramesConfigs;
import com.automation.configs.WaitConfigs;
import com.base.utils.BaseTest;
import com.cbcm.favoriteTab.pages.CaptureCustomerRequestPage;
import com.cbcm.favoriteTab.pages.RequestInquiryPage;
import com.cbcm.pages.MaintainRequestPage;
import com.cbcm.pages.SuccessfulOperationPage;
import com.cbcm.singleSelectWindow.pages.DocumentFrmProfileWindowPage;
import com.cbcm.singleSelectWindow.pages.SRTActionRegistrationWindowPage;

public class NormalToCloneTestNg extends BaseTest{
	


	CaptureCustomerRequestPage ccrPage;
	SRTActionRegistrationWindowPage srtActionRegWindPage;
	MaintainRequestPage mainTainReqPage;
	DocumentFrmProfileWindowPage docFrmProfileWindowPage;
	SuccessfulOperationPage successFullOperPage;
	RequestInquiryPage reqInquiryPage;
	
	@Test()
	public void normalToCloneTest() throws InterruptedException {
		launchBrowser();
		login("regressioncrc", "password@123");
		windowHandle();


		String accountNo ="0501117828";
		String simNo1 ="8997112209670468460";
		String simNo2="8997112209670468462";

		
		ccrPage = new CaptureCustomerRequestPage(getDriver());
		srtActionRegWindPage = new SRTActionRegistrationWindowPage(getDriver());
		mainTainReqPage = new MaintainRequestPage(getDriver());
		docFrmProfileWindowPage = new DocumentFrmProfileWindowPage(getDriver());
		successFullOperPage = new SuccessfulOperationPage(getDriver());
		reqInquiryPage = new RequestInquiryPage(getDriver());
		
		
		getHomePage().navigateToFavoriteTab().navigateToCCRSubTab().selectSubRequestType("Replacement of Sim Cards").enterAccountNumber(accountNo).
		clickOnAccountNumberAndTab();
				
		//enter the action charge reason and then clicking on into action charge button
		getBasePage().switchToParentAndChildFrame(FramesConfigs.baseFrame, FramesConfigs.secondFrame);
		ccrPage.enterActionChrgReason("asassa").clickOnActionChargeBtn();
		
		
		//switching to child window and return parent window id
	    String parentWindowId =switchToWindow();
	    getWaitUtil().waitForTitle("SRT Action Registration");
	    srtActionRegWindPage.clickOnCloneGSCReplacementRadioBtn().clickOnSelectBtn();
		
	    getDriver().switchTo().window(parentWindowId);
	    
	    getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.secondFrame);
	    
		ccrPage.clickDoneBtn();
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame);
		ccrPage.clickContinueBtn();
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
		mainTainReqPage.clickOnOverrideChkBox().enterRemarks("dsdsdf").clickOnOverrideBtn();
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame("basefrm");
		mainTainReqPage.clickOnSubReqIdLbl();
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
		mainTainReqPage.selectCardType("Clone").clickOnAddBtn().enterResourceNo(simNo1).enterResourceCloneNo(simNo2).
		clickOnSave().clickOnVerifiedOrginalDocumentChkBox().clickOnDatButton();
		
		//switching to date Single Select child window and return parent window id
	    String parentWindowId2 =switchToWindow1();
	    //getWaitUtil().waitForTitle("Party Documents");
	    docFrmProfileWindowPage.clickOnDocumentRadioBtn().clickOnSelectBtn();
	    
	    getDriver().switchTo().window(parentWindowId2);
	    getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
	    mainTainReqPage.clickOnSave();
	    
	    
	    getWaitUtil().elementPresence(mainTainReqPage.completeLbl, WaitConfigs.pageLoadWait);
	    
	    getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame);
		mainTainReqPage.clickOnSaveButton2();
		
		getWaitUtil().elementPresence(successFullOperPage.successTitleLbl, 40);
		
		String successOperationTitle = successFullOperPage.getSuccessOperationTitle();
		Assert.assertEquals(successOperationTitle, "Successful Operation", "text is not matching");
		
		String subRequestId = successFullOperPage.getSubRequestId();
		System.out.println("the sub request id ==>"+subRequestId);
		String tt = subRequestId.split(":")[1];		
		System.out.println("the splited sub request id ==>"+tt);
		getHomePage().clickMenuTree().clickOnDocImg().navigateToFavoriteTab().navigateToRequestInquirySubTab().enterSubReqId(tt).clickOnSearch();
		
		
		boolean stat = false;
		try {
			stat = getDBUtilities().verifySubRequestStatus("select status from t_soh_subrequest where subrequest_id ="+"'"+tt.toString().trim()+"'");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		//String status = dbUtil.executeQuerry("select status from t_soh_subrequest where subrequest_id ="+"'"+tt.toString().trim()+"'");
		String status =null;
		if(stat) {
			status="90";
		}else {
			status="49464";
		}
		
		System.out.println("the status of the closed:==>"+status);
			
		ArrayList<String> al = getDBUtilities().executeQuerry1("select NEW_ICCID_NO from t_soh_gsm_clone_sim_dtls where subrequest_id ="+"'"+tt.toString().trim()+"'");
		System.out.println("sim no==>"+al);
		
		Assert.assertTrue(al.contains(simNo1));
		Assert.assertTrue(al.contains(simNo2));
		
		Assert.assertEquals(status,"90","the request is closed");

			
	}


}
