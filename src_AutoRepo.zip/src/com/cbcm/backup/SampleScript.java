package com.cbcm.backup;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.base.utils.BaseTest;
import com.cbcm.favoriteTab.pages.CaptureCustomerRequestPage;
import com.cbcm.favoriteTab.pages.RequestInquiryPage;
import com.cbcm.pages.MaintainRequestPage;
import com.cbcm.pages.SuccessfulOperationPage;
import com.cbcm.singleSelectWindow.pages.DocumentFrmProfileWindowPage;
import com.cbcm.singleSelectWindow.pages.SRTActionRegistrationWindowPage;

public class SampleScript extends BaseTest {
	
	CaptureCustomerRequestPage ccrPage;
	SRTActionRegistrationWindowPage srtActionRegWindPage;
	MaintainRequestPage mainTainReqPage;
	DocumentFrmProfileWindowPage docFrmProfileWindowPage;
	SuccessfulOperationPage successFullOperPage;
	RequestInquiryPage reqInquiryPage;
	
	@Test()
	public void sampleScript() throws InterruptedException {
		
		
		WebDriver driver = launchBrowser();
		
		driver.get("https://10.37.247.91:8080/fsm/login.page");
		driver.navigate ().to("javascript:document.getElementById('overridelink').click()");
		
		driver.findElement(By.name("j_username")).sendKeys("admin");
		driver.findElement(By.name("j_password")).sendKeys("adminnimda");
		driver.findElement(By.id("login_submit")).click();
		Thread.sleep(5000);
				
		mouseOver(By.xpath("//ul[contains(@class,'ui-menu-list ui-helper-reset')]/li[contains(@id,'menu:menubar:fsmSubMenu')]/a"));
		Thread.sleep(1000);
		
		driver.findElement(By.id("menu:browseOrdersMenuItem")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.id("browseOrders:browseView:clearFilters")).click();
		Thread.sleep(3000);
		
		
		driver.findElement(By.id("browseOrders:browseView:filterDashboard:externalProcessSignOrderFilter:textFilterValueInput")).clear();
		driver.findElement(By.id("browseOrders:browseView:filterDashboard:externalProcessSignOrderFilter:textFilterValueInput")).sendKeys("619282256");
		Thread.sleep(3000);
		
		driver.findElement(By.id("browseOrders:browseView:search")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.id("browseOrders:browseView:dataTableComponent:browseView:0:businessKeyOrdGridCol:orderLink")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.id("taskList:form:taskList:0:taskId")).click();
		Thread.sleep(5000);
		
/*		driver.findElement(By.id("taskMenuForm:goToSchedulingMenuItem")).click();
		Thread.sleep(5000);*/
		
		driver.findElement(By.id("taskAssignForm:taskAssign:time:loadVariants")).click();
		Thread.sleep(5000);
		
		
		driver.findElement(By.xpath("//DIV[@id='taskAssignForm:taskAssign:time:taskSlots:employeeVariantFilterChbxMenu']/DIV[3]/UL/LI")).click();
		Thread.sleep(5000);
		
		
/*		driver.findElement(By.className("taskAssignForm:taskAssign:time:taskSlots:j_idt3369")).click();
		Thread.sleep(5000);*/
		
		
		
		driver.findElement(By.id("taskAssignForm:taskAssign:time:taskSlots:slotsDataTable:0:changeAppointmentBtn")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.id("taskAssignForm:taskAssign:time:taskSlots:j_idt3418")).click();
		Thread.sleep(5000);
		
		
		driver.findElement(By.id("taskAssignForm:taskAssign:time:taskSlots:noteTemplateSelect_label")).click();
		Thread.sleep(5000);
		
		
		
		driver.findElement(By.xpath("//div[contains(@id,'taskAssignForm:taskAssign:time:taskSlots:noteTemplateSelect_panel')]//li[contains(@data-label,'Unallocated')]")).click();
		Thread.sleep(5000);
		
		
		driver.findElement(By.id("taskAssignForm:taskAssign:time:taskSlots:changeApp")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//li[contains(@id,'taskTabs:form:taskItemsTab')]//a[contains(@id,'taskTabs:form:taskItemsTab')]")).click();
		Thread.sleep(5000);
		
		getBasePage().scrollIntoViewTillElement(By.xpath("//div[contains(@id,'itemProposalProp')]"));
		Thread.sleep(2000);
		
		List<WebElement> lst = driver.findElements(By.xpath("//div[contains(@id,'j_idt613:3:itemProposalProp')]"));
		
		ArrayList<String> siCodes = new ArrayList<String>();
		
		System.out.println("the list size::"+lst.size());
		
		for(int i=0;i<lst.size();i++) {
			String temp = lst.get(i).getText();
			siCodes.add(temp);
		}
		
		System.out.println("the si codesn ::"+siCodes);
		
		
		
		//List<WebElement> lst1 = driver.findElements(By.id("j_idt586:j_idt608:0:Eq:tab:0:chooseItemBtn"));
		getBasePage().scrollIntoViewTillElement(By.id("j_idt586:j_idt608:0:Eq:tab:1:chooseItemBtn"));
		driver.findElement(By.id("j_idt586:j_idt608:0:Eq:tab:1:chooseItemBtn")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(By.xpath("//input[contains(@id,'Eq:EqcaptureEquipment')]")).sendKeys("121231213");
		Thread.sleep(2000);
		//j_idt586:j_idt608:0:Eq:EqcaptureEquipment:j_idt639:4:j_idt640:j_idt640_Inpt
		
		driver.findElement(By.id("j_idt586:j_idt608:0:Eq:tab:1:chooseItemBtn")).click();
		Thread.sleep(2000);
		
		//ArrayList<String> siCodes = new ArrayList<String>();
		
		/*System.out.println("the list size::"+lst1.size());
		
		System.out.println("the list size::"+lst1);*/
		/*for(int i=0;i<lst1.size();i++) {
			lst1.get(i).click();
		}*/
		
		//lst1.get(0).click();
		
		//System.out.println("the si codesn ::"+siCodes);
		
		/*try {
			Runtime.getRuntime().exec("C://Users//jekumar//Desktop//autoIT//testDemo.exe");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//getActions().moveToElement(getDriver().findElement(By.id("clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"))).doubleClick().build().perform();
*/		
		
		
	}

}
