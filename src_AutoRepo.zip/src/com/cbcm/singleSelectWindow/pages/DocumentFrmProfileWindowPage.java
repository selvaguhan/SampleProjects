package com.cbcm.singleSelectWindow.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.base.utils.BasePage;

public class DocumentFrmProfileWindowPage extends BasePage{
	
	private By documentRadioBtn = By.xpath("//input[contains(@name,'sel') and contains(@type,'radio')]");
	private By selectBtn = By.xpath("//input[contains(@value,'Select')]");

	
	public DocumentFrmProfileWindowPage(WebDriver driver) {
		super(driver);
	}
	
	public DocumentFrmProfileWindowPage clickOnDocumentRadioBtn() {
		getWaitUtils().elementPresence(documentRadioBtn,40);
		scrollIntoViewTillElement(documentRadioBtn);
		safeClick(documentRadioBtn);
		return this;
	}
	
	public DocumentFrmProfileWindowPage clickOnSelectBtn() {
		scrollIntoViewTillElement(selectBtn);
		safeClick(selectBtn);
		try {
			//Thread.sleep(3000);
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

}
