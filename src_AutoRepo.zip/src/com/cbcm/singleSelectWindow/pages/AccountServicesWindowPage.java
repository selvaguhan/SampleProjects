package com.cbcm.singleSelectWindow.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.configs.WaitConfigs;
import com.base.utils.BasePage;

public class AccountServicesWindowPage extends BasePage{
	
	//private By radioBtn = By.className("checkboxfield");
	
	private By radioBtn = By.xpath("//td[contains(text(),'RP616290')]/parent::*//input[contains(@class,'checkboxfield')]");
	private By addSelectionBtn = By.xpath("//button[contains(@class,'button') and contains(@onclick,'returnSelect')]");
	private By closeBtn = By.xpath("//button[contains(@class,'button') and contains(@onclick,'self.close')]");
	
	public AccountServicesWindowPage(WebDriver driver) {
		super(driver);
	}
	
	public AccountServicesWindowPage clickOnSerivceCodeRadioBtn() {
		
		getWaitUtils().elementPresence(radioBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(radioBtn);
		clickByWebElement(radioBtn);
		return this;
	}
	
	public AccountServicesWindowPage clickOnAddSelectionBtn() {
		
		getWaitUtils().elementPresence(addSelectionBtn, WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(addSelectionBtn);
		clickByWebElement(addSelectionBtn);
		return this;
	}
	public AccountServicesWindowPage clickOnCloseBtn() {
		
		scrollIntoViewTillElement(closeBtn);
		clickByWebElement(closeBtn);
		return this;
	}

}
