package com.cbcm.singleSelectWindow.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.automation.configs.WaitConfigs;
import com.base.utils.BasePage;

public class SRTActionRegistrationWindowPage extends BasePage{
	
	private By cloneGSCReplacementRadioBtn = By.xpath("//input[contains(@value,'srtSrvcActionId=2209&subrequestTypeId=70')]"); 
	private By selectBtn = By.xpath("//button[contains(@title,'Select') or contains(@onclick,'returnSelect()')]");
	
	private By prepaidRadioBtn = By.xpath("//td[contains(text(),'CLONEGSF_REPLACEMENT') or contains(text(),'CLONEWSF_REPLACEMENT')]/parent::*//input[contains(@class,'radiobuttonfield')]");
	
	public SRTActionRegistrationWindowPage(WebDriver driver) {
		super(driver);
	}
	
	public SRTActionRegistrationWindowPage clickOnCloneGSCReplacementRadioBtn() {
		getWaitUtils().elementPresence(By.xpath("//td[contains(text(),'SRT Action Registration Search')]"),40);
		clickOnElementByActions(cloneGSCReplacementRadioBtn);
		Reporter.log("clicked on gsc replacement radio Btn");
		return this;
	}
	
	public SRTActionRegistrationWindowPage clickOnPrepaidRadioBtn() {
		getWaitUtils().elementPresence(By.xpath("//td[contains(text(),'SRT Action Registration Search')]"),40);
		clickOnElementByActions(prepaidRadioBtn);
		Reporter.log("clicked on clickOnPrepaidRadioBtn radio Btn");
		return this;
	}
	
	public SRTActionRegistrationWindowPage clickOnSelectBtn() {
		scrollIntoViewTillElement(selectBtn);
		clickElementUsingJavaScript(selectBtn);
		Reporter.log("clicked on select Btn");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

}
