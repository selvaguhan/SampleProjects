package com.cbcm.singleSelectWindow.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.configs.WaitConfigs;
import com.base.utils.BasePage;

public class MaintainPartySearchWindowPage extends BasePage{
	
	
	private By searchCriteriaLbl = By.xpath("//strong[contains(text(),'Search Criteria')]");
	private By partyIdRadioBtn= By.className("radiobuttonfield");
	
	private By selectBtn= By.xpath("//button[contains(@class,'button') and contains(@onclick,'returnSelect')]");
	
	public MaintainPartySearchWindowPage(WebDriver driver) {
		super(driver);
	}
	
	public MaintainPartySearchWindowPage waitForPartrySearchWindow() {
		getWaitUtils().elementPresence(searchCriteriaLbl,WaitConfigs.elementVisibleWait);
		return this;
	}
	
	public MaintainPartySearchWindowPage clickOnPartyIdRadioBtn() {
		getWaitUtils().elementPresence(partyIdRadioBtn,WaitConfigs.elementVisibleWait);
		clickByWebElement(partyIdRadioBtn);
		return this;
	}
	
	public MaintainPartySearchWindowPage clickOnSelectBtn() {
		getWaitUtils().elementPresence(selectBtn,WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(selectBtn);
		clickByWebElement(selectBtn);
		return this;
	}

}
