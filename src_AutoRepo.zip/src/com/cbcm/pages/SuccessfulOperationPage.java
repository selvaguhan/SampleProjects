package com.cbcm.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.base.utils.BasePage;

public class SuccessfulOperationPage extends BasePage{
	
	public By successTitleLbl = By.xpath("//td[contains(@class,'titleBig')]");
	private By subRequestIdLbl = By.xpath("//table[contains(@class,'tableStyle1')]//td//font[contains(@color,'blue') or contains(text(),'Sub Request Id')]");
	private By okBtn = By.xpath("//input[contains(@value,'OK') and contains(@name,'button')]");
    
	
	public SuccessfulOperationPage(WebDriver driver) {
		super(driver);
	}
	
	public String getSuccessOperationTitle() {
		switchFrame("basefrm");
		String successTitle = getDriver().findElement(successTitleLbl).getText(); 
		return successTitle;
	}
	
	public String getSubRequestId() {
		String subRequestId = getDriver().findElement(subRequestIdLbl).getText(); 
		return subRequestId;
	}
	
	public SuccessfulOperationPage clickOnOkBtn() {
		scrollIntoViewTillElement(okBtn);
		clickByWebElement(okBtn);
		getDriver().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		return this;
	}
}
