package com.cbcm.pages;



import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import com.automation.configs.WaitConfigs;
import com.base.utils.BasePage;
import com.cbcm.favoriteTab.pages.CaptureCustomerRequestPage;

public class MaintainRequestPage extends BasePage{
	private By overrideChk = By.xpath("//input[contains(@name,'overrideFlag1')]");
	private By remarksTxt = By.xpath("//input[contains(@name,'remarks')]");
	private By overrideBtn = By.xpath("//input[contains(@name,'overrideBtn')]");
	private By subReqIdLbl = By.xpath("//input[contains(@name,'subReqId')]");
	private By cardTypeSclt = By.xpath("//select[contains(@name,'cardType')]");
	private By addBtn = By.xpath("//button[contains(@id,'addCloneId')]");
	private By resourceNoTxt = By.xpath("//input[contains(@id,'otherResourceNumber')]");
	private By resourceCloneNoTxt = By.xpath("//input[contains(@name,'resourceCloneNo') or contains(@id,'resourceCloneId')]");
	private By cloneToCloneResourceNoTxt = By.xpath("(//input[contains(@name,'resourceCloneNo')])[position()=2]");
	public By saveBtn = By.xpath("//button[contains(@id,'Save') and contains(@class,'submit')]");
	public By saveBtn1 = By.id("Save");
	private By verifiedOrginalDocChk = By.xpath("//input[contains(@id,'verifiedCheckbox')]");
	private By dateButton = By.xpath("//input[contains(@class,'dateButton')]");
	public By saveBtn2 = By.xpath("//button[contains(@id,'Save') and contains(@class,'button')]");
	public By saveBtn3 = By.xpath("//button[contains(@name,'save') and contains(@class,'button')]");
	
	public By requestActivitiesBtn = By.name("RequestActivities");
	
	private By emailIdTxt = By.xpath("//input[contains(@name,'email') and contains(@type,'text')]");
	
	private By addBtn1 = By.xpath("//input[contains(@name,'add_button') and contains(@type,'button')]");
	
	private By directoryCodeSclt = By.name("directoryCode");
	
	private By areaCodeTxt = By.id("areaCode");
	
	private By numberTxt = By.id("productNumber");
	
	private By nextBtn= By.name("next");
	
	private By capProfileSclt= By.id("capProfile");
	
	
	public By completeLbl = By.xpath("//a[contains(@id,'addOption') or contains(text(),'Capture Other Resource Information') or contains(text(),'Capture Document Type Information')]");
	
	public By requestActivityLbl = By.xpath("//*[contains(text(),'Request Activity')]");	
	
	public By accountInformationLbl = By.xpath("//b[contains(text(),'Account Information')]");
	
	public By invoiceDetailsLbl = By.xpath("//b[contains(text(),'Invoice Details')]");
	
	public By dqDetailsLbl = By.xpath("//b[contains(text(),'DQ Details')]");
	
	public By captureNumInformationLbl = By.xpath("//b[contains(text(),'Capture Number Information')]");
	
	public By captureOtherResourceInformartionLbl = By.xpath("//b[contains(text(),'Capture Other Resource Information')]");
	
	public By captureCapProfileLbl = By.xpath("//b[contains(text(),'Capture Cap Profile')]");
	
	public By subrequestDetailsLbl = By.xpath("//b[contains(text(),'Subrequest Details')]");
	
	
	public MaintainRequestPage(WebDriver driver) {
		super(driver);
	}
	
	public MaintainRequestPage clickOnOverrideChkBox() {
		getWaitUtils().isElementVisible(overrideChk,WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(overrideChk);
		safeClick(overrideChk);
		Reporter.log("clicked on override check box");
		return this;
	}
	
	public MaintainRequestPage enterRemarks(String remarks) {
		safeType(remarksTxt, remarks);
		Reporter.log("entered the remarks text::"+remarks);
		return this;
	}
	
	public MaintainRequestPage clickOnOverrideBtn() {
		safeClick(overrideBtn);
		Reporter.log("clicked on override button");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public MaintainRequestPage clickOnSubReqIdLbl() {
		scrollIntoViewTillElement(subReqIdLbl);
		safeClick(subReqIdLbl);
		Reporter.log("clicked on sub request label");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public MaintainRequestPage selectCardType(String cardType) {
		getWaitUtils().elementPresence(By.xpath("//label[contains(@id,'cardTypeLabel')]"), 40);
		//getWaitUtils().isElementVisible(cardTypeSclt,WaitConfigs.elementVisibleWait);
		selectValueFromDropDownByVisibleText(cardTypeSclt, cardType);
		Reporter.log("slected the card type::"+cardType);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	
	
	public MaintainRequestPage clickOnAddBtn() {
		getWaitUtils().isElementVisible(addBtn,WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(addBtn);
		safeClick(addBtn);
		Reporter.log("clicked on add button");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return this;
	}
	
	public MaintainRequestPage enterResourceNo(String resourceNo) {
		getWaitUtils().isElementPresent(resourceNoTxt,WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(resourceNoTxt);
		safeType(resourceNoTxt, resourceNo);
		Reporter.log("Entered Resource Sim no1::"+resourceNo);
		return this;
	}
	
	
	
	public MaintainRequestPage enterResourceCloneNo(String resourceCloneNo) {
		
		
		try {
			getWaitUtils().isElementPresent(resourceCloneNoTxt,WaitConfigs.elementVisibleWait);
			scrollIntoViewTillElement(resourceCloneNoTxt);
			safeType(resourceCloneNoTxt, resourceCloneNo);
			Reporter.log("Entered Resource Clone Sim no2::"+resourceCloneNo);
		} catch (UnhandledAlertException f) {
		    try {
		        Alert alert = getDriver().switchTo().alert();
		        String alertText = alert.getText();
		        System.out.println("Alert data: " + alertText);
		        alert.accept();
		    } catch (NoAlertPresentException e) {
		        e.printStackTrace();
		    }
		}
		return this;
	}
	
public MaintainRequestPage enterCloneToCloneNo(String resourceCloneNo) {
		
		
			try {
				
				getWaitUtils().isElementPresent(resourceCloneNoTxt,WaitConfigs.elementVisibleWait);
				getDriver().findElement(resourceCloneNoTxt).clear();
				Alert alert = getDriver().switchTo().alert();
		        String alertText = alert.getText();
		        System.out.println("Alert data: " + alertText);
		        alert.accept();
			}catch (UnhandledAlertException e) {
				Alert alert = getDriver().switchTo().alert();
		        String alertText = alert.getText();
		        System.out.println("Alert data: " + alertText);
		        alert.accept();
			}
		
		try {
			
			//safeType(resourceCloneNoTxt, resourceCloneNo);
			getDriver().findElement(resourceCloneNoTxt).sendKeys(resourceCloneNo);
			Reporter.log("Entered Resource Clone Sim no2::"+resourceCloneNo);
		} catch (UnhandledAlertException f) {
		    try {
		        Alert alert = getDriver().switchTo().alert();
		        String alertText = alert.getText();
		        System.out.println("Alert data: " + alertText);
		        alert.accept();
		    } catch (NoAlertPresentException e) {
		        e.printStackTrace();
		    }
		}
		return this;
	}
	
	public MaintainRequestPage cloneToCloneResourceNo(String resourceCloneNo) {
		getWaitUtils().isElementVisible(cloneToCloneResourceNoTxt,WaitConfigs.elementVisibleWait);
		scrollIntoViewTillElement(cloneToCloneResourceNoTxt);
		safeType(cloneToCloneResourceNoTxt, resourceCloneNo);
		Reporter.log("Entered the clone to clone sim no::"+resourceCloneNo);
		return this;
	}
	
	public MaintainRequestPage clickOnSave() {
		getWaitUtils().elementPresence(saveBtn, 40);
		scrollIntoViewTillElement(saveBtn);
		clickElementUsingJavaScript(saveBtn);
		Reporter.log("clicked on save button");
		//getDriver().manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		//getWaitUtils().waitForPageLoad(WaitConfigs.pageLoadWait);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return this;
	}
	
	public MaintainRequestPage onClickFireEventSave() {
		
		getWaitUtils().elementPresence(saveBtn, 40);
		//scrollIntoViewTillElement(saveBtn);
		getDriver().findElement(saveBtn).submit();
		getActions().moveToElement(getDriver().findElement(saveBtn)).click().build().perform();
/*		onMouseOverEventFire(saveBtn1);
		onClickEventFire(saveBtn1);*/
		//clickByWebElement(saveBtn);
		
		//clickByWebElement(saveBtn);
		//clickOnElementByActions(saveBtn1);
		//onFocusEventFire(saveBtn1);
		//onClickEventFire(saveBtn1);
		Reporter.log("clicked on save button");
		return this;
	}
	
	public MaintainRequestPage clickOnSaveForMultiMate() {
		//getWaitUtils().elementPresence(saveBtn, 40);
		scrollIntoViewTillElement(saveBtn);
		safeClick(saveBtn);
		//clickElementUsingJavaScript(saveBtn);
		Reporter.log("clicked on save button");
		//getDriver().manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		//getWaitUtils().waitForPageLoad(WaitConfigs.pageLoadWait);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return this;
	}
	
	public MaintainRequestPage clickOnVerifiedOrginalDocumentChkBox() {
		//elementPresence(verifiedOrginalDocChk, 40);Verified-Original-Document :
		getWaitUtils().elementPresence(By.xpath("//td[contains(text(),'Verified-Original-Document :')]"), 
				WaitConfigs.pageLoadWait);
		clickByWebElement(verifiedOrginalDocChk);
		Reporter.log("clicked on verified orginal doc check box");
		//safeClick(verifiedOrginalDocChk);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public MaintainRequestPage clickOnDatButton() {
		//safeClick(dateButton);
		//getWaitUtils().isElementClickable(dateButton, WaitConfigs.elementVisibleWait);
		clickElementUsingJavaScript(dateButton);
		Reporter.log("clicked on date button");
		/*try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return this;
	}

	 public MaintainRequestPage clickOnSaveButton2() {
		 /*try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			scrollIntoViewTillElement(saveBtn2);
			clickOnElementByActions(saveBtn2);
			Reporter.log("clicked on bottom save button");
			//getWaitUtils().implicitlyWait(WaitConfigs.implictWaitTime);
			return this;
	}
	
	 public MaintainRequestPage clickOnSaveButton3() {
		 
			scrollIntoViewTillElement(saveBtn3);
			clickOnElementByActions(saveBtn3);
			Reporter.log("clicked on bottom save button");
			//getWaitUtils().implicitlyWait(WaitConfigs.implictWaitTime);
			return this;
	}
	 
	 public MaintainRequestPage enterEmailId(String emailId) {
			getWaitUtils().isElementPresent(emailIdTxt,WaitConfigs.elementVisibleWait);
			scrollIntoViewTillElement(emailIdTxt);
			safeType(emailIdTxt, emailId);
			Reporter.log("Entered email id::"+emailId);
			return this;
		}
	
	 public MaintainRequestPage clickOnAddBtn1() {
			getWaitUtils().isElementVisible(addBtn1,WaitConfigs.elementVisibleWait);
			scrollIntoViewTillElement(addBtn1);
			safeClick(addBtn1);
			Reporter.log("clicked on add button");
			return this;
		}
	
	 public MaintainRequestPage selectDirectoryCode(String directoryType) {
			selectValueFromDropDownByVisibleText(directoryCodeSclt, directoryType);
			Reporter.log("selected the directory code is::"+directoryType);
			return this;
		}
	 
	 public MaintainRequestPage enterAreaCode(String areaCode) {
			getWaitUtils().isElementPresent(areaCodeTxt,WaitConfigs.elementVisibleWait);
			scrollIntoViewTillElement(areaCodeTxt);
			safeType(areaCodeTxt, areaCode);
			clickOnTabKey(areaCodeTxt);
			Reporter.log("Entered Area Code::"+areaCode);
			return this;
		}
	 
	 public MaintainRequestPage enterNumber(String number) {
			getWaitUtils().isElementPresent(numberTxt,WaitConfigs.elementVisibleWait);
			scrollIntoViewTillElement(numberTxt);
			safeType(numberTxt, number);
			clickOnTabKey(numberTxt);
			Reporter.log("Entered Number is ::"+number);
			return this;
		}
	 
	 public MaintainRequestPage clickOnNextBtn() {
			getWaitUtils().isElementVisible(nextBtn,WaitConfigs.elementVisibleWait);
			scrollIntoViewTillElement(nextBtn);
			safeClick(nextBtn);
			Reporter.log("clicked on add button");
			return this;
		}
	 public MaintainRequestPage selectCapProfile(String capPrfolieType) {
			selectValueFromDropDownByVisibleText(capProfileSclt, capPrfolieType);
			Reporter.log("slected the cap profile type::"+capPrfolieType);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return this;
		}
	 
	 public MaintainRequestPage clickOnRequestActivitiesBtn() {
			getWaitUtils().isElementVisible(requestActivitiesBtn,WaitConfigs.elementVisibleWait);
			scrollIntoViewTillElement(requestActivitiesBtn);
			safeClick(requestActivitiesBtn);
			Reporter.log("clicked requestActivitiesBtn button");
			/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			return this;
		}
	 
}
