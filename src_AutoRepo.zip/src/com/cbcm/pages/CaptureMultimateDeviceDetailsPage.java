package com.cbcm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.base.utils.BasePage;

public class CaptureMultimateDeviceDetailsPage extends BasePage {
	
	public By captureMultiMateDeviceDetailsLbl = By.xpath("//td[contains(text(),'Capture Multimate Device Details')]");

	public CaptureMultimateDeviceDetailsPage(WebDriver driver) {
		super(driver);
	}

}
