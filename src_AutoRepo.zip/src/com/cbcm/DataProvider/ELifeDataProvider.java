package com.cbcm.DataProvider;

import java.io.File;

import org.testng.annotations.DataProvider;

import com.base.utils.ExcelUtil;

public class ELifeDataProvider {
	
	final static File currentDirectory = new File(new File("").getAbsolutePath());
	static String WORKING_DIR = currentDirectory.getAbsolutePath();

	static String filePath = WORKING_DIR + "" + File.separator + "src" + File.separator + "resources" + File.separator + "testdata";
	
	@DataProvider(name = "NewAccountTrippleETest")
	public static Object[][] NewAccountTrippleETest() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLife", "NewAccountTrippleETest");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "eContractAutoPayDirectDebit")
	public static Object[][] eContractAutoPayDirectDebit() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLife", "eContractAutoPayDirectDebit");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	
	@DataProvider(name = "removalOfFreeNortonAnti_Virus_AddService_146156Test")
	public static Object[][] removalOfFreeNortonAnti_Virus_AddService_146156Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLife", "removalOfFreeNortonAnti_Virus_AddService_146156Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "projectEnigma_NewAccount3P_142781Test")
	public static Object[][] projectEnigma_NewAccount3P_142781Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLife", "projectEnigma_NewAccount3P_142781Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "projectEnigma_SubscriberRequestCessation3P_142781Test")
	public static Object[][] projectEnigma_SubscriberRequestCessation3P_142781Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLife", "projectEnigma_SubscriberRequestCessation3P_142781Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	
	@DataProvider(name = "projectEnigma_DeleteServices3P_142781Test")
	public static Object[][] projectEnigma_DeleteServices3P_142781Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLife", "projectEnigma_DeleteServices3P_142781Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "change_RPS_Alshamil_Project_140992Test")
	public static Object[][] change_RPS_Alshamil_Project_140992Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLife", "change_RPS_Alshamil_Project_140992Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	

	@DataProvider(name = "rvCPEConsumerPhase2_NewAccount_144040Test")
	public static Object[][] rvCPEConsumerPhase2_NewAccount_144040Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLife", "rvCPEConsumerPhase2_NewAccount_144040Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "rvCPEPhase2CR_144167_AddServiceTest")
	public static Object[][] rvCPEPhase2CR_144167_AddServiceTest() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLife", "rvCPEPhase2CR_144167_AddServiceTest");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "applythe_100PercentDiscountOneLifeONforLitePromos_141238Test")
	public static Object[][] applythe_100PercentDiscountOneLifeONforLitePromos_141238Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLife", "applythe_100PercentDiscountOneLifeONforLitePromos_141238Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	
}
