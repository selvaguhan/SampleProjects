package com.cbcm.DataProvider;

import java.io.File;

import org.testng.annotations.DataProvider;

import com.base.utils.ExcelUtil;

public class ELifeDataProviderRC {
	

	
	final static File currentDirectory = new File(new File("").getAbsolutePath());
	static String WORKING_DIR = currentDirectory.getAbsolutePath();

	static String filePath = WORKING_DIR + "" + File.separator + "src" + File.separator + "resources" + File.separator + "testdata";
	
	@DataProvider(name = "NewAccountTrippleETest")
	public static Object[][] NewAccountTrippleETest() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "NewAccountTrippleETest");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "eContractAutoPayDirectDebit")
	public static Object[][] eContractAutoPayDirectDebit() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "eContractAutoPayDirectDebit");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	
	@DataProvider(name = "removalOfFreeNortonAnti_Virus_AddService_146156Test")
	public static Object[][] removalOfFreeNortonAnti_Virus_AddService_146156Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "removalOfFreeNortonAnti_Virus_AddService_146156Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "projectEnigma_NewAccount3P_142781Test")
	public static Object[][] projectEnigma_NewAccount3P_142781Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "projectEnigma_NewAccount3P_142781Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "projectEnigma_SubscriberRequestCessation3P_142781Test")
	public static Object[][] projectEnigma_SubscriberRequestCessation3P_142781Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "projectEnigma_SubscriberRequestCessation3P_142781Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	
	@DataProvider(name = "projectEnigma_DeleteServices3P_142781Test")
	public static Object[][] projectEnigma_DeleteServices3P_142781Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "projectEnigma_DeleteServices3P_142781Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "change_RPS_Alshamil_Project_140992Test")
	public static Object[][] change_RPS_Alshamil_Project_140992Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "change_RPS_Alshamil_Project_140992Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "rvCPEConsumerPhase2_NewAccount_144040Test")
	public static Object[][] rvCPEConsumerPhase2_NewAccount_144040Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "rvCPEConsumerPhase2_NewAccount_144040Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "rvCPEPhase2CR_144167_AddServiceTest")
	public static Object[][] rvCPEPhase2CR_144167_AddServiceTest() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "rvCPEPhase2CR_144167_AddServiceTest");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	
	
	@DataProvider(name = "inclusionOfESDPValuesInCIM_126721Test")
	public static Object[][] inclusionOfESDPValuesInCIM_126721Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "inclusionOfESDPValuesInCIM_126721Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "applythe_100PercentDiscountOneLifeONforLitePromos_141238Test")
	public static Object[][] applythe_100PercentDiscountOneLifeONforLitePromos_141238Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "inclusionOfESDPValuesInCIM_126721Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "tc_MIG_007_SOH_DELADSLToDualPlay_Migration")
	public static Object[][] tc_MIG_007_SOH_DELADSLToDualPlay_Migration() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "tc_MIG_007_SOH_DELADSLToDualPlay_Migration");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales")
	public static Object[][] tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRC", "tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	
}
