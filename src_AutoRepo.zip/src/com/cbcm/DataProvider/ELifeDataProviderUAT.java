package com.cbcm.DataProvider;

import java.io.File;

import org.testng.annotations.DataProvider;

import com.base.utils.ExcelUtil;

public class ELifeDataProviderUAT {
	
	final static File currentDirectory = new File(new File("").getAbsolutePath());
	static String WORKING_DIR = currentDirectory.getAbsolutePath();

	static String filePath = WORKING_DIR + "" + File.separator + "src" + File.separator + "resources" + File.separator + "testdata";
	
	@DataProvider(name = "rvCPEConsumerPhase2_NewAccount_144040Test")
	public static Object[][] rvCPEConsumerPhase2_NewAccount_144040Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeUAT", "rvCPEConsumerPhase2_NewAccount_144040Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "applythe_100PercentDiscountOneLifeONforLitePromos_141238Test")
	public static Object[][] applythe_100PercentDiscountOneLifeONforLitePromos_141238Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeUAT", "applythe_100PercentDiscountOneLifeONforLitePromos_141238Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "projectEnigma_NewAccount3P_142781Test")
	public static Object[][] projectEnigma_NewAccount3P_142781Test() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeUAT", "projectEnigma_NewAccount3P_142781Test");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "NewAccountTrippleETest")
	public static Object[][] NewAccountTrippleETest() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeUAT", "NewAccountTrippleETest");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}

}
