
package com.cbcm.DataProvider;

import java.io.File;

import org.testng.annotations.DataProvider;

import com.base.utils.ExcelUtil;

public class ElifeDataProviderRegRC {
	
	final static File currentDirectory = new File(new File("").getAbsolutePath());
	static String WORKING_DIR = currentDirectory.getAbsolutePath();

	static String filePath = WORKING_DIR + "" + File.separator + "src" + File.separator + "resources" + File.separator + "testdata";
	
	@DataProvider(name = "tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales")
	public static Object[][] tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"eLifeRegRC", "tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}

}
