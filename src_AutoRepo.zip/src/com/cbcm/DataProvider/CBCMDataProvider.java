package com.cbcm.DataProvider;

import java.io.File;

import org.testng.annotations.DataProvider;

import com.base.utils.ExcelUtil;



public class CBCMDataProvider {
	
	final static File currentDirectory = new File(new File("").getAbsolutePath());
	static String WORKING_DIR = currentDirectory.getAbsolutePath();

	static String filePath = WORKING_DIR + "" + File.separator + "src" + File.separator + "resources" + File.separator + "testdata";
	
	@DataProvider(name = "CloneTest001")
	public static Object[][] CloneTest001() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"cbcmData", "CloneTest001");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "CloneTest002")
	public static Object[][] CloneTest002() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"cbcmData", "CloneTest002");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "CloneTest003")
	public static Object[][] CloneTest003() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"cbcmData", "CloneTest003");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	
	@DataProvider(name = "MultiMate001")
	public static Object[][] MultiMate001() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"cbcmData", "MultiMate001");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "MultiMate002")
	public static Object[][] MultiMate002() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"cbcmData", "MultiMate002");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "DeleteServiceMultiMate")
	public static Object[][] DeleteServiceMultiMate() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"cbcmData", "DeleteServiceMultiMate");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	@DataProvider(name = "AddServiceMultiMate")
	public static Object[][] AddServiceMultiMate() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"cbcmData", "AddServiceMultiMate");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	
	//PrePaid data providers
	
	@DataProvider(name = "PrePaidNormalToClone")
	public static Object[][] PrePaidNormalToClone() {
		final Object[][] objReturn = ExcelUtil.getTableArray(filePath + "\\automationTestData.xls",
				"cbcmData", "PrePaidNormalToClone");
		System.out.println("the file loaction is==>" + filePath);
		return objReturn;
	}
	

	
	

}
