package com.cbcm.main.pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.automation.configs.FramesConfigs;
import com.base.utils.BasePage;
import com.cbcm.favoriteTab.pages.FavoritePage;


public class HomePage extends BasePage{
	
	WebDriver driver;
	
	By favoriteTabImg= By.xpath("//html//body//a[contains(@href,'javascript:clickOnNode')]/img[contains(@id,'nodeIcon1')]");
	
	By favoriteTabImgUAT= By.xpath("//html//body//a[contains(@href,'javascript:clickOnNode')]/img[contains(@id,'nodeIcon4')]");
	
	//By favoriteTabImgUAT= By.xpath("//a[contains(text(),'Favorite')]/parent::*//a[contains(@href,'javascript:clickOnNode')]/img[contains(@id,'nodeIcon')]");
	
	By menuTree = By.xpath("//div[contains(@style,'POSITION:')]/img[contains(@id,'treeImg')]");
	By docImg = By.id("dock");
	
	  public HomePage(WebDriver driver) {
	    super(driver);
	    this.driver = driver;
	   
	  }
	  
	  public HomePage clickMenuTree() {
		    try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		    switchFrame("basefrm");
		    clickElementUsingJavaScript(menuTree);
		    Reporter.log("Clicked on Menu Tree Button");
		    getWaitUtils().waitForPage(2);
		    return this;

		  }
	  
	  public HomePage clickOnDocImg() {
		    try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		    switchFrame("treeframe");
		    clickElementUsingJavaScript(docImg);
		    Reporter.log("Clicked on Doc Image");
		    getWaitUtils().waitForPage(2);
		    return this;

		  }
	  
	  public FavoritePage navigateToFavoriteTab() {
		    try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		    switchFrame(FramesConfigs.treeFrame);
		    
		    if (getPropUtils().getEnvironment().equals("CBCM_UAT")) {
		    	clickElementUsingJavaScript(favoriteTabImgUAT);
			}else {
				clickElementUsingJavaScript(favoriteTabImg);
			}
		    
		    
		    
		    Reporter.log("Clicked on Favorite Tab");
		    getWaitUtils().waitForPage(2);
		    return new FavoritePage(driver);

		  }
		   
}
