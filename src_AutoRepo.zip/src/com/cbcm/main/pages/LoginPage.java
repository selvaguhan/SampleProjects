package com.cbcm.main.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.base.utils.BasePage;


public class LoginPage extends BasePage {
	
	private final By userName = By.xpath("//input[contains(@id,'usernameforshow')]");
	
	private final By passWord = By.xpath("//input[contains(@id,'passwordforshow')]");
	
	private final By loginBtn = By.xpath("//input[contains(@class,'login-button')]");
	
	public LoginPage(WebDriver driver) {
		super(driver);
		
		}
	
	public HomePage login(String usrNme,String pssWord) {
		
		safeType(userName, usrNme);
		safeType(passWord, pssWord);
		safeClick(loginBtn);
		/*getDriver().findElement(userName).sendKeys(usrNme);
		getDriver().findElement(passWord).sendKeys(pssWord);
		getDriver().findElement(loginBtn).click();*/
		Reporter.log("The user name logged in:"+usrNme);
		//waitForPage(60);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new HomePage(getDriver());
		
	}
	

}
