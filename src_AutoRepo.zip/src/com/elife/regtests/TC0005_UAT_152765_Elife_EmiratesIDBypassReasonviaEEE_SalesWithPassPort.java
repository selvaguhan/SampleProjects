package com.elife.regtests;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.automation.configs.DBQuerryConstants;
import com.base.utils.BaseTest;
import com.cbcm.DataProvider.ELifeDataProviderRC;
import com.pages.elife.AccountDetailsPage;
import com.pages.elife.CustomerDetailsPage;
import com.pages.elife.ELifeApplicationDetailsPage;
import com.pages.elife.ELifeNewtWorkDetailsPage;

public class TC0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_SalesWithPassPort extends BaseTest {
	
	ELifeApplicationDetailsPage eLifePage;
	ELifeNewtWorkDetailsPage eflifeNetWorkDetailsPage;
	CustomerDetailsPage customerDetailsPage;
	AccountDetailsPage accountDetailsPage;
	
	@BeforeTest
	public void setUp() {
		//launchBrowser();
		launchElifeApplication();
		
	}
	
	@Test(dataProviderClass = ELifeDataProviderRC.class, dataProvider = "tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales", testName = "tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales",enabled=true)
	public void tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales(String userName,String passWord,String eidNumber,String custFName,String custLName,String docNumber,String issueAutority,
			String engAddr1,String custMobNo,String custEmailId,String accountFLName,String internetUsrName,String custEnvConNo,String custEnvConEmailId,String	webTVUsrNme,
			String contactPName,String	contactPMobNo,String partyID,String passPortRegion,String fromDB) throws InterruptedException {
			
			//login(userName,passWord);
			eLifePage = new ELifeApplicationDetailsPage(getDriver());
			eflifeNetWorkDetailsPage = new ELifeNewtWorkDetailsPage(getDriver());
			customerDetailsPage = new CustomerDetailsPage(getDriver());
			accountDetailsPage = new AccountDetailsPage(getDriver());
			
			/*windowHandle();
			
			ArrayList<Integer> windowSize=getWindowSize();
			
			getHomePage().navigateToFavoriteTab().navigateToeLifeTransformationSubTab();
			
			String parentWindow = switchToWindow();
			
			windowMaximize(windowSize.get(0),windowSize.get(1));*/
			
			eLifePage.clickOnServiceTypeDropDownBtn().selectSeriveTypeFilterAndclick("New Account").clickOnServiceRequiredLabel().
			selectServiceRequiredType("elife Triple Play").clickOnExistingCustRadioBtn("Yes");
			
			eflifeNetWorkDetailsPage.enterPartyID(partyID).clickPartyIDDetailsContinueFrmPopUp();
			
			eflifeNetWorkDetailsPage.clickPartyIDDetailsRadioBtnFrmPopUp().clickSubmitBtnFrmPartyIDDetailsFrmPopUp();
			
			Thread.sleep(4000);
			
			String custMobNumber1 = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			eLifePage.enterCustomerMobileNo1(custMobNumber1);
			
			eLifePage.enterContactEmailId("jekumar@etisalat.ae");
			
			eflifeNetWorkDetailsPage.clickOnEIDRadioBtn().enterEIDNumber(eidNumber).clickOnCheckAvaliablityLnk()
			.clickTVProgramLbl().selectTVProramOptionAndClick("Generic").clickOnNoOfRoomsInHouseLbl().selectTVRoomOptionAndClick("1 Room").
			clickOnCountryLbl().selectCountyOptionAndClick("Albania").clickOnRecorderRadioBtn()
			.clickOnProposePackageBtn().clickOnVasServiceIdChk().clickOnProceedBtnk();
			
			Thread.sleep(1500);
			eflifeNetWorkDetailsPage.clickYesBtnFrmPopUp();
			Thread.sleep(2500);
			eflifeNetWorkDetailsPage.clickYesBtnFrmPopUp1();
			Thread.sleep(2500);
			
			customerDetailsPage.clickOnCustTitleLbl().selectCustTitleOption().enterCustFname(custFName).enterCustLname(custLName).enterCustArabicFname(".").
			enterCustArabicLname(".").selectDOB("15","03","1995").clickOnCustNationalityLbl().selectCustNationalityOption("Albania").
			clickOnIdentityTypeLbl().selectIdentityTypeOption();
			
					
			//String custEmail="tat"+DBQuerryConstants.get3DigitRandomNumbers()+"@etisalat.ae";
			String custEmail="jekumar@etisalat.ae";
		
			String documentNum11 = docNumber.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			//String documentNum11 = "7841995"+DBQuerryConstants.get8DigitRandomNumbers();
			System.out.println("the document no::"+documentNum11);
			
			String custMobNumber = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			
			String visaNo="71"+DBQuerryConstants.get5DigitRandomNumbers();
			System.out.println("vis no::"+visaNo);
			
			String visaIssueAuthority="visaisue";
			String unifiedNo="51"+DBQuerryConstants.get5DigitRandomNumbers();
			
			customerDetailsPage.clickOnVerifiedDocChk();		
			Thread.sleep(1000);
			
			customerDetailsPage/*.selectIssueDate("16","Apr","2010")*/.enterVisaNo(visaNo).enterDocumentNo(documentNum11).selectExpiryDate("22", "Apr", "2021")
			.enterVisaIssueAuthority(visaIssueAuthority).selectVisaIssueDate("10","Apr","2017")
			.selectVisaExpiryDate("11", "Apr","2019").enterIssuingAuthority("asas").enterUniFiedNo(unifiedNo)
			.clickOnDocByPassReasonLbl();
			
			captureScreenshot(getDriver(), "PassPortReason:"+DBQuerryConstants.getRandomNumbers());
			
			String[] byPassReason = passPortRegion.split(",");
			
			for(int i=0;i<=byPassReason.length-1;i++) {
				System.out.println("pass port by reason is ::"+byPassReason[i]);
				By byPassReasonele=customerDetailsPage.getDocByPassReason(byPassReason[i]);
				String actualValue = getBasePage().getAttributeValue(byPassReasonele,"data-label");
				System.out.println("the attribute fetched value is::"+actualValue);
				Assert.assertEquals(actualValue, byPassReason[i],"passport by reason is not matching");
			}
				
			
	}

}
