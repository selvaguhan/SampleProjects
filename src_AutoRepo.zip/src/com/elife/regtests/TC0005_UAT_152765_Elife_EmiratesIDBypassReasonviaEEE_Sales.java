package com.elife.regtests;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.automation.configs.DBQuerryConstants;
import com.base.utils.BaseTest;
import com.base.utils.RQMUpdate;
import com.cbcm.DataProvider.ElifeDataProviderRegRC;
import com.pages.elife.AccountDetailsPage;
import com.pages.elife.CustomerDetailsPage;
import com.pages.elife.ELifeApplicationDetailsPage;
import com.pages.elife.ELifeNewtWorkDetailsPage;

public class TC0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales extends BaseTest{
	
	ELifeApplicationDetailsPage eLifePage;
	ELifeNewtWorkDetailsPage eflifeNetWorkDetailsPage;
	CustomerDetailsPage customerDetailsPage;
	AccountDetailsPage accountDetailsPage;
	
	ITestResult result;
	String testScrptName;
	String testPlanId ="7777";
	
	@BeforeTest
	public void setUp() {
		launchElifeApplication();
		
	}
	
	@Test(dataProviderClass = ElifeDataProviderRegRC.class, dataProvider = "tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales", testName = "tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales",enabled=true)
	public void tc0005_UAT_152765_Elife_EmiratesIDBypassReasonviaEEE_Sales(String userName,String passWord,String eidNumber,String custFName,String custLName,String docNumber,String issueAutority,
			String engAddr1,String custMobNo,String custEmailId,String accountFLName,String internetUsrName,String custEnvConNo,String custEnvConEmailId,String	webTVUsrNme,
			String contactPName,String	contactPMobNo,String partyID,String passPortRegion,String fromDB) throws InterruptedException {
	
			eLifePage = new ELifeApplicationDetailsPage(getDriver());
			eflifeNetWorkDetailsPage = new ELifeNewtWorkDetailsPage(getDriver());
			customerDetailsPage = new CustomerDetailsPage(getDriver());
			accountDetailsPage = new AccountDetailsPage(getDriver());
			
			
			eLifePage.clickOnServiceTypeDropDownBtn().selectSeriveTypeFilterAndclick("New Account").clickOnServiceRequiredLabel().
			selectServiceRequiredType("elife Triple Play").clickOnExistingCustRadioBtn("Yes");
			
			eflifeNetWorkDetailsPage.enterPartyID(partyID)/*.clickPartyIDDetailsContinueFrmPopUp()*/;
			
			eflifeNetWorkDetailsPage.clickPartyIDDetailsRadioBtnFrmPopUp().clickSubmitBtnFrmPartyIDDetailsFrmPopUp();
			
			Thread.sleep(4000);
			
			String custMobNumber1 = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			eLifePage.enterCustomerMobileNo1(custMobNumber1);
			
			eLifePage.enterContactEmailId("jekumar@etisalat.ae");
			
			eflifeNetWorkDetailsPage.clickOnEIDRadioBtn().enterEIDNumber(eidNumber).clickOnCheckAvaliablityLnk()
			.clickTVProgramLbl().selectTVProramOptionAndClick("Generic").clickOnNoOfRoomsInHouseLbl().selectTVRoomOptionAndClick("1 Room").
			clickOnCountryLbl().selectCountyOptionAndClick("Albania").clickOnRecorderRadioBtn()
			.clickOnProposePackageBtn().clickOnVasServiceIdChk().clickOnProceedBtnk();
			
			Thread.sleep(1500);
			eflifeNetWorkDetailsPage.clickYesBtnFrmPopUp();
			Thread.sleep(2500);
			eflifeNetWorkDetailsPage.clickYesBtnFrmPopUp1();
			Thread.sleep(2500);
			
			getBasePage().pageScrollDown();
			customerDetailsPage.clickOnVerifiedDocChk();		
			Thread.sleep(1000);
		
			customerDetailsPage.clickOnDocByPassReasonLbl();
			
			captureScreenshot(getDriver(), "PassPortReason:"+DBQuerryConstants.getRandomNumbers());
			
			String[] byPassReason = passPortRegion.split(",");
			
			for(int i=0;i<=byPassReason.length-1;i++) {
				System.out.println("pass port by reason is ::"+byPassReason[i]);
				By byPassReasonele=customerDetailsPage.getDocByPassReason(byPassReason[i]);
				String actualValue = getBasePage().getAttributeValue(byPassReasonele,"data-label");
				System.out.println("the attribute fetched value is::"+actualValue);
				Assert.assertEquals(actualValue, byPassReason[i],"EID bypass reasons are not matching");
			}
			
			testScrptName = getTestScriptName();
			
			result = getCurrentTestCaseResult();
			System.out.println("the current status ::"+result.getStatus());
			Reporter.log("the current test case status is ::"+result.getStatus());
			getSoftAssert().assertAll();
				
			
	}
	
	@AfterTest
	public void tearDown() {
		
		RQMUpdate.updateTestCaseStatusIntoRQM(testScrptName, result,"7777");
		getDriver().quit();
		
	}



}
