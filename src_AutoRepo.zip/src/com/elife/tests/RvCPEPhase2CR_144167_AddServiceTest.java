package com.elife.tests;

import java.util.ArrayList;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.automation.configs.DBQuerryConstants;
import com.automation.configs.WaitConfigs;
import com.base.utils.BaseTest;
import com.cbcm.DataProvider.ELifeDataProvider;
import com.cbcm.DataProvider.ELifeDataProviderRC;
import com.pages.elife.AccountDetailsPage;
import com.pages.elife.CustomerDetailsPage;
import com.pages.elife.ELifeApplicationDetailsPage;
import com.pages.elife.ELifeNewtWorkDetailsPage;

public class RvCPEPhase2CR_144167_AddServiceTest  extends BaseTest {

	ELifeApplicationDetailsPage eLifePage;
	ELifeNewtWorkDetailsPage eflifeNetWorkDetailsPage;
	CustomerDetailsPage customerDetailsPage;
	AccountDetailsPage accountDetailsPage;
	
	@BeforeTest
	public void setUp() {
		//launchBrowser();
		launchElifeApplication();
		
	}
	
	@Test(dataProviderClass = ELifeDataProvider.class, dataProvider = "rvCPEPhase2CR_144167_AddServiceTest", testName = "rvCPEPhase2CR_144167_AddServiceTest",enabled=true)
	public void rvCPEPhase2CR_144167_AddServiceTest(String userName,String passWord,String eidNumber,String custFName,String custLName,String docNumber,String issueAutority,
			String engAddr1,String custMobNo,String custEmailId,String accountFLName,String internetUsrName,String custEnvConNo,String custEnvConEmailId,String	webTVUsrNme,
			String contactPName,String	contactPMobNo,String fromDB,String accountNo) throws InterruptedException {
			
			//login(userName,passWord);
			eLifePage = new ELifeApplicationDetailsPage(getDriver());
			eflifeNetWorkDetailsPage = new ELifeNewtWorkDetailsPage(getDriver());
			customerDetailsPage = new CustomerDetailsPage(getDriver());
			accountDetailsPage = new AccountDetailsPage(getDriver());
			/*windowHandle();
			
			ArrayList<Integer> windowSize=getWindowSize();
			
			getHomePage().navigateToFavoriteTab().navigateToeLifeTransformationSubTab();
			
			String parentWindow = switchToWindow();
			
			windowMaximize(windowSize.get(0),windowSize.get(1));*/
			
			String custMobNumber1 = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			
			eLifePage.clickOnServiceTypeDropDownBtn().selectSeriveTypeFilterAndclick("Add Service").enterAccountNo(accountNo);
			
			//eflifeNetWorkDetailsPage.clickPartyIDDetailsContinueFrmPopUp();
			
			Thread.sleep(5000);
			
			String tt = getBasePage().getText(eLifePage.contactNumberText);
			System.out.println("the contact customer mobile number is:"+tt);
			
			if(tt.isEmpty()) {
				System.out.println("i am in the if block");
				getBasePage().typeText(eLifePage.contactNumberText,custMobNumber1);
			}
			
			eLifePage.enterContactEmailId("jekumar@etisalat.ae");
	
			
			getWaitUtil().elementPresence(eflifeNetWorkDetailsPage.searchWithCodeTxt1, WaitConfigs.pageLoadWait);
			getBasePage().scrollIntoViewTillElement(eflifeNetWorkDetailsPage.searchWithCodeTxt1);
			getBasePage().safeType(eflifeNetWorkDetailsPage.searchWithCodeTxt1, "RPTPVCPE");
			getBasePage().clickOnTabKey(eflifeNetWorkDetailsPage.searchWithCodeTxt1);
						
			getWaitUtil().elementPresence(eflifeNetWorkDetailsPage.getAddServicePlan("RPTPVCPE"), WaitConfigs.elementVisibleWait);
			getBasePage().scrollIntoViewTillElement(eflifeNetWorkDetailsPage.getAddServicePlan("RPTPVCPE"));
			eflifeNetWorkDetailsPage.selectAddServicePlan("RPTPVCPE");
			Thread.sleep(1000);
			getBasePage().clickElementUsingJavaScript(eflifeNetWorkDetailsPage.addBtn1);
			
			
			getBasePage().scrollIntoViewTillElement(eflifeNetWorkDetailsPage.searchWithCodeTxt1);
			getBasePage().safeType(eflifeNetWorkDetailsPage.searchWithCodeTxt1, "RPANTIVIRS");
			getBasePage().clickOnTabKey(eflifeNetWorkDetailsPage.searchWithCodeTxt1);
	
			getWaitUtil().elementPresence(eflifeNetWorkDetailsPage.getAddServicePlan("RPANTIVIRS"), WaitConfigs.elementVisibleWait);
			getBasePage().scrollIntoViewTillElement(eflifeNetWorkDetailsPage.getAddServicePlan("RPANTIVIRS"));
			eflifeNetWorkDetailsPage.selectAddServicePlan("RPANTIVIRS");
			Thread.sleep(1000);
			getBasePage().clickElementUsingJavaScript(eflifeNetWorkDetailsPage.addBtn1);
			
			Thread.sleep(1000);
			eflifeNetWorkDetailsPage.clickOnVasAddServiceIdChk().clickOnAddServiceProceedBtn();
			Thread.sleep(3000);
			
			String custMobNumber = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			String custEmail="jekumar@etisalat.ae";
			
			getWaitUtil().elementPresence(customerDetailsPage.docVerifyLbl, WaitConfigs.elementVisibleWait);
			getBasePage().scrollIntoViewTillElement(customerDetailsPage.docVerifyLbl);
			customerDetailsPage.clickOnVerifiedDocChk();
			Thread.sleep(3000);
			customerDetailsPage.clickOnDocByPassReasonLbl().selectDocByPassReasonOption();
			
			customerDetailsPage.clickOnEmiratesLbl().selectEmiratesOption().enterPOBoxNo("1150").
			enterEnglishAddess1(engAddr1).enterArabicAddess1(".").enterCustMobileNo(custMobNumber).enterCustEmailId(custEmail);
				
			
			customerDetailsPage.clickOnSubmitDeleteBtn();
			
			String subReqId = accountDetailsPage.getSubReqId();
			System.out.println("the engima package sub request Id::"+subReqId);
				
			//clicking on the ok btn pop up	
			getBasePage().clickByWebElement(accountDetailsPage.popUpOkDeleteServicesBtn);
	}
}
