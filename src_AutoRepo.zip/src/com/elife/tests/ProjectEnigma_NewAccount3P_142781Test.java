package com.elife.tests;
import java.util.ArrayList;
import org.openqa.selenium.Alert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.automation.configs.DBQuerryConstants;
import com.base.utils.BaseTest;
import com.cbcm.DataProvider.ELifeDataProviderRC;
import com.cbcm.DataProvider.ELifeDataProviderUAT;
import com.pages.elife.AccountDetailsPage;
import com.pages.elife.CustomerDetailsPage;
import com.pages.elife.ELifeApplicationDetailsPage;
import com.pages.elife.ELifeNewtWorkDetailsPage;

public class ProjectEnigma_NewAccount3P_142781Test extends BaseTest{
	
	ELifeApplicationDetailsPage eLifePage;
	ELifeNewtWorkDetailsPage eflifeNetWorkDetailsPage;
	CustomerDetailsPage customerDetailsPage;
	AccountDetailsPage accountDetailsPage;
	
	@BeforeTest
	public void setUp() {
		launchElifeApplication();
		
	}
	
	@Test(dataProviderClass = ELifeDataProviderRC.class, dataProvider = "projectEnigma_NewAccount3P_142781Test", testName = "projectEnigma_NewAccount3P_142781Test",enabled=true)
	public void projectEnigma_NewAccount3P_142781Test(String userName,String passWord,String eidNumber,String custFName,String custLName,String docNumber,String issueAutority,
			String engAddr1,String custMobNo,String custEmailId,String accountFLName,String internetUsrName,String custEnvConNo,String custEnvConEmailId,String	webTVUsrNme,
			String contactPName,String	contactPMobNo,String fromDB) throws InterruptedException {
			
			//login(userName,passWord);
			eLifePage = new ELifeApplicationDetailsPage(getDriver());
			eflifeNetWorkDetailsPage = new ELifeNewtWorkDetailsPage(getDriver());
			customerDetailsPage = new CustomerDetailsPage(getDriver());
			accountDetailsPage = new AccountDetailsPage(getDriver());
			/*windowHandle();
			
			ArrayList<Integer> windowSize=getWindowSize();
			
			getHomePage().navigateToFavoriteTab().navigateToeLifeTransformationSubTab();
			
			String parentWindow = switchToWindow();
			
			windowMaximize(windowSize.get(0),windowSize.get(1));*/
			
			eLifePage.clickOnServiceTypeDropDownBtn().selectSeriveTypeFilterAndclick("New Account").clickOnServiceRequiredLabel().selectServiceRequiredType("elife Triple Play").
			clickOnExistingCustRadioBtn("No");
			
			eflifeNetWorkDetailsPage.clickOnEIDRadioBtn().enterEIDNumber(eidNumber).clickOnCheckAvaliablityLnk().clickTVProgramLbl().
			selectTVProramOptionAndClick("Generic").clickOnNoOfRoomsInHouseLbl().selectTVRoomOptionAndClick("1 Room").clickOnCountryLbl().
			selectCountyOptionAndClick("Albania").clickOnRecorderRadioBtn().
			clickOnProposePackageBtn().clickOnVasServiceIdChk().clickOnProceedBtnk();
			
			/*String parentWindow1 = switchToWindow();
			getDriver().close();
			
			getDriver().switchTo().window(parentWindow1);*/
			
			eflifeNetWorkDetailsPage.clickNoBtnFrmPopUp();
			 Thread.sleep(1500);
			eflifeNetWorkDetailsPage.clickNoBtnFrmPopUp2();
			Thread.sleep(1500);
			eflifeNetWorkDetailsPage.clickEngimaYesBtnFrmPopUp3();
			Thread.sleep(6000);
			
			customerDetailsPage.clickOnCustTitleLbl().selectCustTitleOption().enterCustFname(custFName).enterCustLname(custLName).enterCustArabicFname(".").
			enterCustArabicLname(".").selectDOB("15","03","1995").clickOnCustNationalityLbl().selectCustNationalityOption("Albania").clickOnCustSubTypeLbl().
			selectCustSubTypeOption("Residential").clickOnIdentityTypeLbl().selectIdentityTypeOption();
			
			Thread.sleep(1000);
			Alert alert = getDriver().switchTo().alert();
			String alertText = alert.getText();
			System.out.println("Alert data: " + alertText);
			alert.dismiss();
			Thread.sleep(1000);
			
			//String custEmail=custEmailId+DBQuerryConstants.get3DigitRandomNumbers()+"@etisalat.ae";
			String custEmail="jekumar@etisalat.ae";
			
			String documentNum11 = docNumber.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			//String documentNum11 = "7841995"+DBQuerryConstants.get8DigitRandomNumbers();
			System.out.println("the document no::"+documentNum11);
			
			String custMobNumber = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			
			String visaNo="71"+DBQuerryConstants.get5DigitRandomNumbers();
			System.out.println("vis no::"+visaNo);
			
			String visaIssueAuthority="visaisue";
			String unifiedNo="51"+DBQuerryConstants.get5DigitRandomNumbers();
			
			customerDetailsPage.clickOnVerifiedDocChk();		
			Thread.sleep(1000);
			
			customerDetailsPage/*.selectIssueDate("16","Apr","2010")*/.enterVisaNo(visaNo).enterDocumentNo(documentNum11).selectExpiryDate("22", "Apr", "2021")
			.enterVisaIssueAuthority(visaIssueAuthority).selectVisaIssueDate("10","Apr","2017")
			.selectVisaExpiryDate("11", "Apr","2019").enterIssuingAuthority("asas").enterUniFiedNo(unifiedNo).
			clickOnDocByPassReasonLbl().selectDocByPassReasonOption().clickOnEmiratesLbl().selectEmiratesOption().enterEnglishAddess1(engAddr1)
			.enterArabicAddess1(".").enterCustMobileNo(custMobNumber).enterCustEmailId("jekumar@etisalat.ae");
			
			String intUsrNme=internetUsrName+DBQuerryConstants.get3DigitRandomNumbers();
			
			String custEnvContactNo = custEnvConNo+DBQuerryConstants.get5DigitRandomNumbers();
			
			//String custEnvEmailId=custEnvConEmailId+DBQuerryConstants.get3DigitRandomNumbers()+"@etisalat.ae";
			String custEnvEmailId="jekumar@etisalat.ae";
			String webTvUN = webTVUsrNme+DBQuerryConstants.get3DigitRandomNumbers();
			
			String conPrimaryMobileNo = contactPMobNo+DBQuerryConstants.get5DigitRandomNumbers();
			
			accountDetailsPage.enterAccountFNEnglish(accountFLName).enterAccountFNArabic(".").enterInternetUserName(intUsrNme)
			.enterCustEnvContactNo(custEnvContactNo).enterCustEnvContactEmailId(custEnvEmailId)
			.editWebTvUsrName(webTvUN)/*.editWebTvEmailId(custEmail).editWebTvMobileNo(custMobNumber)*/
			.unCheckElifeInstantAccountChk()
			.clickOnFlatDetailsLbl().selectFlatDetailsOption("1216").enterContactPersonName(contactPName).enterContactPrimaryMobileNo(conPrimaryMobileNo).
			clickInstallationCityLbl().selectInstallationCityOption("AL SABKHA").clickOnConfirmOrder().clickAgreeBtnFrmPopUp();
			
			String subReqId = accountDetailsPage.getSubReqId();
			System.out.println("the engima package sub request Id::"+subReqId);
				
			accountDetailsPage.clickOnOkBtnFrmPopUp();
				
	}

}
