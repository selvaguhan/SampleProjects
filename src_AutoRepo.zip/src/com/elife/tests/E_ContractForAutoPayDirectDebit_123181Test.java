package com.elife.tests;

import java.util.ArrayList;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.base.utils.BaseTest;
import com.cbcm.DataProvider.ELifeDataProvider;
import com.pages.elife.ELifeApplicationDetailsPage;
import com.pages.elife.ELifeNewtWorkDetailsPage;

public class E_ContractForAutoPayDirectDebit_123181Test extends BaseTest{
	
	ELifeApplicationDetailsPage eLifePage;
	ELifeNewtWorkDetailsPage eflifeNetWorkDetailsPage;
	
	@BeforeTest
	public void setUp() {
		launchBrowser();
		
	}
	
	@Test(dataProviderClass = ELifeDataProvider.class, dataProvider = "eContractAutoPayDirectDebit", testName = "eContractAutoPayDirectDebit",enabled=true)
	public void e_ContractForAutoPayDirectDebit_123181Test(String userName,String passWord,String eidNumber,String custFName,String custLName,String docNumber,String issueAutority,
			String engAddr1,String custMobNo,String custEmailId,String accountFLName,String internetUsrName,String custEnvConNo,String custEnvConEmailId,String	webTVUsrNme,
			String contactPName,String	contactPMobNo,String fromDB) throws InterruptedException {
			
			login(userName,passWord);
			windowHandle();
			eLifePage = new ELifeApplicationDetailsPage(getDriver());
			ArrayList<Integer> windowSize=getWindowSize();
			
			getHomePage().navigateToFavoriteTab().navigateToeLifeTransformationSubTab();
			
			String parentWindow = switchToWindow();
			windowMaximize(windowSize.get(0),windowSize.get(1));
			
			eflifeNetWorkDetailsPage = new ELifeNewtWorkDetailsPage(getDriver());
			
			eLifePage.clickOnServiceTypeDropDownBtn().selectSeriveTypeFilterAndclick("New Account").clickOnServiceRequiredLabel().selectServiceRequiredType("elife Triple Play").clickOnExistingCustRadioBtn("Yes");
			
			/*eflifeNetWorkDetailsPage.enterEIDNumber(eidNumber).enterPartyID("21373820").clickOnCheckAvaliablityLnk().clickTVProgramLbl().
			selectTVProramOptionAndClick().clickOnNoOfRoomsInHouseLbl().select3RoomOptionAndClick().clickOnCountryLbl().selectCountyOptionAndClick().clickOnRecorderRadioBtn()
			.clickOnRoom1TelephoneChk().clickOnRoom2TelephoneChk().clickOnProposePackageBtn().clickOnVasServiceIdChk().clickOnProceedBtnk();*/
			
	}

}
