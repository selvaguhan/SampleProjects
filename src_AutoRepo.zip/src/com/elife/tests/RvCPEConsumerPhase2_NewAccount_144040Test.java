package com.elife.tests;

import java.util.ArrayList;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.automation.configs.DBQuerryConstants;
import com.base.utils.BaseTest;
import com.cbcm.DataProvider.ELifeDataProvider;
import com.cbcm.DataProvider.ELifeDataProviderRC;
import com.cbcm.DataProvider.ELifeDataProviderUAT;
import com.pages.elife.AccountDetailsPage;
import com.pages.elife.CustomerDetailsPage;
import com.pages.elife.ELifeApplicationDetailsPage;
import com.pages.elife.ELifeNewtWorkDetailsPage;

public class RvCPEConsumerPhase2_NewAccount_144040Test  extends BaseTest {

	ELifeApplicationDetailsPage eLifePage;
	ELifeNewtWorkDetailsPage eflifeNetWorkDetailsPage;
	CustomerDetailsPage customerDetailsPage;
	AccountDetailsPage accountDetailsPage;
	
	@BeforeTest
	public void setUp() {
		launchElifeApplication();
		
	}
	
	@Test(dataProviderClass = ELifeDataProviderRC.class, dataProvider = "rvCPEConsumerPhase2_NewAccount_144040Test", testName = "rvCPEConsumerPhase2_NewAccount_144040Test",enabled=true)
	public void rvCPEConsumerPhase2_NewAccount_144040Test(String userName,String passWord,String eidNumber,String custFName,String custLName,String docNumber,String issueAutority,
			String engAddr1,String custMobNo,String custEmailId,String accountFLName,String internetUsrName,String custEnvConNo,String custEnvConEmailId,String	webTVUsrNme,
			String contactPName,String	contactPMobNo,String fromDB,String partyID) throws InterruptedException {
			
			//login(userName,passWord);
			eLifePage = new ELifeApplicationDetailsPage(getDriver());
			eflifeNetWorkDetailsPage = new ELifeNewtWorkDetailsPage(getDriver());
			customerDetailsPage = new CustomerDetailsPage(getDriver());
			accountDetailsPage = new AccountDetailsPage(getDriver());
			/*windowHandle();
			
			ArrayList<Integer> windowSize=getWindowSize();
			
			getHomePage().navigateToFavoriteTab().navigateToeLifeTransformationSubTab();
			
			String parentWindow = switchToWindow();
			
			windowMaximize(windowSize.get(0),windowSize.get(1));*/
			
			eLifePage.clickOnServiceTypeDropDownBtn().selectSeriveTypeFilterAndclick("New Account").clickOnServiceRequiredLabel().selectServiceRequiredType("eLife Internet").
			clickOnExistingCustRadioBtn("Yes");
			
			//eflifeNetWorkDetailsPage.enterPartyID(partyID);
			
			eflifeNetWorkDetailsPage.enterPartyID(partyID).clickPartyIDDetailsContinueFrmPopUp();
			
			eflifeNetWorkDetailsPage.clickPartyIDDetailsRadioBtnFrmPopUp().clickSubmitBtnFrmPartyIDDetailsFrmPopUp();
			
			
			/*if(getBasePage().getText(eflifeNetWorkDetailsPage.partyIDDetailsContinueFrmPopUp).contains("Continue")) {
				
				System.out.println("i am in continue ***************"+getBasePage().getText(eflifeNetWorkDetailsPage.partyIDDetailsContinueFrmPopUp));
				eflifeNetWorkDetailsPage.clickPartyIDDetailsContinueFrmPopUp();
				
			}/*else if(getBasePage().getText(eflifeNetWorkDetailsPage.partyIDDetailsRadioBtnFrmPopUp).contains("ok")) {
				System.out.println("i am in ok***************");
				eflifeNetWorkDetailsPage.clickPartyIDDetailsRadioBtnFrmPopUp().clickSubmitBtnFrmPartyIDDetailsFrmPopUp();
				
			}*/
		
			eflifeNetWorkDetailsPage.clickOnEIDRadioBtn().enterEIDNumber(eidNumber).clickOnCheckAvaliablityLnk();
			
			eflifeNetWorkDetailsPage.clickOnNoOfInternetUsersLbl().selectInternetUserAndClick("Less than 2").
			clickOnNoOfRoomsInUse().selectRoomsInUseAndClick("1 Room").clickOnProposePackageBtn();
			
			//clickOnProposePackageBtn().clickOnVasServiceIdChk().clickOnProceedBtnk();
			getBasePage().scrollIntoViewTillElement(eflifeNetWorkDetailsPage.searchWithCodeTxt);
			getBasePage().safeType(eflifeNetWorkDetailsPage.searchWithCodeTxt, "RPTPVCPE");
			getBasePage().clickOnTabKey(eflifeNetWorkDetailsPage.searchWithCodeTxt);
			Thread.sleep(3000);
			
			getBasePage().scrollIntoViewTillElement(eflifeNetWorkDetailsPage.getServicePlan("RPTPVCPE"));
			eflifeNetWorkDetailsPage.selectServicePlan("RPTPVCPE");
			Thread.sleep(3000);
			getBasePage().clickElementUsingJavaScript(eflifeNetWorkDetailsPage.addBtn);
			
			
			getBasePage().scrollIntoViewTillElement(eflifeNetWorkDetailsPage.searchWithCodeTxt);
			getBasePage().safeType(eflifeNetWorkDetailsPage.searchWithCodeTxt, "RPANTIVIRS");
			getBasePage().clickOnTabKey(eflifeNetWorkDetailsPage.searchWithCodeTxt);
			Thread.sleep(3000);
			
			getBasePage().scrollIntoViewTillElement(eflifeNetWorkDetailsPage.getServicePlan("RPANTIVIRS"));
			eflifeNetWorkDetailsPage.selectServicePlan("RPANTIVIRS");
			Thread.sleep(3000);
			getBasePage().clickElementUsingJavaScript(eflifeNetWorkDetailsPage.addBtn);
			Thread.sleep(3000);
			eflifeNetWorkDetailsPage.clickOnVasServiceIdChk().clickOnProceedBtnk();
			Thread.sleep(1500);
			
			eflifeNetWorkDetailsPage.clickNoBtnFrmPopUp();
			Thread.sleep(1500);

			customerDetailsPage.selectVisaExpiryDate("11", "Apr","2021").enterVisaIssueAuthority("visa aa").clickOnVerifiedDocChk().
			clickOnDocByPassReasonLbl().selectDocByPassReasonOption();
			
			String custMobNumber = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			
			customerDetailsPage.enterPOBoxNo("1150").enterArabicAddess1(".").enterCustMobileNo(custMobNumber).enterCustEmailId("jekumar@etisalat.ae");
			
			String intUsrNme=internetUsrName+DBQuerryConstants.get3DigitRandomNumbers();
			
			String conPrimaryMobileNo = contactPMobNo+DBQuerryConstants.get5DigitRandomNumbers();
			
			accountDetailsPage.enterInternetUserName(intUsrNme).unCheckElifeInstantAccountChk().
			clickOnFlatDetailsLbl().selectFlatDetailsOption("101").enterContactPrimaryMobileNo(conPrimaryMobileNo).
			clickInstallationCityLbl().selectInstallationCityOption("SADIYAT")
			.clickOnConfirmOrder().clickAgreeBtnFrmPopUp();
			
			String subReqId = accountDetailsPage.getSubReqId();
			System.out.println("the RVCPE package sub request Id::"+subReqId);
				
			accountDetailsPage.clickOnOkBtnFrmPopUp();
			
	}
}
