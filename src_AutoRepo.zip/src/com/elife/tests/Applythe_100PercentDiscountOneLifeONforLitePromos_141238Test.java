package com.elife.tests;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.automation.configs.DBQuerryConstants;
import com.automation.configs.WaitConfigs;
import com.base.utils.BaseTest;
import com.cbcm.DataProvider.ELifeDataProvider;
import com.cbcm.DataProvider.ELifeDataProviderRC;
import com.cbcm.DataProvider.ELifeDataProviderUAT;
import com.pages.elife.AccountDetailsPage;
import com.pages.elife.CustomerDetailsPage;
import com.pages.elife.ELifeApplicationDetailsPage;
import com.pages.elife.ELifeNewtWorkDetailsPage;

public class Applythe_100PercentDiscountOneLifeONforLitePromos_141238Test extends BaseTest {

	ELifeApplicationDetailsPage eLifePage;
	ELifeNewtWorkDetailsPage eflifeNetWorkDetailsPage;
	CustomerDetailsPage customerDetailsPage;
	AccountDetailsPage accountDetailsPage;
	
	@BeforeTest
	public void setUp() {
		launchBrowser();
		
	}
	
	@Test(dataProviderClass = ELifeDataProvider.class, dataProvider = "applythe_100PercentDiscountOneLifeONforLitePromos_141238Test", testName = "applythe_100PercentDiscountOneLifeONforLitePromos_141238Test",enabled=true)
	public void applythe_100PercentDiscountOneLifeONforLitePromos_141238Test(String userName,String passWord,String eidNumber,String custFName,String custLName,String docNumber,String issueAutority,
			String engAddr1,String custMobNo,String custEmailId,String accountFLName,String internetUsrName,String custEnvConNo,String custEnvConEmailId,String	webTVUsrNme,
			String contactPName,String	contactPMobNo,String fromDB,String accountNo) throws InterruptedException {
			
			login(userName,passWord);
			eLifePage = new ELifeApplicationDetailsPage(getDriver());
			eflifeNetWorkDetailsPage = new ELifeNewtWorkDetailsPage(getDriver());
			customerDetailsPage = new CustomerDetailsPage(getDriver());
			accountDetailsPage = new AccountDetailsPage(getDriver());
			windowHandle();
			
			ArrayList<Integer> windowSize=getWindowSize();
			
			getHomePage().navigateToFavoriteTab().navigateToeLifeTransformationSubTab();
			
			String parentWindow = switchToWindow();
			
			windowMaximize(windowSize.get(0),windowSize.get(1));
			
			String custMobNumber1 = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			
			String alternateContactNo = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			
			eLifePage.clickOnServiceTypeDropDownBtn().selectSeriveTypeFilterAndclick("Subscriber Request Cessation").enterAccountNo(accountNo);
			
			//Pls Wait Loading....
			getWaitUtil().elementPresence(eLifePage.productGrpDescription, WaitConfigs.pageLoadWait);
			
			eLifePage.clickOnCessReasonDropDownBtn().
			selectCessReasonAndClick("Business Closed");
			
			getWaitUtil().isElementInVisible(eLifePage.closeCessationLoading,70);
	
			
			eLifePage.clickOnMainRetentionOffersRadioBtn();
			eLifePage.clickOnOffersDescriptionRadioBtn().enterAlternateContactNumber(alternateContactNo).enterNote("TEST").
			clickOnRejectRetentionOffersRadioBtn();
			
			getWaitUtil().elementPresence(eLifePage.noRadioBtn, WaitConfigs.elementVisibleWait);
			getBasePage().scrollIntoViewTillElement(eLifePage.noRadioBtn);
			getBasePage().clickOnElementByJavaScriptExecutor(eLifePage.noRadioBtn);
			
			Thread.sleep(1000);
	
			/*try {
				Robot	r = new Robot();
				   // Press Enter
				   r.keyPress(KeyEvent.VK_ENTER);
				   // Release Enter
				   r.keyRelease(KeyEvent.VK_ENTER);
			} catch (AWTException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				
			}*/
			 
			  
			
			/*try {
			    WebDriverWait wait = new WebDriverWait(getDriver(), 5);
			    wait.until(ExpectedConditions.alertIsPresent());
			    Alert alert = getDriver().switchTo().alert();
			    System.out.println(alert.getText());
			    alert.accept();
			    
			    //alert.sendKeys(KeyEvent);;
			} catch (Exception e) {
			    //exception handling
				System.out.println("unable to handle exception in the alert block::"+e);
			}*/
			
			
			String custEmail="jekumar@etisalat.ae";
			String custMobNumber = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			
			customerDetailsPage./*clickOnEmiratesLbl().selectEmiratesOption().clickOnCityLbl().selectCity("AL SABKHA").enterEnglishAddess1(engAddr1)
			enterArabicAddess1(".").*/enterCustMobileNo(custMobNumber).enterCustEmailId(custEmail)/*.enterContactPerson("aasa")*/.clickOnConfirmCessationBtn();
			
			
	}
}
