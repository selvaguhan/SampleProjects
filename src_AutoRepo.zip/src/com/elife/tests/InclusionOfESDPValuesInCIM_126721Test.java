package com.elife.tests;

import java.util.ArrayList;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.automation.configs.DBQuerryConstants;
import com.base.utils.BaseTest;
import com.cbcm.DataProvider.ELifeDataProviderRC;
import com.pages.elife.AccountDetailsPage;
import com.pages.elife.CustomerDetailsPage;
import com.pages.elife.ELifeApplicationDetailsPage;
import com.pages.elife.ELifeNewtWorkDetailsPage;

public class InclusionOfESDPValuesInCIM_126721Test extends BaseTest{
	
	ELifeApplicationDetailsPage eLifePage;
	ELifeNewtWorkDetailsPage eflifeNetWorkDetailsPage;
	CustomerDetailsPage customerDetailsPage;
	AccountDetailsPage accountDetailsPage;
	
	@BeforeTest
	public void setUp() {
		launchBrowser();
		
	}
	
	@Test(dataProviderClass = ELifeDataProviderRC.class, dataProvider = "inclusionOfESDPValuesInCIM_126721Test", testName = "inclusionOfESDPValuesInCIM_126721Test",enabled=true)
	public void inclusionOfESDPValuesInCIM_126721Test(String userName,String passWord,String eidNumber,String custFName,String custLName,String docNumber,String issueAutority,
			String engAddr1,String custMobNo,String custEmailId,String accountFLName,String internetUsrName,String custEnvConNo,String custEnvConEmailId,String	webTVUsrNme,
			String contactPName,String	contactPMobNo,String fromDB,String accountNumber) throws InterruptedException {
			//login into to the application
			login(userName,passWord);
			eLifePage = new ELifeApplicationDetailsPage(getDriver());
			eflifeNetWorkDetailsPage = new ELifeNewtWorkDetailsPage(getDriver());
			customerDetailsPage = new CustomerDetailsPage(getDriver());
			accountDetailsPage = new AccountDetailsPage(getDriver());
			windowHandle();
			
			ArrayList<Integer> windowSize=getWindowSize();
			
			getHomePage().navigateToFavoriteTab().navigateToeLifeTransformationSubTab();
			
			String parentWindow = switchToWindow();
			
			windowMaximize(windowSize.get(0),windowSize.get(1));
			// generating the dynamic phone number and alternate no, which is required each and every time unique
			String contactNo = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			String alternateContactNo = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			
			//selecting the service type and then entering the account number and other mandatory details
			eLifePage.clickOnServiceTypeDropDownBtn().selectSeriveTypeFilterAndclick("Subscriber Request Cessation").enterAccountNo(accountNumber).enterContactNumber(contactNo);
			
			String custEmail1="jekumar@etisalat.ae";
			
			customerDetailsPage.enterCustDetailsEmailId(custEmail1);
			//select the cess reason from the drop down
			eLifePage.clickOnCessReasonDropDownBtn().selectCessReasonAndClick("Business Closed").
			clickOnMainRetentionOffersRadioBtn().clickOnOffersDescriptionRadioBtn().enterAlternateContactNumber(alternateContactNo).clickOnRejectRetentionOffersRadioBtn();
						
			String custEmail="jekumar@etisalat.ae";
			String custMobNumber = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			
			// entering the other mandatory details and then click on the sub mit button
			customerDetailsPage.enterArabicAddess1(".").enterCustMobileNo(custMobNumber).enterCustEmailId(custEmail).clickOnSubmitBtn();
			
			// getting the sub request id from the opo up
			String subReqId = accountDetailsPage.getSubReqId();
			System.out.println("the inclusion sub request Id::"+subReqId);
			
			//clicking on the ok btn pop up	
			getBasePage().clickByWebElement(accountDetailsPage.popUpOkDeleteServicesBtn);
		
	  }
}
