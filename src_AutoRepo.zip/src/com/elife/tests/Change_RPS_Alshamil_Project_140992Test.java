package com.elife.tests;

import java.util.ArrayList;

import org.openqa.selenium.Alert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.automation.configs.DBQuerryConstants;
import com.automation.configs.WaitConfigs;
import com.base.utils.BaseTest;
import com.cbcm.DataProvider.ELifeDataProvider;
import com.cbcm.DataProvider.ELifeDataProviderRC;
import com.pages.elife.AccountDetailsPage;
import com.pages.elife.CustomerDetailsPage;
import com.pages.elife.ELifeApplicationDetailsPage;
import com.pages.elife.ELifeNewtWorkDetailsPage;

public class Change_RPS_Alshamil_Project_140992Test extends BaseTest{
	
	ELifeApplicationDetailsPage eLifePage;
	ELifeNewtWorkDetailsPage eflifeNetWorkDetailsPage;
	CustomerDetailsPage customerDetailsPage;
	AccountDetailsPage accountDetailsPage;
	
	@BeforeTest
	public void setUp() {
		launchBrowser();
		
	}
	
	@Test(dataProviderClass = ELifeDataProvider.class, dataProvider = "change_RPS_Alshamil_Project_140992Test", testName = "change_RPS_Alshamil_Project_140992Test",enabled=true)
	public void change_RPS_Alshamil_Project_140992Test(String userName,String passWord,String eidNumber,String custFName,String custLName,String docNumber,String issueAutority,
			String engAddr1,String custMobNo,String custEmailId,String accountFLName,String internetUsrName,String custEnvConNo,String custEnvConEmailId,String	webTVUsrNme,
			String contactPName,String	contactPMobNo,String serviceType,String accountNo) throws InterruptedException {
			
			login(userName,passWord);
			eLifePage = new ELifeApplicationDetailsPage(getDriver());
			eflifeNetWorkDetailsPage = new ELifeNewtWorkDetailsPage(getDriver());
			customerDetailsPage = new CustomerDetailsPage(getDriver());
			accountDetailsPage = new AccountDetailsPage(getDriver());
			windowHandle();
			
			ArrayList<Integer> windowSize=getWindowSize();
			
			getHomePage().navigateToFavoriteTab().navigateToeLifeTransformationSubTab();
			
			String parentWindow = switchToWindow();
			
			windowMaximize(windowSize.get(0),windowSize.get(1));
			
			eLifePage.clickOnServiceTypeDropDownBtn().selectSeriveTypeFilterAndclick(serviceType).clickOnServiceRequiredLabel().
			selectServiceRequiredType("eLife Dual Play").enterAccountNo(accountNo);
			
			if(getBasePage().isElementDisplayed(eLifePage.alshamilRPContinuePopUpBtn)) {
				getWaitUtil().elementPresence(eLifePage.alshamilRPContinuePopUpBtn,WaitConfigs.pageLoadWait);
				getBasePage().clickByWebElement(eLifePage.alshamilRPContinuePopUpBtn);
			}
			
			String eidNum = getBasePage().getText(eflifeNetWorkDetailsPage.eidTxt);
			
			if (eidNum != null && !eidNum.equals("")) {
			    System.out.println("eid number is present in the text box.");
			}else {
				eflifeNetWorkDetailsPage.clickOnEIDRadioBtn().enterEIDNumber(eidNumber).clickOnCheckAvaliablityLnk();
			}
			
			
			
			getWaitUtil().elementPresence(eLifePage.noOfInternetUsersLbl,WaitConfigs.pageLoadWait);
			getBasePage().scrollIntoViewTillElement(eLifePage.noOfInternetUsersLbl);
			getBasePage().clickByWebElement(eLifePage.noOfInternetUsersLbl);
			
			getWaitUtil().elementPresence(eLifePage.getNoOfInternetUsers("Less than 2"),WaitConfigs.elementVisibleWait);
			getBasePage().clickByWebElement(eLifePage.getNoOfInternetUsers("Less than 2"));
			
			getWaitUtil().elementPresence(eLifePage.noOfRoomsInHouseLbl,WaitConfigs.elementVisibleWait);
			getBasePage().scrollIntoViewTillElement(eLifePage.noOfRoomsInHouseLbl);
			getBasePage().clickByWebElement(eLifePage.noOfRoomsInHouseLbl);
			getBasePage().clickByWebElement(eLifePage.getNoOfRoomsInHouse("1 Room"));
			
			getWaitUtil().elementPresence(eLifePage.selectedCountryLbl,WaitConfigs.elementVisibleWait);
			getBasePage().scrollIntoViewTillElement(eLifePage.selectedCountryLbl);
			getBasePage().clickByWebElement(eLifePage.selectedCountryLbl);
			getBasePage().clickByWebElement(eLifePage.getSelectedCounty("Albania"));
			
			
			getWaitUtil().elementPresence(eLifePage.proposePackageBtn,WaitConfigs.elementVisibleWait);
			getBasePage().scrollIntoViewTillElement(eLifePage.proposePackageBtn);
			getBasePage().clickByWebElement(eLifePage.proposePackageBtn);
			
			
			getWaitUtil().elementPresence(eflifeNetWorkDetailsPage.packageValueAddedServiceChk,WaitConfigs.pageLoadWait);
			getBasePage().scrollIntoViewTillElement(eflifeNetWorkDetailsPage.packageValueAddedServiceChk);
			getBasePage().clickByWebElement(eflifeNetWorkDetailsPage.packageValueAddedServiceChk);
			
			getWaitUtil().elementPresence(eflifeNetWorkDetailsPage.packageCodeDescLbl,WaitConfigs.pageLoadWait);
			getBasePage().scrollIntoViewTillElement(eflifeNetWorkDetailsPage.packageCodeDescLbl);
			getBasePage().clickByWebElement(eflifeNetWorkDetailsPage.packageCodeDescLbl);
			getBasePage().clickByWebElement(eflifeNetWorkDetailsPage.getSelectedPackageCodeDesc("eLife Double Play - Lite - 512kbps speed"));
			eflifeNetWorkDetailsPage.clickOnVasServiceIdChk().clickOnProceedBtnk();
			
			eflifeNetWorkDetailsPage.clickNoBtnFrmAlShamilPopUp();
			Thread.sleep(2000);
			
			String custMobNumber = custMobNo.toString().trim()+DBQuerryConstants.get5DigitRandomNumbers();
			String custEmail=custEmailId+DBQuerryConstants.get3DigitRandomNumbers()+"@etisalat.ae";
			String conPrimaryMobileNo = contactPMobNo+DBQuerryConstants.get5DigitRandomNumbers();
			
			customerDetailsPage.enterArabicAddess1(".").enterCustMobileNo(custMobNumber).enterCustEmailId(custEmail);
			accountDetailsPage.enterContactPersonName(contactPName).
			enterCompanyNameEng1("asas").enterCompanyNameArabic1("...")
			.clickOnFlatDetailsLbl().selectFlatDetailsOption("GSM4693").
			enterContactPrimaryMobileNo(conPrimaryMobileNo).
			clickInstallationCityLbl().selectInstallationCityOption("SADIYAT").
			clickOnConfirmOrder1();
			
			Thread.sleep(1000);
			Alert alert = getDriver().switchTo().alert();
			String alertText = alert.getText();
			System.out.println("Alert data: " + alertText);
			alert.accept();
			Thread.sleep(1000);
			
			String subReqId = accountDetailsPage.getSubReqId();
			System.out.println("the engima package sub request Id::"+subReqId);
				
			accountDetailsPage.clickOnOkBtnFrmPopUp();
			
			
	}

}
