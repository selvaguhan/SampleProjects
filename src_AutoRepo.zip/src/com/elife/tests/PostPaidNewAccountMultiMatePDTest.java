package com.elife.tests;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.automation.configs.AutomationConstants;
import com.automation.configs.FramesConfigs;
import com.automation.configs.WaitConfigs;
import com.base.utils.CBCMDbHelperClass;
import com.cbcm.DataProvider.CBCMDataProvider;
import com.cbcm.favoriteTab.pages.CaptureCustomerRequestPage;
import com.cbcm.pages.CaptureMultimateDeviceDetailsPage;
import com.cbcm.pages.MaintainRequestPage;
import com.cbcm.pages.SuccessfulOperationPage;
import com.cbcm.singleSelectWindow.pages.DocumentFrmProfileWindowPage;
import com.cbcm.singleSelectWindow.pages.MaintainPartySearchWindowPage;
import com.cbcm.superclass.CloneSuperClass;

public class PostPaidNewAccountMultiMatePDTest extends CloneSuperClass{
	
	CaptureCustomerRequestPage ccrPage;
	MaintainRequestPage mrPage;
	DocumentFrmProfileWindowPage docFrmProfileWindowPage;
	SuccessfulOperationPage successFullOperPage;
	
	@BeforeTest
	public void setUp() {
		launchBrowser();
		
	}
	
	@Test(dataProviderClass = CBCMDataProvider.class, dataProvider = "MultiMate002", testName = "MultiMate002",enabled=true)
	public void postPaidNewAccountMultiMateTest(String userName,String	passWord,String	subRequestType,String	package1,String	package2,String	ratePlan,
			String	salesChannel,String	emailId,String	directoryCode,String capProfile,String	noOfSims,String	simno1,String	simno2,
			String	areaCode,String	prdoctNo,String partyId,String fromDB) throws InterruptedException {

		login(userName,passWord);
		windowHandle();
		
		String partyId1 = partyId.trim();
		MaintainPartySearchWindowPage mpsw = new MaintainPartySearchWindowPage(getDriver());
		ccrPage = new CaptureCustomerRequestPage(getDriver());
		mrPage = new MaintainRequestPage(getDriver());
		docFrmProfileWindowPage = new DocumentFrmProfileWindowPage(getDriver());
		successFullOperPage = new SuccessfulOperationPage(getDriver());
		CaptureMultimateDeviceDetailsPage cmdd = new CaptureMultimateDeviceDetailsPage(getDriver());
		CBCMDbHelperClass cbcmDbHelperClass = new CBCMDbHelperClass();
		
		selectNewMultiMateReqType(subRequestType.toString().trim(),partyId1);
		String parentWindow12 = switchToWindow();
		mpsw.waitForPartrySearchWindow().clickOnPartyIdRadioBtn().clickOnSelectBtn();
		Thread.sleep(2000);
		
		getDriver().switchTo().window(parentWindow12);
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame);
		getWaitUtil().elementPresence(ccrPage.partySubTypeLbl,WaitConfigs.elementVisibleWait);
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.secondFrame);
		
		ccrPage.selectRatePlanType(AutomationConstants.packageType).clickOnAddRatePlanRow().enterPackageCode1(package1).
		selectRatePlanType(AutomationConstants.packageType).clickOnAddRatePlanRow().enterPackageCode2(package2).
		selectRatePlanType(AutomationConstants.ratePlanType).clickOnAddRatePlanRow().enterRatePlan(ratePlan);
		Thread.sleep(2000);
		
		ccrPage.selectSalesChannel(salesChannel);
		ccrPage.clickOnDoneBtnForMultiMate();
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame);
		ccrPage.clickContinueBtn();
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
		
		getWaitUtil().elementPresence(mrPage.requestActivityLbl, WaitConfigs.pageLoadWait);
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame("basefrm");
		
		mrPage.clickOnSubReqIdLbl();
		
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
		getWaitUtil().elementPresence(mrPage.accountInformationLbl, WaitConfigs.pageLoadWait);
		mrPage.clickOnSaveButton3();
		
		getWaitUtil().elementPresence(mrPage.invoiceDetailsLbl, WaitConfigs.pageLoadWait);
		mrPage.enterEmailId(emailId).clickOnAddBtn1().clickOnSave();
		getWaitUtil().elementPresence(mrPage.dqDetailsLbl, WaitConfigs.pageLoadWait);
		
		mrPage.selectDirectoryCode(directoryCode).clickOnSaveButton2();
		getWaitUtil().elementPresence(mrPage.captureNumInformationLbl, WaitConfigs.pageLoadWait);
		
		ArrayList<String> areaCodeAndPrdNum;
		if(fromDB.equalsIgnoreCase(AutomationConstants.testInputFromDB)) {
			 areaCodeAndPrdNum =cbcmDbHelperClass.getFreeAreaCodeAndProductNumFromCBCMDB();
			 areaCode=areaCodeAndPrdNum.get(0);
			 prdoctNo=areaCodeAndPrdNum.get(1);
		}else {
			 areaCodeAndPrdNum =cbcmDbHelperClass.checkWithMsisdnNoIfExistsUpdateAndInsertIntoCSSDB(areaCode,prdoctNo);
			 areaCode=areaCodeAndPrdNum.get(0);
			 prdoctNo=areaCodeAndPrdNum.get(1);
			 
		}
		mrPage.enterAreaCode(areaCode).enterNumber(prdoctNo).clickOnSave();
		getWaitUtil().elementPresence(mrPage.captureOtherResourceInformartionLbl, WaitConfigs.pageLoadWait);
		
		ArrayList<String> serialNoList;
		if(fromDB.equals(AutomationConstants.testInputFromDB)) {
			 serialNoList= cbcmDbHelperClass.getFreeSerialNumberFromCBCMDB(2);
			 simno1=serialNoList.get(0).toString().trim();
			 simno2=serialNoList.get(1).toString().trim();
			 
		 }else {
			 ArrayList<String> serialNoListFromExcel=new ArrayList<String>();
			 serialNoListFromExcel.add(simno1);
			 serialNoListFromExcel.add(simno2);
			 serialNoList =cbcmDbHelperClass.updateSerialNumbersIntheCSSDB(serialNoListFromExcel);
			 simno1=serialNoList.get(0).toString().trim();
			 simno2=serialNoList.get(1).toString().trim();
			 
		 }
				 	 
		 mrPage.selectCardType(AutomationConstants.cloneType).clickOnAddBtn().enterResourceNo(simno1).enterResourceCloneNo(simno2);
		 String missIdn = getDriver().findElement(By.id("msisdnId")).getAttribute("value");
		 
		if(missIdn.length()!=0) {
			System.out.println(" the free no populated in the msisdn text box::"+missIdn);
		}else {
			
			
		}
			 
		getDriver().findElement(mrPage.saveBtn).click();
		Thread.sleep(2000);
		
		Alert alert = getDriver().switchTo().alert();
		String alertText = alert.getText();
		System.out.println("Alert data: " + alertText);
		alert.accept();
		
		mrPage.clickOnVerifiedOrginalDocumentChkBox().clickOnDatButton();
		String parentWindowId2 =switchToWindow1();
		docFrmProfileWindowPage.clickOnDocumentRadioBtn().clickOnSelectBtn();
		 
		getDriver().switchTo().window(parentWindowId2);
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame).switchTo().frame(FramesConfigs.detailsFrame);
		mrPage.clickOnSave();
		    		  
		getWaitUtil().elementPresence(cmdd.captureMultiMateDeviceDetailsLbl, WaitConfigs.pageLoadWait);
		mrPage.clickOnNextBtn();
		getWaitUtil().elementPresence(mrPage.captureCapProfileLbl, WaitConfigs.pageLoadWait);
		   
		mrPage.selectCapProfile(capProfile);
		mrPage.clickOnSave();
		getWaitUtil().elementPresence(mrPage.subrequestDetailsLbl, WaitConfigs.pageLoadWait);
			
		getDriver().switchTo().defaultContent();
		getDriver().switchTo().frame(FramesConfigs.baseFrame);
		mrPage.clickOnSaveButton2();
		getWaitUtil().elementPresence(successFullOperPage.successTitleLbl, WaitConfigs.pageLoadWait);
		Reporter.log("Landed on to the SuccessFull Operation Page");
			
		String successOperationTitle = successFullOperPage.getSuccessOperationTitle();
		Assert.assertEquals(successOperationTitle, AutomationConstants.successfulOperationtitle, "successfull operation title page is not displayed");
					
		String subRequestId = successFullOperPage.getSubRequestId();
		System.out.println("the sub request id ==>"+subRequestId);
		String subRquestId = subRequestId.split(":")[1];		
		System.out.println("the splited sub request id ==>"+subRquestId);
		try {
			getHomePage().clickMenuTree().clickOnDocImg().navigateToFavoriteTab().navigateToRequestInquirySubTab().enterSubReqId(subRquestId).clickOnSearch();
		} catch (InterruptedException e) {
				e.printStackTrace();
		}
		Reporter.log("the normal to clone sub request type::"+subRquestId);
		
		boolean stat = false;
		try {
			stat = getDBUtilities().verifySubRequestStatus("select status from t_soh_subrequest where subrequest_id ="+"'"+subRquestId.toString().trim()+"'");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String status =null;
		if(stat) {
			status="90";
		}else {
			status="49464";
		}
		
		System.out.println("the status of the closed:==>"+status);
		Reporter.log("the status of the sub request is ::"+status);
		Assert.assertEquals(status,"90","the request is closed");
	}

	//@AfterTest(enabled=true)
	public void tearDown() {
		System.out.println("i am in after test method");
		 final Runtime rt = Runtime.getRuntime();
			try {
			Process p=rt.exec("C:\\Users\\jekumar\\Desktop\\ieclose\\ieClose.bat"); 
			} catch (final IOException e) {
			throw new RuntimeException("Failed to run bat file.");
			}
	}
}
