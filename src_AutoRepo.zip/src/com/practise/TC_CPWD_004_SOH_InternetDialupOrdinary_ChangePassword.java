package com.practise;

import org.testng.annotations.Test;

import com.automation.configs.RQMConfigs;
import com.base.utils.RQMUtils;
import com.base.utils.XMLParserUtil;

public class TC_CPWD_004_SOH_InternetDialupOrdinary_ChangePassword {
	

	
	
	@Test
	public void apiTest() {
		
		RQMUtils rqmUtils = new RQMUtils();
		XMLParserUtil xmlParserUtil = new XMLParserUtil();
		
		try {
			
			String className = getClass().getName();
			System.out.println(className);
			String[] tcName=className.split("\\.");
			String testScrptName =tcName[tcName.length-1];
			System.out.println("the test script name is ::"+testScrptName);
			
			rqmUtils.connectRQMandGetTestCaseName(testScrptName);
			
			String webId = xmlParserUtil.retrieveValueFrmResponceFile(RQMConfigs.resFilePath+RQMConfigs.responceTCName,RQMConfigs.webIdTag,0);
			System.out.println("the parsed xml tag value::"+webId);
			
			rqmUtils.connectRQMandGetCurrentExecutionID(webId);
			
			 String currentExecutionId=xmlParserUtil.retrieveValueFrmResponceFileWithAttribute(RQMConfigs.resFilePath+RQMConfigs.responceTCName,
					 RQMConfigs.currentExecutionTag,"6141");
			 System.out.println("the parsed current execution id xml tag value::"+currentExecutionId);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}



}
