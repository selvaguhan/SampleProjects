package com.practise;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.base.utils.BaseTest;
import com.base.utils.RQMUpdate;

public class TC_CDQ_006_SOH_PABXLines_ChangeDQInfo extends BaseTest{
	ITestResult result;
	String testScrptName;
	String testPlanId ="6487";
	@Test
	public void apiTest() {
			
		
		try {
			
			testScrptName = getTestScriptName();
			
			result = getCurrentTestCaseResult();
			System.out.println("the current status ::"+result.getStatus());
			
			Assert.assertEquals(testScrptName, "TC_CDQ_006_SOH_PABXLines_ChangeDQInfo");
		
			getSoftAssert().assertAll();
				
			                                                               
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@AfterTest
	public void tearDown() {
		 RQMUpdate.updateTestCaseStatusIntoRQM(testScrptName, result,testPlanId);

	}                                                                         
	
}
