package com.practise;

import org.apache.bcel.classfile.Method;
import org.testng.ITestContext;
import org.testng.annotations.Test;

public class TestNgParam {
	
	@Test(enabled=true)
	public void test1(ITestContext context) throws Exception {
	    // ...
	    context.setAttribute("A", "1");
	    // ...
	}

	@Test
	public void test2(ITestContext context) throws Exception {
	    String a=(String) context.getAttribute("A");
	    System.out.println(a);
	    // ...
	}
	
	@Test
	public void test3(ITestContext context) throws Exception {
	    String a=(String) context.getAttribute("A");
	    System.out.println("test 3:::"+a);
	    // ...
	}

}
