package com.practise;

import java.security.SecureRandom;
import java.util.Random;

public class RandomRange {
	
	public static final void main(String... aArgs){
		/*int random1 = (int )(Math.random() * 20 + 1);
		int random2 = (int )(Math.random() * 20 + 1);*/
/*		int no = random1();
		System.out.println(no);
		int no1 = random1();
		System.out.println(no1);
		int no2 = random1();
		System.out.println(no2);*/
		int no3 = random1();
		System.out.println(no3);
		
/*		SecureRandom random = new SecureRandom();
		int num = random.nextInt(100000);
		String formatted = String.format("%08d", num); 
		System.out.println(formatted);*/
		
	
	  }
	  
	public static int random1() {
		int random1 = (int )(Math.random() * 20 + 1);
		System.out.println(random1);
		return random1;
		
	}
	

}
