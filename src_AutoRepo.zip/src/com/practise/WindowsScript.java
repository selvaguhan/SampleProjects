package com.practise;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class WindowsScript {
	
	 public static void main(String[] args) throws IOException {
		 
		  
		 	
		     Runtime rt = Runtime.getRuntime();
		 	
		  
		 	
		     Process process = rt.exec(new String[]{"D:\\test.bat TC_CDQ_001_SOH_DualPlayProduct_ChangeDQInfo"});
		 	
		  
		 	
		     InputStream inputStream = process.getInputStream();
		 	
		  
		 	
		     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
		 	
		  
		 	
		     String line;
		 	
		  
		 	
		     while ((line = bufferedReader.readLine()) != null) {
		 	
		  
		 	
		         if(line.contains("value="))
		 	
		  
		 	
		          System.out.println(line);
		 	
		  
		 	
		     }
		 	
		  
		 	
		     System.out.println("end------");
		 	
		  
		 	
		   }

}
