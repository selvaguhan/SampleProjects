package com.practise;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.testng.annotations.Test;

import com.automation.configs.DBQuerryConstants;
import com.base.utils.BaseTest;

public class DBDemoTest extends BaseTest{
	
	ResultSet rs;
	
	//@Test
	public void test() throws SQLException {
		
		//ArrayList<String> productNoList = new ArrayList<String>();
		ArrayList<String> serialNoList = new ArrayList<String>();
		
			/*rs=getDBUtilities().fetchDataFromDataBase(DBQuerryConstants.getFreeProductNumberAndAreaCode);
		
	
			while(rs.next()) {
				String areaCode=rs.getString(DBQuerryConstants.areaCodeAttribute);
				String productNumber=rs.getString(DBQuerryConstants.productNumberAttribute);
				productNoList.add(areaCode);
				productNoList.add(productNumber);
			}
			
			System.out.println(productNoList);
			String areaCode=productNoList.get(0);
			String productNum=productNoList.get(1);
			
			System.out.println("the framed no==>"+DBQuerryConstants.getMsidnNo(areaCode+productNum));
			
			rs=getDBUtilities().fetchDataFromDataBase(DBQuerryConstants.getMsidnNo(areaCode+productNum));
			
			String msidnNo = null;
			while(rs.next()) {
					msidnNo=rs.getString(DBQuerryConstants.msisdnAttribute);
			}
			
			if(msidnNo==null) {
				System.out.println("need to insert data into the table");
				getDBUtilities().insertValuesIntoDB(DBQuerryConstants.getInserQuerryForMSISDN(areaCode,productNum));
			}else {
				System.out.println("need to update the data in the table");
				getDBUtilities().updateValuesIntoDB(DBQuerryConstants.getUpdateMsidnNoIntoNumbersDBQuerry(areaCode, productNum));
			}*/
			
			
			
			
			rs=getDBUtilities().fetchDataFromCBCMDB(DBQuerryConstants.getFreeSerialNumbersFromCBCMDB);
			
			while(rs.next()) {
				String serialNo=rs.getString(DBQuerryConstants.iccidNoAttribute);
				serialNoList.add(serialNo);
			}
			
			
			//getDBUtilities().insertValuesIntoDB(DBQuerryConstants.insertQuerry);
			
			getDBUtilities().updateValuesIntoCSSDB(DBQuerryConstants.getUpdateSerialNoQuerry(serialNoList.get(serialNoList.size()-1)));
		
		//System.out.println("the array list data of serial no ==>"+serialNoList);
		
		//System.out.println("the last index of the serial no array list is ==>"+serialNoList.get(serialNoList.size()-1));
		
	}


	@Test
	public void test123() {
		
		ResultSet rs= getDBUtilities().fetchDataFromCBCMDB(DBQuerryConstants.getMultiMateAccountNo("583376428"));
		String accountNo=getDBUtilities().iterateResultSet(rs, DBQuerryConstants.accountNumberAttribute);
		System.out.println("the multimate account number::"+accountNo);
		
	}
}
