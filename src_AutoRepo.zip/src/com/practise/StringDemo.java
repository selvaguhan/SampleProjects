package com.practise;

public class StringDemo {
	
		  public static void main(String[] args) {
		    String text = "056";
		    
		    String tt = text.replaceFirst("(?:05)+", "5");
		    
		    //System.out.println(text.replaceFirst("(?:05)+", "5"));
		    System.out.println(tt);
		  }
		

}
