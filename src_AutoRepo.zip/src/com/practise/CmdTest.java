package com.practise;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CmdTest {
	
	public static void main(String[] args) throws Exception {
		
		 String jarfile = "java -jar"+" "+'"'+"C:\\Users\\jekumar\\Desktop\\rqmIntgeration\\RQMUrlUtility\\RQMUrlUtility.jar"+'"';
		 String userCmd =" "+"-command GET -user"+" "+"hkhirodkar"+" "+"-password eatmydust@2018"+" ";
		 String filepath = "-filepath"+" "+'"'+"C:\\Users\\jekumar\\Desktop\\testRQM\\TCName.xml"+'"'+" ";
		 String urlPath="-url"+" "+'"'+"https://rqmserver.etisalat.corp.ae:9443/qm2/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Etisalat Regression Suite - 2018/testcase/TC_CDQ_001_SOH_DualPlayProduct_ChangeDQInfo"+'"';

		 System.out.println(jarfile+userCmd+filepath+urlPath);
        ProcessBuilder builder = new ProcessBuilder(
        		new String[] {"cmd.exe", "/c",jarfile+userCmd+filepath+urlPath});
        builder.redirectErrorStream(true);
        Process p = builder.start();
     
        
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while (true) {
            line = r.readLine();
            if (line == null) { break; }
            System.out.println(line);
        }
    }

}
