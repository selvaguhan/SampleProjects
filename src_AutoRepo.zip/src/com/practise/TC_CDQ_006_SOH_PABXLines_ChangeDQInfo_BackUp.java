package com.practise;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.base.utils.RQMUpdate;
import com.base.utils.RQMUtils;
import com.base.utils.XMLParserUtil;

public class TC_CDQ_006_SOH_PABXLines_ChangeDQInfo_BackUp {
	

	ITestResult result;
	SoftAssert sa;
	RQMUtils rqmUtils = new RQMUtils();
	XMLParserUtil xmlParserUtil = new XMLParserUtil();
	String testScrptName;
		
	@Test
	public void apiTest() {
		
		
		
		try {
			
			sa = new SoftAssert();
			String className = getClass().getName();
			System.out.println(className);
			String[] tcName=className.split("\\.");
			testScrptName=tcName[tcName.length-1];
			System.out.println("the test script name is ::"+testScrptName);
			
			result = Reporter.getCurrentTestResult();
			System.out.println("the current status ::"+result.getStatus());
			
			Assert.assertEquals(testScrptName, "aas");
		
			sa.assertAll();
			
			
									
			/*rqmUtils.connectRQMandGetTestCaseName(testScrptName);
			
			String webId = xmlParserUtil.retrieveValueFrmResponceFile(RQMConfigs.resFilePath+RQMConfigs.responceTCName,RQMConfigs.webIdTag,0);
			System.out.println("the parsed xml tag value::"+webId);
			
			rqmUtils.connectRQMandGetCurrentExecutionID(webId);
			
			String currentExecutionId=xmlParserUtil.retrieveValueFrmResponceFileWithAttribute(RQMConfigs.resFilePath+RQMConfigs.responceTCName,
					 RQMConfigs.currentExecutionTag,"6487");
			System.out.println("the parsed current execution id xml tag value::"+currentExecutionId);
				 
			rqmUtils.connectRQMandGetTempFile(currentExecutionId);
			
			String stateValue = xmlParserUtil.retrieveValueFrmResponceFile(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,"ns5:state",0);
			System.out.println("current status of the Test Cases::"+stateValue);
			
			if(stateValue.contains("passed")) {
				String inprogress = xmlParserUtil.setTextToStateTag(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,"ns5:state",RQMConfigs.inProgressState,0);
				System.out.println("the after making inprogress::"+inprogress);
			}
			
			
			switch (result.getStatus()) {
		    case ITestResult.SUCCESS:
		        System.out.println("======PASS=====");
		        String passed = xmlParserUtil.setTextToStateTag(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,"ns5:state",RQMConfigs.passedState,0);
				System.out.println("i am in passed switch block::"+passed);
		        // my expected functionality here when passed
		        break;

		    case ITestResult.FAILURE:
		        System.out.println("======FAIL=====");
		        String failed = xmlParserUtil.setTextToStateTag(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,"ns5:state",RQMConfigs.failedState,0);
		   		System.out.println("i am in failed switch block::"+failed);
		        // my expected functionality here when passed
		        
		        break;

		    default:
		        throw new RuntimeException("Invalid status");
		    }
			 		
			String assa = xmlParserUtil.setTextToStateTag(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,"ns5:state",RQMConfigs.passedState,0);
			System.out.println("the parsed xml tag value::"+assa);
			
			rqmUtils.connectRQMandUpdateTestCaseStatus(currentExecutionId);*/
			
			
			//xmlParserUtil.writeFile(assa);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@AfterTest
	public void tearDown() {
		 RQMUpdate.updateTestCaseStatusIntoRQM(testScrptName, result,"6487");
		/*try {
			rqmUtils.connectRQMandGetTestCaseName(testScrptName);
			String webId = xmlParserUtil.retrieveValueFrmResponceFile(RQMConfigs.resFilePath+RQMConfigs.responceTCName,RQMConfigs.webIdTag,0);
			System.out.println("the parsed xml tag value::"+webId);
			
			rqmUtils.connectRQMandGetCurrentExecutionID(webId);
			
			String currentExecutionId=xmlParserUtil.retrieveValueFrmResponceFileWithAttribute(RQMConfigs.resFilePath+RQMConfigs.responceTCName,
					 RQMConfigs.currentExecutionTag,"6487");
			System.out.println("the parsed current execution id xml tag value::"+currentExecutionId);
				 
			rqmUtils.connectRQMandGetTempFile(currentExecutionId);
			
			String stateValue = xmlParserUtil.retrieveValueFrmResponceFile(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,"ns5:state",0);
			System.out.println("current status of the Test Cases::"+stateValue);
			
			if(stateValue.contains("passed")) {
				String inprogress = xmlParserUtil.setTextToStateTag(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,"ns5:state",RQMConfigs.inProgressState,0);
				System.out.println("the after making inprogress::"+inprogress);
			}
			
			if(result.getStatus() == ITestResult.SUCCESS)
		    {

		        //Do something here
		        System.out.println("passed **********");
		        String passed = xmlParserUtil.setTextToStateTag(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,"ns5:state",RQMConfigs.passedState,0);
				System.out.println("i am in passed switch block::"+passed);
		    }

		    else if(result.getStatus() == ITestResult.FAILURE)
		    {
		         //Do something here
		        System.out.println("Failed ***********");
		        String failed = xmlParserUtil.setTextToStateTag(RQMConfigs.resFilePath+RQMConfigs.responceTempFile,"ns5:state",RQMConfigs.failedState,0);
		   		System.out.println("i am in failed switch block::"+failed);

		    }
			
			rqmUtils.connectRQMandUpdateTestCaseStatus(currentExecutionId);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
		
		
	


}
