package com.practise;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.Assert;

import com.base.utils.PropUtils;

import jxl.demo.Demo;
import oracle.jdbc.pool.OracleDataSource;

public class DBDemo {
	
	 	/*static String jdbcUrl = "jdbc:oracle:thin:@AU941:1527:CBCMRCDL";
	 	static String userid = "cbcm_customer";
	 	static String password = "cbcm54321"; */
	 	static Connection conn;
	 	static java.sql.Statement st;
	 	static PropUtils pp;
	 	
 	
	 	static String jdbcUrl1 = "jdbc:oracle:thin:"+"@";
	 	static String jdbc;
		 static String userid1;
	 	 static String password1;
	 	 
	    public static Connection getDBConnection() throws SQLException{
	     	int port = Integer.parseInt(pp.getDbPort());
	     	
	    	jdbc=jdbcUrl1+pp.getDbLocalHost()+":"+port+":"+pp.getDbSID();
	    	System.out.println("fffff"+ jdbc);
	    	
	    	 userid1 = pp.getDbUserId();
		 	  password1 = pp.getDbPassword(); 
	        OracleDataSource ds;
	        ds = new OracleDataSource();
	        ds.setURL(jdbc);
	        conn=ds.getConnection(userid1,password1);
	        
	        return conn;
	        
	    }
	    
	    public static void executeQueyy() throws Exception {
	    	
	    	System.out.println("the db connection==>"+getDBConnection());
	    	
			st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from numbers where msisdn=971507057951");
			while(rs.next()) {
				String simNo=rs.getString("MSISDN");
				System.out.println("the msisdn no:"+simNo);
			}
		
	    }
	
/*	    public static ArrayList<String> executeQuerry1(String querry) {
	    	
	    	System.out.println("the db name from profile==>"+pp.getBrowserType());
			ArrayList<String> al = new ArrayList<String>();
		try {
			System.out.println("the db connection==>"+getDBConnection());
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(querry);
			while(rs.next()) {
				String simNo=rs.getString("NEW_ICCID_NO");
				al.add(simNo);
			}
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return al;
	}*/
	    
	public static void main(String args[]) {
		//Demo dd = new Demo();
		pp=new PropUtils();
    	//pp.loadPropFile();
  // System.out.println("the result :::"+Demo.executeQueyy());
    	    	
		//ArrayList<String> al = executeQuerry1("select NEW_ICCID_NO from t_soh_gsm_clone_sim_dtls where subrequest_id ='583336832'");

	}

}
