package com.example.etisalat.myapplication.com.etisalat.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class NavigationScreen {


    @FindBy(xpath = "//android.widget.TextView[@text='Recharges & Payments']")
    @CacheLookup
    public WebElement rechargeAndPayTab;

    public void clickOnRechargeAndPayTab(){
        rechargeAndPayTab.click();
    }



    @FindBy(xpath = "//android.widget.TextView[@text='Bills and Payments']")
    @CacheLookup
    public WebElement billsAndPaymentsTab;

    @FindBy(xpath = "//android.widget.TextView[@text='Collect Call']")
    @CacheLookup
    public WebElement collectCall;

    public void clickOnCollectCall(){
        collectCall.click();
    }

    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Pay & Recharge for Others')]")
    @CacheLookup
    public WebElement payAndRechargeForOthersTab;

    public void clickOnPayAndRechargeForOthersTab(){
        payAndRechargeForOthersTab.click();
    }

    public void clickOnBillsAndPaymentsTab(){
        billsAndPaymentsTab.click();
    }

    @FindBy(xpath = "//android.widget.EditText[@text='0543935607']")
    @CacheLookup
    public WebElement prepaidUserProfile;

    @FindBy(xpath= "//android.widget.TextView[@text='SEE DETAILS AND EDIT']")
    @CacheLookup
    public WebElement seeDetailsAndEditBtn;

    public void clickOnSeeDetailsAndEditBtn(){
        seeDetailsAndEditBtn.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Out of Credit Services']")
    @CacheLookup
    public WebElement outOfCreditServicesTab;

    public void clickOnOutOfCreditServicesTab(){
        outOfCreditServicesTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Etisalat Shop']")
    @CacheLookup
    public WebElement etisalatShopTab;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_postpaid_addons']")
    public WebElement postPaidAddOnsTab;

    @FindBy(xpath = "//android.widget.TextView[@text='DATA']")
    @CacheLookup
    public WebElement dataTab;


    @FindBy(xpath = "//android.widget.ImageButton[@resource-id='com.Etisalat.ETIDA:id/search_toggle']")
    @CacheLookup
    public WebElement searchBtn;




    @FindBy(xpath = "//android.widget.TextView[@text='month plan']")
    @CacheLookup
    public WebElement monthplan;

    @FindBy(xpath = "//android.widget.TextView[@text='Exclusive App Offer']")
    @CacheLookup
    public WebElement exclusiveAppOffer;


    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/searchEdit']")
    @CacheLookup
    public WebElement searchTxt;




    @FindBy(xpath = "//android.widget.TextView[@text='View Bills']")
    @CacheLookup
    public WebElement viewBillsTab;

    public void clickOnViewBillsTab(){
        viewBillsTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Pay My Bills']")//Pay My Bills
    @CacheLookup
    public WebElement payMyBillsTab;

    @FindBy(xpath = "//android.widget.TextView[@text='Transaction History']")
    @CacheLookup
    public WebElement transactionHistoryTab;

    @FindBy(xpath= "//android.widget.TextView[@text='Account settings']")
    @CacheLookup
    public WebElement accountSettingsTab;

    public void clickOnAccountSettingsTab(){
        accountSettingsTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='mParking']")
    @CacheLookup
    public WebElement mParkingTab;

    @FindBy(xpath = "//android.widget.TextView[@text='Recharge']")
    @CacheLookup
    public WebElement rechargeTab;

    @FindBy(xpath = "//android.widget.TextView[@text='Set Bill Limit']")
    @CacheLookup
    public WebElement setBillLimitTab;


    public void clickOnRechargeTab(){
        rechargeTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Usage']")
    @CacheLookup
    public WebElement usageTab;

    public void clickOnUsageTab(){
        usageTab.click();
    }


    @FindBy(xpath = "//android.widget.TextView[@text='Share Credits and Data']")
    @CacheLookup
    public WebElement shareCreditAndDataTab;

    public void clickOnShareCreditAndDataTab(){
        shareCreditAndDataTab.click();
    }

    @FindBy(xpath= "//android.widget.TextView[@text='Weekly']")
    @CacheLookup
    public WebElement frequencyBtn;

    public void clickOnFrequencyBtn(){
        frequencyBtn.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='My Accounts']")
    @CacheLookup
    public WebElement myAccountTab;

    public void clickOnMyAccountTab(){
        myAccountTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Adars']")
    @CacheLookup
    public WebElement etisalatAutomationUserProfile;



    @FindBy(id = "com.Etisalat.ETIDA:id/cover_title")
    @CacheLookup
    public WebElement profileCoverTitle;


    @FindBy(xpath = "//android.widget.TextView[@text='Account settings']")
    @CacheLookup
    public WebElement accountSettings;


    @FindBy(xpath = "//android.widget.TextView[@text='4 Digit PIN']")
    @CacheLookup
    public WebElement digit4Pin;

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_ivr_pin']")
    @CacheLookup
    public WebElement digit4PinTxt;

    @FindBy(xpath= "//android.widget.TextView[@text='My Plan & Add ons']")
    @CacheLookup
    public WebElement myPlanAndAddOnsTab;

    public void clickOnMyPlanAndAddOns(){
        myPlanAndAddOnsTab.click();
    }

    @FindBy(xpath= "//android.widget.TextView[@text='My Smiles Points']")
    @CacheLookup
    public WebElement mySmilesPointsTab;

    public void clickOnMySmilesPointsTab(){
        mySmilesPointsTab.click();
    }

    @FindBy(xpath= "//android.widget.TextView[@text='Security Settings']")
    @CacheLookup
    public WebElement securitySettingsTab;

    public void clickOnSecuritySettingsTab(){
        securitySettingsTab.click();
    }

    @FindBy(xpath = "//android.widget.Button[@resource-id='com.Etisalat.ETIDA:id/bt_subscribe']")
    @CacheLookup
    public WebElement continueBtn;


    @FindBy(xpath = "//android.widget.TextView[@text='Help & Support']")
    @CacheLookup
    public WebElement helpAndSupportTab;

    public void clickOnHelpAndSupportTab(){
        helpAndSupportTab.click();
    }




    @FindBy(id = "com.Etisalat.ETIDA:id/et_recharge_amount")
    @CacheLookup
    public WebElement rechargeAmountTxt;

    public void enterPrepaidRechargeAmount(String amount){
        rechargeAmountTxt.sendKeys(amount);
    }


    @FindBy(xpath= "//android.widget.TextView[@text='My Info']")
    @CacheLookup
    public WebElement myInfoLnk;

    public void clickOnMyInfoLnk(){
        myInfoLnk.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/tv_ap_username")//com.Etisalat.ETIDA:id/tv_ap_username
    @CacheLookup
    public WebElement profileUsrName;

    @FindBy(xpath = "//android.widget.TextView[@text='Auto Recharge']")
    @CacheLookup
    public WebElement autoRechargeTab;

    public void clickOnAutoRechargeTab(){
        autoRechargeTab.click();
    }

    @FindBy(xpath= "//android.widget.RadioButton[@resource-id='com.Etisalat.ETIDA:id/rb_weekly']")
    @CacheLookup
    public WebElement weeklyRadioBtn;

    @FindBy(xpath = "//android.widget.TextView[@text='Weekly']")
    @CacheLookup
    public WebElement weeklyTab;

    public void clickOnWeeklyRadioBtn(){
        weeklyRadioBtn.click();
    }

    @FindBy(xpath= "//android.widget.RadioButton[@resource-id='com.Etisalat.ETIDA:id/rb_monthly']")
    @CacheLookup
    public WebElement monthlyRadioBtn;

    public void clickOnMonthlyRadioBtn(){
        monthlyRadioBtn.click();
    }




    @FindBy(xpath= "//android.widget.TextView[@text='Sunday']")
    @CacheLookup
    public WebElement sunday;

    public void clickOnSunday(){
        sunday.click();
    }

    @FindBy(xpath= "//android.widget.TextView[@text='2']")
    @CacheLookup
    public WebElement monthlyFrequencyDate;

    public void clickOnMonthlyFrequencyDate(){
        monthlyFrequencyDate.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/tv_next")
    @CacheLookup
    public WebElement nextBtn;

    public void clickOnNextBtn(){
        nextBtn.click();
    }

    @FindBy(xpath= "//android.widget.TextView[@text='25']")
    @CacheLookup
    public WebElement aed25;

    public void clickOn25AedTab(){
        aed25.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/cb_terms_and_conditions")
    @CacheLookup
    public WebElement agreeRadioBtn;

    public void clickOnAgreeRadioBtn(){
        agreeRadioBtn.click();
    }

    @FindBy(xpath= "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_delete_auto_recharge']")
    @CacheLookup
    public WebElement deleteAutoPayBtn;

    public void clickOnDeleteAutoPayBtn(){
        deleteAutoPayBtn.click();
    }


}
