package com.example.etisalat.myapplication.com.etisalat.myetisalat.helpandsupport;

import com.example.etisalat.myapplication.com.etisalat.baseutils.AppInstallAndUninstallTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class StoreLocatorTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    AppInstallAndUninstallTest mmm;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void storeLocatorTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        mmm = new AppInstallAndUninstallTest();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();
        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        driver.swipe(500,1500,30,0,2000);
        //mmm.scrollDown(489,1566,0,0);

        //waitForElement(navigationScreen.helpAndSupportTab);
        navigationScreen.clickOnHelpAndSupportTab();

        waitForElement(myEtisalatAppPages.storeLocatorTab);
        myEtisalatAppPages.clickOnStoreLocatorTab();

        /*waitForElement(myEtisalatAppPages.cancelBtn);
        myEtisalatAppPages.clickOnCancelBtn();*/

        //waitForElement(myEtisalatAppPages.messagePopUpStoreLocator);

        String liveMsg = myEtisalatAppPages.myLocation.getText();
        System.out.println("the retrived latest calls balance from the application::"+liveMsg);
        Assert.assertEquals("text is not matching","My Location",liveMsg);
    }

    @After
    public void tearDwon(){
        driver.quit();
    }


}
