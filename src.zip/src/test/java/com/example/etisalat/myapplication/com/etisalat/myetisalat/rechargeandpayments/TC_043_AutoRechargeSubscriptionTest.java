package com.example.etisalat.myapplication.com.etisalat.myetisalat.rechargeandpayments;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;

public class TC_043_AutoRechargeSubscriptionTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;


    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void tc_043_AutoRechargeSubscriptionTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.rechargeAndPayTab);
        navigationScreen.clickOnRechargeAndPayTab();

        waitForElement(navigationScreen.autoRechargeTab);
        navigationScreen.clickOnAutoRechargeTab();

       /* waitForElement(navigationScreen.seeDetailsAndEditBtn);
        navigationScreen.clickOnSeeDetailsAndEditBtn();*/

        waitForElement(navigationScreen.frequencyBtn);
        navigationScreen.clickOnFrequencyBtn();

        waitForElement(navigationScreen.sunday);
        navigationScreen.clickOnSunday();

        //String tt = navigationScreen.weeklyRadioBtn.getAttribute("checked");

      /*  if(tt.equalsIgnoreCase("true")){
            System.out.println("weekly frequency is selected , we need to select monthly"+tt);
            waitForElement(navigationScreen.monthlyRadioBtn);
            navigationScreen.clickOnMonthlyRadioBtn();

            waitForElement(navigationScreen.monthlyFrequencyDate);
            navigationScreen.clickOnMonthlyFrequencyDate();

            waitForElement(navigationScreen.nextBtn);
            navigationScreen.clickOnNextBtn();


        }else{
            waitForElement(navigationScreen.weeklyRadioBtn);
            navigationScreen.clickOnWeeklyRadioBtn();

            waitForElement(navigationScreen.monday);
            navigationScreen.clickOnMonday();


        }*/


        waitForElement(navigationScreen.aed25);
        navigationScreen.clickOn25AedTab();

        try{
            Thread.sleep(3000);
        }catch (Exception e){

        }

        waitForElement(navigationScreen.agreeRadioBtn);
        navigationScreen.clickOnAgreeRadioBtn();

        try{
            Thread.sleep(3000);
        }catch (Exception e){

        }

        waitForElement(myEtisalatAppPages.next12);
        myEtisalatAppPages.next12.click();


        waitForElement(homePage.lastUsedCheckBox1);
        homePage.lastUsedCheckBox1.click();

        waitForElement(myEtisalatAppPages.next12);
        myEtisalatAppPages.next12.click();

        try{
            Thread.sleep(3000);
        }catch (Exception e){

        }
        waitForElement(myEtisalatAppPages.okBtn);
        myEtisalatAppPages.okBtn.click();


        waitForElement(homePage.cardNametxt);
        homePage.cardNametxt.sendKeys("asas");

        waitForElement(homePage.cvvTxt);
        homePage.enterCVVNo("123");

        waitForElement(homePage.payBtn);
        homePage.clickOnPayBtn();

        waitForElement(homePage.paymentHeadingTitle);
        String payMentText =homePage.paymentHeadingTitle.getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"PAYMENT SUCCESSFUL");

    }
    @After
    public void end() {
        driver.quit();
    }

}
