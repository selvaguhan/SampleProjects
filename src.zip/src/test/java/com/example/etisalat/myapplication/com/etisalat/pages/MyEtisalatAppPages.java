package com.example.etisalat.myapplication.com.etisalat.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class MyEtisalatAppPages {

    @FindBy(id = "//com.Etisalat.ETIDA:id/menu_toggle")
    public WebElement myAccountsTab;

    @FindBy(xpath = "//android.widget.TextView[@text='DATA']")
    public WebElement dataTab;

    public void clickOnDataTab(){
        dataTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Home']")
    @CacheLookup
    public WebElement homeTab;

    public String getHomeTab(){
        String mm = homeTab.getText();
        return  mm;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Local Credit Transfer']")
    public WebElement localCreditTransferTab;

    public void clickOnLocalCreditTransferTab(){
        localCreditTransferTab.click();
    }


    @FindBy(xpath = "//android.widget.TextView[@text='Dubai']")
    public WebElement selectEmirate;


    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_city']")
    public WebElement billLimitDropDown;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/package_name']")
    public WebElement packageName;

    @FindBy(xpath = "//android.widget.TextView[@text='International Minutes Add-on']")
    public WebElement internationalMinAddOn;

    @FindBy(xpath = "//android.widget.TextView[@text='250MB + 250MB Plus Month Plan']")
    public WebElement dayPack250mb;


    @FindBy(xpath = "//android.widget.TextView[@text='3 GB MONTHLY DATA PLUS PACKAGE']")
    public WebElement dataPackage3gb;

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_current_password']")
    @CacheLookup
    public WebElement currentPasswordTxt;

    public void enterCurrentPassword(String currentPassword){
        currentPasswordTxt.sendKeys(currentPassword);
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Featured']")
    public WebElement featuredTab;

    @FindBy(xpath = "//android.widget.CheckBox[@resource-id='com.Etisalat.ETIDA:id/cb_mstore_add_to_bill']")
    public WebElement deductBalanceChk;

    @FindBy(xpath = "//android.widget.CheckBox[@resource-id='com.Etisalat.ETIDA:id/cb_mstore_pay_with_points']")
    public WebElement smilesPointChk;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/buy_package']")
    public WebElement buyBtn;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_logout_ok']")
    public WebElement logOutOkBtn;

    @FindBy(xpath = "//android.widget.Button[@resource-id='com.Etisalat.ETIDA:id/btn_upgrade_ok']")
    public WebElement upgradeOkBtn;



    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_mi_address_line_1']")
    @CacheLookup
    public WebElement addressTxt1;

    public void enterAddress1(String address){
        addressTxt1.clear();
        addressTxt1.sendKeys(address);
    }

    @FindBy(xpath = "//android.widget.Button[@resource-id='com.Etisalat.ETIDA:id/btn_mi_save']")//com.Etisalat.ETIDA:id/btn_mi_save
    @CacheLookup
    public WebElement saveBtn;

    public void clickOnSaveBtn(){
        saveBtn.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_cost_title']")
    public WebElement costTitle;

    @FindBy(xpath = "//android.widget.CheckedTextView[@text='200 AED']")
    public WebElement selectBillLimitAmount;

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_mi_friendly_name']")//com.Etisalat.ETIDA:id/et_mi_friendly_name
    @CacheLookup
    public WebElement nickNameTxt;

    public void enterNickName(String nickNme){
        nickNameTxt.sendKeys(nickNme);
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_item_name']")
    public WebElement payBillList;

    @FindBy(xpath = "//android.widget.TextView[@text='All']")
    public WebElement allTab;

    @FindBy(xpath = "//android.widget.TextView[@text='USAGE']")
    public WebElement usageTab;



    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_item_date']")
    public WebElement payBillDate;

    @FindBy(xpath= "//android.widget.TextView[@text='4 Digit PIN']")
    @CacheLookup
    public WebElement digitPin4;

    public void clickOn4DigitPin(){
        digitPin4.click();
    }

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_password']")//com.Etisalat.ETIDA:id/et_password
    @CacheLookup
    public WebElement newPasswordTxt;

    public void enterNewPassword(String newPassword){
        newPasswordTxt.clear();
        newPasswordTxt.sendKeys(newPassword);
    }

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_confirm_password']")//com.Etisalat.ETIDA:id/et_confirm_password
    @CacheLookup
    public WebElement confirmPasswordTxt;

    public void enterConfirmPassword(String newPassword){
        confirmPasswordTxt.clear();
        confirmPasswordTxt.sendKeys(newPassword);
    }

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_ivr_pin']")
    @CacheLookup
    public WebElement existing4DigitPinTxt;

    public void enterExisting4DigitPin(String pin){
        existing4DigitPinTxt.clear();
        existing4DigitPinTxt.sendKeys(pin);
    }


    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_ivr_new_pin']")
    @CacheLookup
    public WebElement newPinTxt;

    public void enterNewPin(String pin){
        //newPinTxt.clear();
        newPinTxt.sendKeys(pin);
    }

    @FindBy(xpath = "//android.widget.TextView[contains(@text,'International Credit Transfer')]")
    public WebElement internationalCreditTransferTab;

    public void clickOnInternationalCreditTransferTab(){
        internationalCreditTransferTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[contains(@text,'Data transfer')]")
    public WebElement dataTransferTab;

    public void clickOnDataTransferTab(){
        dataTransferTab.click();
    }



    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_viewPackages']")
    public WebElement myAddonsList;

    public String getAddons(){
        String addons=myAddonsList.getText().toString().trim();
        return  addons;
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/ict_tv_country_selected']")
    public WebElement selectedCounty;

    public String getSelectedCounty(){
        String addons=selectedCounty.getText().toString().trim();
        return  addons;
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/ict_tv_mobile_no']")//com.Etisalat.ETIDA:id/ict_tv_mobile_no
    public WebElement givenInterMobNumber;

    public String getGivenInterMobNumber(){
        String addons=givenInterMobNumber.getText().toString().trim();
        return  addons;
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/ProgressValue']")
    public WebElement balanceDataUsage;

    public String getBalenceData(){
        String dataBalance=balanceDataUsage.getText().toString().trim();
        return  dataBalance;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='CALLS']")
    public WebElement callsTab;
    public void clickOnCallsTab(){
        callsTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/ProgressValue']")
    public WebElement callsBalance;

    public String getBalenceCalls(){
        String callBalance=callsBalance.getText().toString().trim();
        return  callBalance;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='MESSAGES']")
    public WebElement messageTab;

    public void clickOnMessageTab(){
        messageTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/ProgressValue']")
    public WebElement messageBalance;

    public String getBalenceMessages(){
        String msgBalance=messageBalance.getText().toString().trim();
        return  msgBalance;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Extras']")
    public WebElement extrasTab;

    public void clickOnExtrasTab(){
         extrasTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_bundle_usage']")
    public WebElement tvSubScriptionUsage;

    public String getTVSubScriptionUsage(){
        String tvSubScrptionUsage=tvSubScriptionUsage.getText().toString().trim();
        return  tvSubScrptionUsage;
    }



    @FindBy(xpath = "//android.widget.Button[@resource-id='com.Etisalat.ETIDA:id/btn_usage_pay_bill']")
    @CacheLookup
    public WebElement rechargeBtn;

    public void clickOnRechargeBtn(){
        rechargeBtn.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Live Chat']")
    public WebElement liveChatTab;
    public void clickOnLiveChatTab(){
        liveChatTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='How can we help you?']")
    public WebElement howCanHelpYou;
    public String validateTheLiveChatMessage(){
        String msg=howCanHelpYou.getText();
        return msg;
    }


    @FindBy(xpath = "//android.widget.TextView[@text='Contact Etisalat']")
    public WebElement contactEtisalatTab;
    public void clickOnContactEtisalatTab(){
        contactEtisalatTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Terms & Conditions']")
    public WebElement termsAndConditionsTab;
    public void clickOnTermsAndConditionsTab(){
        termsAndConditionsTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Other Etisalat Apps']")
    public WebElement otherEtisalatAppTab;
    public void clickOnOtherEtisalatAppTab(){
        otherEtisalatAppTab.click();
    }


    @FindBy(xpath = "//android.widget.TextView[@text='Email us']")
    public WebElement emailUsTab;
    public String validateEmailUsTab(){
        String msg=emailUsTab.getText();
        return msg;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='care@etisalat.ae']")
    public WebElement careEmailId;
    public String validateCareEmailId(){
        String msg=careEmailId.getText();
        return msg;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='roamingcare@etisalat.ae']")
    public WebElement roamingCareId;
    public String validateRoamingCareEmailId(){
        String msg=roamingCareId.getText();
        return msg;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='United Arab Emirates']")
    public WebElement uaeRegionTab;
    public void clickOnUAERegionTab(){
        uaeRegionTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Terms & Conditions']")
    public WebElement termsAndConditionList;
    public String validateTermsAndConditions(){
        String msg=termsAndConditionList.getText();
        return msg;
    }


    @FindBy(xpath = "//android.widget.TextView[@text='Smiles by Etisalat']")
    public WebElement uaeRegionApp;
    public String validateUAERegionApp(){
        String msg=uaeRegionApp.getText();
        return msg;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Saudi Arabia']")
    public WebElement saudiArabiaTab;
    public void clickOnsaudiArabiaTab(){
        saudiArabiaTab.click();
    }



    @FindBy(xpath = "//android.widget.TextView[@text='Diabetes Test']")
    public WebElement saudiArabiaApp;
    public String validateSaudiArabiaApp(){
        String msg=saudiArabiaApp.getText();
        return msg;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Egypt']")
    public WebElement egyptTab;
    public void clickOnEgyptTab(){
        egyptTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='EasyMobile App']")
    public WebElement egyptApp;
    public String validateEgyptApp(){
        String msg=egyptApp.getText();
        return msg;
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/label_my_addons']")
    @CacheLookup
    public WebElement myPlanAndAddOnsLbl;

    public String getmyPlanAndAddOns(){
        String mm = myPlanAndAddOnsLbl.getText();
        return  mm;
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_smile_points']")
    @CacheLookup
    public WebElement totalSmilesPoints;

    public String getMyTotalSmilesPoints(){
        String mm = totalSmilesPoints.getText();
        return  mm;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Change Password']")
    public WebElement changePasswordTab;
    public void clickOnChangePasswordTab(){
        changePasswordTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_ap_username']")
    @CacheLookup
    public WebElement updatedUserName;

    public String getUpdatedUsrName(){
        String mm = updatedUserName.getText();
        return  mm;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Pakistan']")
    public WebElement pakistanTab;
    public void clickOnPakistanTab(){
        pakistanTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='TouchPTCL']")
    public WebElement pakistanApp;
    public String validatePakistanApp(){
        String msg=pakistanApp.getText();
        return msg;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Sri Lanka']")
    public WebElement sriLankaTab;
    public void clickOnSriLankaTab(){
        sriLankaTab.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Etisalat GlobalTalk']")
    public WebElement sriLankaApp;
    public String validateSriLankaApp(){
        String msg=sriLankaApp.getText();
        return msg;
    }



    @FindBy(xpath = "//android.widget.TextView[@text='Call us']")
    public WebElement callUsTab;
    public String validateCallUsTab(){
        String msg=callUsTab.getText();
        return msg;
    }

    @FindBy(xpath = "//android.widget.ImageButton[@content-desc='Navigate up']")
    @CacheLookup
    public WebElement navigateBack;
    public void clickOnNavigateBack(){
        navigateBack.click();
    }


    @FindBy(xpath = "//android.widget.TextView[@text='Other contact numbers']")
    public WebElement otherContactNumbersTab;
    public String validateOtherContactNumbersTab(){
        String msg=otherContactNumbersTab.getText();
        return msg;
    }


    @FindBy(xpath = "//android.widget.TextView[@text='Store Locator']")
    public WebElement storeLocatorTab;
    public void clickOnStoreLocatorTab(){
        storeLocatorTab.click();
    }


    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.android.packageinstaller:id/permission_allow_button']")
    public WebElement allowBtn;
    public void clickOnAllowBtn(){
        allowBtn.click();
    }

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_Licenceplatenumber']")
    public WebElement plateNumberTxt;


    @FindBy(xpath = "//android.widget.EditText[@text='Enter parking zone']")
    public WebElement parkingZoneTxt;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/label_mparking_itemnumber']")
    public WebElement parkingDuration;


    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_mparking_requestticket']")
    public WebElement requestParkingTicket;


    @FindBy(xpath = "//android.widget.TextView[@resource-id='android:id/sms_short_code_confirm_message']")
    public WebElement confirmaMessage;


    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_billlimit_total']")
    public WebElement selectedBillLimitAmount;

    @FindBy(xpath = "//android.widget.Button[@resource-id='android:id/button1']")
    public WebElement sendBtn1;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/btn_set_new_password' or @resource-id='com.Etisalat.ETIDA:id/btn_bill_limit_submit']")//com.Etisalat.ETIDA:id/btn_bill_limit_submit
    public WebElement submitBtn;


    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/btn_pay_bill']")
    public WebElement payTotalAmountBtn;
    public void clickOnPayTotalAmountBtn(){
        payTotalAmountBtn.click();
    }

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/tv_price']")
    public WebElement totalDueAmountTxt;

    public void enterTotalDueAmount(String amount){
        totalDueAmountTxt.clear();
        totalDueAmountTxt.sendKeys(amount);
    }

    @FindBy(xpath = "(//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/tv_price'])[position()=2]")
    public WebElement totalDueAmountTxt1;

    public void enterTotalDueAmount1(String amount){
        totalDueAmountTxt1.clear();
        totalDueAmountTxt1.sendKeys(amount);
    }


    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/btn_recahrgeSelect_next']")
    public WebElement rechargeNextBtn;
    public void clickOnRechargeNextBtn(){
        rechargeNextBtn.click();
    }

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/cancelButton']")
    public WebElement cancelBtn;
    public void clickOnCancelBtn(){
        cancelBtn.click();
    }


    @FindBy(xpath = "//android.widget.Button[@resource-id='com.Etisalat.ETIDA:id/btn_ma_show_accounts']")//com.Etisalat.ETIDA:id/btn_ma_show_accounts
    public WebElement hideShowBtn;
    public void clickOnHideShowBtn(){
        hideShowBtn.click();
    }


    @FindBy(xpath = "//android.widget.ToggleButton[@resource-id='com.Etisalat.ETIDA:id/tb_enable_account']")
    public WebElement hideToggleBtn;
    public void clickOnHideToggleBtn(){
        hideToggleBtn.click();
    }




    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/message']")
    public WebElement messagePopUpStoreLocator;
    public String validateMessagePopUpStoreLocator(){
        String mm = messagePopUpStoreLocator.getText();
        return mm;
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/message']")
    public WebElement messagePopup;

    @FindBy(xpath = "//android.widget.TextView[@text='My Location']")
    public WebElement myLocation;




    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/question_edit_text']")
    public WebElement questionTxt;
    public String validateAskQuestion(){
        String mm = questionTxt.getText();
        return mm;
    }

    @FindBy(xpath = "//android.widget.Button[@text='Send']")
    public WebElement sendBtn;
    public void clickOnSendBtn(){
        sendBtn.click();
    }

    @FindBy(xpath = "//android.view.View[@text='Etisalat: Welcome to Etisalat']")
    public WebElement welcomeToLiveChat;
    public String validateLiveChatScreen(){

        String msg=welcomeToLiveChat.getText();
        return msg;
    }

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_lct_mobile_no']")
    @CacheLookup
    public WebElement localMoblieNumberTxt;

    public void enterLocalMobileNumber(String mobileNum){
        localMoblieNumberTxt.sendKeys(mobileNum);
    }

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/intl_phone_edit__phone']")
    @CacheLookup
    public WebElement internationalMoblieNumberTxt;

    public void enterInternationalMobileNumber(String mobileNum){
        internationalMoblieNumberTxt.sendKeys(mobileNum);
    }

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_mobile_number']")
    @CacheLookup
    public WebElement recipientMobNumberTxt;

    public void enterRecipientPhoneNumber(String mobileNum){
        recipientMobNumberTxt.sendKeys(mobileNum);
    }



    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_lct_amount']")
    @CacheLookup
    public WebElement transferAmountTxt;

    public void enterTransferAmount(String amount){
        transferAmountTxt.sendKeys(amount);
    }

    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/et_dt_data_amount']")
    @CacheLookup
    public WebElement dataAmount;

    public void enterDataAmount(String amount){
        dataAmount.sendKeys(amount);
    }

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/txt_sc_option']")
    public WebElement securityScreen;


    @FindBy(xpath = "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/security_code_entry']")
    public WebElement securityTxt;

    @FindBy(xpath = "//android.widget.Button[@resource-id='com.Etisalat.ETIDA:id/btn_sc_next']")
    public WebElement proceedBtn;


    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_title']")
    public WebElement successTitle;

    public String getSecurityCode(){
        String security=securityScreen.getText().toString().trim();
        return  security;
    }

    @FindBy(xpath = "//android.widget.TextView[@text='10']")
    public WebElement aed10;
    public void clickOnAed10Tab(){
        aed10.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='50']")
    public WebElement aed50;
    public void clickOnAed50Tab(){
        aed50.click();
    }


    @FindBy(xpath = "//android.widget.TextView[@text='50 INR']")
    public WebElement inr50;
    public void clickOnINR50Tab(){
        inr50.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='100']")
    public WebElement mb100Data;
    public void clickOn100MbData(){
        mb100Data.click();
    }

    @FindBy(xpath = "//android.widget.EditText[@text='054 393 5704']")
    public WebElement myAccountNo1;
    public boolean validateHideDisableAccount(){
        if(myAccountNo1.isDisplayed()){
            return true;
        }else{
            return  false;
        }

    }

    @FindBy(xpath= "//android.widget.Button[@resource-id='com.Etisalat.ETIDA:id/bt_subscribe']")
    @CacheLookup
    public WebElement continueBtn;

    public void clickOnContinueBtn(){
        continueBtn.click();
    }

    @FindBy(xpath= "//android.widget.Button[@text='Change']")
    @CacheLookup
    public WebElement changeBtn;

    public void clickOnChangeBtn(){
        changeBtn.click();
    }


    @FindBy(xpath= "//android.widget.Button[@resource-id='com.Etisalat.ETIDA:id/okButton']")
    @CacheLookup
    public WebElement okBtn;

    public void clickOnOkBtn(){
        okBtn.click();
    }


    @FindBy(xpath= "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_ivr_detail']")
    @CacheLookup
    public WebElement pinChangedSuccessfully;

    public String getPinChangeSuccessfullyMsg(){
        String mm =pinChangedSuccessfully.getText();
        return  mm;
    }

    @FindBy(xpath= "//android.widget.Button[@resource-id='com.Etisalat.ETIDA:id/btn_ok']")
    @CacheLookup
    public WebElement btnOk_btn;

    public void clickOnBtnOk(){
        btnOk_btn.click();
    }


    @FindBy(xpath= "//android.widget.EditText[@resource-id='com.Etisalat.ETIDA:id/tv_ma_number']")
    @CacheLookup
    public WebElement accNum;

    @FindBy(xpath = "(//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_mp_name'])[position()=1]")
    public WebElement myPlan1;

    @FindBy(xpath = "(//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_mp_name'])[position()=2]")
    public WebElement myPlanAddOn1;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_total_amount']")
    public WebElement deductedBalanceAmount;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/tv_current_balance']")
    public WebElement currentBalance;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/btn_recahrge_next'  or @resource-id='com.Etisalat.ETIDA:id/btn_recharge_next']")//com.Etisalat.ETIDA:id/btn_recahrge_next
    public WebElement next12;










}
