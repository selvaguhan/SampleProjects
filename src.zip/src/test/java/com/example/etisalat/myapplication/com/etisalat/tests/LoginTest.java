package com.example.etisalat.myapplication.com.etisalat.tests;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.LoginPage;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;

public class LoginTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    LoginPage loginPage;


    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void loginTest(){
        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        loginPage = PageFactory.initElements(driver,LoginPage.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(loginPage.myAccountsTab);

        //driver.scrollToExact("My Accounts");

        driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("
                                + "new UiSelector().textContains(\"My Accounts\"));"));


        waitForElement(loginPage.myAccountsTab);
        loginPage.myAccountsTab.click();

        //waitForElement(loginPage.addAccountsTab);

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        /*driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("
                + "new UiSelector().textContains(\"Add Accounts\"));"));*/

        /*driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()."
                +"scrollable(true)).scrollIntoView(new UiSelector().resourceId(\"com.Etisalat.ETIDA:id/tv_ma_name\"))"));*/

        driver.scrollTo("Add Accounts");

        waitForElement(loginPage.addAccountsTab);
        loginPage.addAccountsTab.click();

        loginPage.login("sit_qa","123456");
        driver.scrollTo("LOGIN");
        loginPage.loginBtn.click();

    }

}
