package com.example.etisalat.myapplication.com.etisalat.myetisalat.myaccounts;

import com.example.etisalat.myapplication.com.etisalat.baseutils.AppInstallAndUninstallTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class TC_028MyInfoTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;


    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_028MyInfoTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);



        waitForElement(homePage.profileCoverId);
        homePage.profileCoverId.click();

        String profileName = navigationScreen.profileUsrName.getText();
        System.out.println("the profile name is::===>"+profileName);

        waitForElement(navigationScreen.myInfoLnk);
        navigationScreen.clickOnMyInfoLnk();

        waitForElement(myEtisalatAppPages.nickNameTxt);
        myEtisalatAppPages.enterNickName("Dest Usr");

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        driver.scrollToExact("Billing address details");

        waitForElement(myEtisalatAppPages.addressTxt1);
        myEtisalatAppPages.enterAddress1("add sdd");


        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        waitForElement(myEtisalatAppPages.saveBtn);
        myEtisalatAppPages.clickOnSaveBtn();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }
        //waitForElement(myEtisalatAppPages.messagePopUpStoreLocator);
 /*       String success = myEtisalatAppPages.validateMessagePopUpStoreLocator();

        Assert.assertTrue(success.equalsIgnoreCase("SUCCESS"));*/

       // myEtisalatAppPages.okBtn.click();


        waitForElement(myEtisalatAppPages.updatedUserName);
        String usrNme = myEtisalatAppPages.getUpdatedUsrName();
        System.out.println("the retrived updated profile name::"+usrNme);
        Assert.assertEquals("the text is not matching","Dest Usr",usrNme);
    }

    @After
    public void tearDwon(){
        driver.quit();
    }
}
