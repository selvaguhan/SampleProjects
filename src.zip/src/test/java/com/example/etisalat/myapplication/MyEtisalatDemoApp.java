package com.example.etisalat.myapplication;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class MyEtisalatDemoApp extends BaseTest{

    AppiumDriver driver;
    Dimension size;

    @Before
    public void setUp() throws MalformedURLException {
        // Created object of DesiredCapabilities class.

        // Created object of DesiredCapabilities class.
        DesiredCapabilities capabilities = new DesiredCapabilities();

        // Set android deviceName desired capability. Set it Android Emulator.
        capabilities.setCapability("deviceName", "68466b20");

        // Set browserName desired capability. It's Android in our case here.
        capabilities.setCapability("browserName", "Android");

        // Set android platformVersion desired capability. Set your emulator's android version.
        capabilities.setCapability("platformVersion", "P");

        // Set android platformName desired capability. It's Android in our case here.
        capabilities.setCapability("platformName", "Android");

        // Set android appPackage desired capability. It is com.android.calculator2 for calculator application.
        // Set your application's appPackage if you are using any other app.
        capabilities.setCapability("appPackage", "com.Etisalat.ETIDA");
        //package:/system/app/ExactCalculator/ExactCalculator.apk=com.android.calculator2
        // Set android appActivity desired capability. It is com.android.calculator2.Calculator for calculator application.
        // Set your application's appPackage if you are using any other app.
        //com.Etisalat.ETIDA.home.activities.MainActivity
        capabilities.setCapability("appActivity", "com.Etisalat.ETIDA.home.activities.SplashActivity");

        // Created object of RemoteWebDriver will all set capabilities.
        // Set appium server address and port number in URL string.
        // It will launch calculator app in android device.
        //driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);


    }

    @Test
    public void testFirstCalculator() {

       /* WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.elementToBeClickable(By.id("com.Etisalat.ETIDA:id/menu_toggle")));*/
        waitForElement(driver,By.id("com.Etisalat.ETIDA:id/menu_toggle"));

       driver.findElement(By.id("com.Etisalat.ETIDA:id/menu_toggle")).click();
        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }

        driver.findElement(By.xpath("//android.widget.TextView[@text='Bills and Payments']")).click();

        try {
            Thread.sleep(3000);
        } catch (Exception e) {

        }

        driver.findElement(By.xpath("//android.widget.TextView[@text='View Bills']")).click();

        try {
            Thread.sleep(3000);
        } catch (Exception e) {

        }

        driver.findElement(By.id("com.Etisalat.ETIDA:id/cb_postpaid")).click();
        try {
            Thread.sleep(3000);
        } catch (Exception e) {

        }


        driver.findElement(By.xpath("//android.widget.TextView[@text='Pay selected']")).click();

        try {
            Thread.sleep(3000);
        } catch (Exception e) {

        }



        driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_price")).clear();
        driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_price")).sendKeys("10.00");

        try {
            Thread.sleep(3000);
        } catch (Exception e) {

        }



        driver.findElement(By.id("com.Etisalat.ETIDA:id/btn_recahrgeSelect_next")).click();
        try {
            Thread.sleep(3000);
        } catch (Exception e) {

        }

        driver.findElement(By.id("com.Etisalat.ETIDA:id/cb_lct_last_used_checkbox")).click();
        try {
            Thread.sleep(3000);
        } catch (Exception e) {

        }


        driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_next")).click();
        try {
            Thread.sleep(3000);
        } catch (Exception e) {

        }

        driver.findElement(By.id("com.Etisalat.ETIDA:id/okButton")).click();
        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }

        //driver.findElement(By.xpath("//android.widget.EditText[@resource-id='ValidationCode']")).click();
        driver.findElement(By.xpath("//android.widget.EditText[@resource-id='ValidationCode']")).sendKeys("123");
        try {
            Thread.sleep(3000);
        } catch (Exception e) {

        }

        driver.findElement(By.xpath("//android.widget.Button[@content-desc = 'Pay']")).click();
        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }

        String payMentText =driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_payment_heading")).getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);

        Assert.assertEquals(payMentText,"PAYMENT SUCCESSFUL");

        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }


    }

    public void horizontalScroll()
    {
        size=driver.manage().window().getSize();
        int x_start=(int)(size.width*0.60);
        int x_end=(int)(size.width*0.30);
        int y=130;
        driver.swipe(x_start,y,x_end,y,4000);
    }

    //@After
    public void end() {
        driver.quit();
    }
}
