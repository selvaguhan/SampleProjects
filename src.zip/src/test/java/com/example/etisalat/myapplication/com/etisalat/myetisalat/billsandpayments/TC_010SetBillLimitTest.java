package com.example.etisalat.myapplication.com.etisalat.myetisalat.billsandpayments;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;

public class TC_010SetBillLimitTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_010SetBillLimitTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.billsAndPaymentsTab);
        navigationScreen.clickOnBillsAndPaymentsTab();

        waitForElement(navigationScreen.setBillLimitTab);
        navigationScreen.setBillLimitTab.click();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        waitForElement(myEtisalatAppPages.billLimitDropDown);
        myEtisalatAppPages.billLimitDropDown.click();

        waitForElement(myEtisalatAppPages.selectBillLimitAmount);
        myEtisalatAppPages.selectBillLimitAmount.click();


        waitForElement(myEtisalatAppPages.selectedBillLimitAmount);
        String selectedBillLimit=myEtisalatAppPages.selectedBillLimitAmount.getText().trim().toString();

        System.out.println("the selected bill limit amount is:::===>"+selectedBillLimit);
        Assert.assertEquals(selectedBillLimit,"200 AED");

        waitForElement(myEtisalatAppPages.submitBtn);
        myEtisalatAppPages.submitBtn.click();

        waitForElement(myEtisalatAppPages.messagePopup);
        String usageMessageBillLimit=myEtisalatAppPages.messagePopup.getText().trim().toString();

        System.out.println("the captured message from the popup:::===>"+usageMessageBillLimit);
        Assert.assertEquals(usageMessageBillLimit,"Your usage will be capped to 200 AED every month and all your usage will be stopped once you reach that limit");

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        myEtisalatAppPages.clickOnOkBtn();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.billsAndPaymentsTab);
        navigationScreen.clickOnBillsAndPaymentsTab();

        waitForElement(navigationScreen.setBillLimitTab);
        navigationScreen.setBillLimitTab.click();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        waitForElement(myEtisalatAppPages.billLimitDropDown);
        String billLimit=myEtisalatAppPages.billLimitDropDown.getText();
        System.out.print("Retieved latest Bill limit from the Screen:: "+billLimit);
        Assert.assertEquals(billLimit,"200 AED");
    }

    @After
    public void end() {
        driver.quit();
    }
}
