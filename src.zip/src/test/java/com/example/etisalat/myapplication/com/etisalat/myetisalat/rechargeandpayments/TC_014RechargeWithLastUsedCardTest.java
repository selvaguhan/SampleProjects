package com.example.etisalat.myapplication.com.etisalat.myetisalat.rechargeandpayments;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.SoapApiUtils;
import com.example.etisalat.myapplication.com.etisalat.baseutils.XMLParser;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;

import javax.xml.soap.SOAPMessage;

public class TC_014RechargeWithLastUsedCardTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    SoapApiUtils ss;
    XMLParser xmlParser;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void tc_014RechargeWithLastUsedCardTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        ss = new SoapApiUtils();
        xmlParser=new XMLParser();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();
        String accountBalPreRecharge=null,accountBalPostRecharge=null;
        try{
            SOAPMessage soapRequest=ss.createSOAPRequest("C:\\Users\\jekumar\\Desktop\\wsdl\\IN\\test12.xml");
            SOAPMessage response=ss.getSOAPResponse(soapRequest,"http://tibcononprd.etisalat.corp.ae:9061/GetINAccountDetails");
            accountBalPreRecharge=xmlParser.getTagValue(response,"ns0:AccountBalance");
            System.out.println("the account balance is ::"+accountBalPreRecharge);
        }catch (Exception e){

        }

        waitForElement(navigationScreen.rechargeAndPayTab);
        navigationScreen.clickOnRechargeAndPayTab();

        waitForElement(navigationScreen.rechargeTab);
        navigationScreen.clickOnRechargeTab();

        waitForElement(navigationScreen.rechargeAmountTxt);
        navigationScreen.enterPrepaidRechargeAmount("10");

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.lastUsedCheckBox);
        homePage.clickOnlastUsedCheckBox();

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();

        waitForElement(homePage.cvvTxt);
        homePage.enterCVVNo("123");

        waitForElement(homePage.payBtn);
        homePage.clickOnPayBtn();

        waitForElement(homePage.paymentHeadingTitle);
        String payMentText =homePage.paymentHeadingTitle.getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"Recharge successful");

        //vadating against to the IN Web Application
        try{
            SOAPMessage soapRequest=ss.createSOAPRequest("C:\\Users\\jekumar\\Desktop\\wsdl\\IN\\test12.xml");
            SOAPMessage response=ss.getSOAPResponse(soapRequest,"http://tibcononprd.etisalat.corp.ae:9061/GetINAccountDetails");
            accountBalPostRecharge=xmlParser.getTagValue(response,"ns0:AccountBalance");
            System.out.println("the account balance is ::"+accountBalPostRecharge);
        }catch (Exception e){

        }

        Double finalAddedBalance = Double.parseDouble(accountBalPreRecharge)+10;

        Assert.assertEquals(Double.toString(finalAddedBalance),accountBalPostRecharge);

    }
    @After
    public void end() {
        driver.quit();
    }
}
