package com.example.etisalat.myapplication.com.etisalat.myetisalat.billsandpayments;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;
import java.util.ArrayList;

public class TC_010PayBillsToMulipleAccountsTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_010PayBillsToMulipleAccountsTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.billsAndPaymentsTab);
        navigationScreen.clickOnBillsAndPaymentsTab();

        waitForElement(navigationScreen.payMyBillsTab);
        navigationScreen.payMyBillsTab.click();

        waitForElement(homePage.postPaidRadioBtn);
        homePage.postPaidRadioBtn.click();

        homePage.postPaidRadioBtn1.click();


        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        waitForElement(homePage.paySelectedBtn);
        homePage.clickOnPaySelectedBtn();

        waitForElement(myEtisalatAppPages.totalDueAmountTxt);
        myEtisalatAppPages.enterTotalDueAmount("10");

        waitForElement(myEtisalatAppPages.totalDueAmountTxt1);
        myEtisalatAppPages.enterTotalDueAmount1("10");

        waitForElement(myEtisalatAppPages.rechargeNextBtn);
        myEtisalatAppPages.clickOnRechargeNextBtn();

        waitForElement(homePage.lastUsedCheckBox);
        homePage.clickOnlastUsedCheckBox();

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();

        waitForElement(homePage.cvvTxt);
        homePage.enterCVVNo("123");

        waitForElement(homePage.payBtn);
        homePage.clickOnPayBtn();

        waitForElement(homePage.paymentHeadingTitle);
        String payMentText =homePage.paymentHeadingTitle.getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"PAYMENT SUCCESSFUL");
    }

    @After
   public void end() {
        driver.quit();
    }
}
