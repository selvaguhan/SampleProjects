package com.example.etisalat.myapplication.com.etisalat.tests;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;

public class PrepaidRechargeWithSmilesPointsTest extends BaseTest {

    HomePage homePage;
    NavigationScreen navigationScreen;



    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void prepaidRechargeWithSmilesPointsTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.rechargeAndPayTab);
        navigationScreen.clickOnRechargeAndPayTab();

        waitForElement(navigationScreen.rechargeTab);
        navigationScreen.clickOnRechargeTab();

        waitForElement(navigationScreen.rechargeAmountTxt);
        navigationScreen.enterPrepaidRechargeAmount("10");

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.payWithSmilesPointsCheckBox);
        homePage.clickOnPayWithSmilesPointsCheckBox();

        waitForElement(homePage.nextBtn1);
        homePage.clickOnNextBtn1();

        waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();


        waitForElement(homePage.payBtn);
        homePage.clickOnPayBtn();

        waitForElement(homePage.paymentHeadingTitle);
        String payMentText =homePage.paymentHeadingTitle.getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"Recharge successful");

    }
    //@After
    public void end() {
        driver.quit();
    }
}
