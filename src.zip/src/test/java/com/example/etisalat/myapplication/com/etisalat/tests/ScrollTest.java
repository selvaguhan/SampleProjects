package com.example.etisalat.myapplication.com.etisalat.tests;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;

public class ScrollTest extends BaseTest{

    HomePage homePage;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void testScroll()throws Exception
    {

        Actions builder = new Actions(driver);

        homePage = PageFactory.initElements(driver,HomePage.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();


        //builder.moveToElement(homePage.helpAndSupportTab).click().build().perform();

        //scrollTo("Help & Support");
    AndroidElement list = (AndroidElement) driver.findElement(By.id("com.Etisalat.ETIDA:id/text"));

        MobileElement listGroup = list
                .findElement(MobileBy
                        .AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("
                                + "new UiSelector().textContains(\"Help & Support\"));"));

       //AndroidElement list1 = (AndroidElement) driver.findElement(By.xpath("//android.widget.TextView[@text='Help & Support']"));
        //listGroup.click();

    }
}
