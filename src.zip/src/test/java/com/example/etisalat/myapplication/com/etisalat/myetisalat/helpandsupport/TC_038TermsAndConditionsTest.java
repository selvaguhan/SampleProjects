package com.example.etisalat.myapplication.com.etisalat.myetisalat.helpandsupport;

import com.example.etisalat.myapplication.com.etisalat.baseutils.AppInstallAndUninstallTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class TC_038TermsAndConditionsTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    AppInstallAndUninstallTest mmm;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void tc_038TermsAndConditionsTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        mmm = new AppInstallAndUninstallTest();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        driver.swipe(500,1500,30,0,2000);


        //waitForElement(navigationScreen.helpAndSupportTab);
        navigationScreen.clickOnHelpAndSupportTab();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        driver.scrollTo("Terms & Conditions");
        waitForElement(myEtisalatAppPages.termsAndConditionsTab);
        myEtisalatAppPages.clickOnTermsAndConditionsTab();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        waitForElement(myEtisalatAppPages.termsAndConditionList);
        String termsAndConditions = myEtisalatAppPages.validateTermsAndConditions();
        System.out.println("the retrieved  roaming email id  from the application::"+termsAndConditions);
        Assert.assertEquals("text is not matching","Terms & Conditions",termsAndConditions);

    }

    @After
    public void tearDwon(){
        driver.quit();
    }
}
