package com.example.etisalat.myapplication.com.etisalat.myetisalat.etisalatshop;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.DBUtils;
import com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs.AutoConfigs;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;
import java.sql.ResultSet;

public class TC_025PurchaseWithPointsGSTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    DBUtils dbUtils;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_025PurchaseWithPointsGSTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages = PageFactory.initElements(driver,MyEtisalatAppPages.class);
        dbUtils = new DBUtils();

        ResultSet rs = dbUtils.fetchDataFromDataBase(AutoConfigs.database,AutoConfigs.dbUATENV, AutoConfigs.get_smilePoints_ACCOUNTS("0543932051"));
        String totalAvailableSmilesPoints = dbUtils.iterateResultSet(rs,"availablepoints");
        System.out.print("before dutction smiles points:: "+totalAvailableSmilesPoints);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.etisalatShopTab);
        navigationScreen.etisalatShopTab.click();

   /*     waitForElement(navigationScreen.dataTab);
        navigationScreen.dataTab.click();

        waitForElement(myEtisalatAppPages.featuredTab);
        myEtisalatAppPages.featuredTab.click();*/

        waitForElement(navigationScreen.searchBtn);
        navigationScreen.searchBtn.click();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        navigationScreen.searchTxt.sendKeys("international minutes add-on");

        try{
            Thread.sleep(1000);
        }catch (Exception e){

        }

        clickOnSearchBtn();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }


        driver.scrollToExact("International Minutes Add-on");
        waitForElement(myEtisalatAppPages.internationalMinAddOn);
        myEtisalatAppPages.internationalMinAddOn.click();

        driver.scrollToExact("Pay with Smiles points");
        String tt = myEtisalatAppPages.smilesPointChk.getAttribute("checked");
        if(tt.equalsIgnoreCase("true")){

        }else {
            myEtisalatAppPages.smilesPointChk.click();

        }

        waitForElement(myEtisalatAppPages.buyBtn);
        myEtisalatAppPages.buyBtn.click();

        waitForElement(myEtisalatAppPages.logOutOkBtn);
        myEtisalatAppPages.logOutOkBtn.click();

/*        waitForElement(homePage.messagePopup);
        String successMsg = homePage.messagePopup.getText();

        Assert.assertEquals("Request received successfully , You will receive a confirmation SMS.",successMsg);*/

        try{
            Thread.sleep(60000);
        }catch (Exception e){

        }


        ResultSet rs1 = dbUtils.fetchDataFromDataBase(AutoConfigs.database,AutoConfigs.dbUATENV, AutoConfigs.get_smilePoints_ACCOUNTS("0543932051"));
        String afterTotalAvailableSmilesPoints = dbUtils.iterateResultSet(rs1,"availablepoints");

        System.out.print("actual  is ::"+afterTotalAvailableSmilesPoints);

        int totalPoints = Integer.parseInt(totalAvailableSmilesPoints)-5000;
        System.out.print(" expected  is ::"+totalPoints);

        Assert.assertEquals(Integer.toString(totalPoints),afterTotalAvailableSmilesPoints);
    }

    @After
    public void end() {
        driver.quit();
    }
}
