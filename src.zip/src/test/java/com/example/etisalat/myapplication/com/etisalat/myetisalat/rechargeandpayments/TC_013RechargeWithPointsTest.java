package com.example.etisalat.myapplication.com.etisalat.myetisalat.rechargeandpayments;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.DBUtils;
import com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs.AutoConfigs;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;
import java.sql.ResultSet;

public class TC_013RechargeWithPointsTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    DBUtils dbUtils;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_013RechargeWithPointsTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        dbUtils = new DBUtils();

        ResultSet rs = dbUtils.fetchDataFromDataBase("Loyalty", AutoConfigs.dbUATENV, AutoConfigs.get_smilePoints_ACCOUNTS("0543931916"));
        String availablePreSmilesPoints = dbUtils.iterateResultSet(rs, "availablepoints");
        System.out.println("before the smiles points ::" + availablePreSmilesPoints);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.rechargeAndPayTab);
        navigationScreen.clickOnRechargeAndPayTab();

        waitForElement(navigationScreen.rechargeTab);
        navigationScreen.clickOnRechargeTab();

        waitForElement(navigationScreen.rechargeAmountTxt);
        navigationScreen.enterPrepaidRechargeAmount("10");

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.payWithSmilesPointsCheckBox);
        homePage.clickOnPayWithSmilesPointsCheckBox();

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.nextBtn1);
        homePage.clickOnNextBtn1();


        waitForElement(homePage.okBtn);
        homePage.okBtn.click();

        waitForElement(homePage.paymentHeadingTitle);
        String payMentText =homePage.paymentHeadingTitle.getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"Recharge successful");

        try{
            Thread.sleep(10000);
        }catch (Exception e){

        }

       ResultSet rs1 = dbUtils.fetchDataFromDataBase("Loyalty",AutoConfigs.dbUATENV, AutoConfigs.get_smilePoints_ACCOUNTS("0543931916"));
        String availablePostSmilesPoints = dbUtils.iterateResultSet(rs1, "availablepoints");
        System.out.println("after smiles points ::" + availablePostSmilesPoints);

        int finalPoints = Integer.parseInt(availablePreSmilesPoints)-1000;

        Assert.assertEquals(Integer.toString(finalPoints),availablePostSmilesPoints,"the points are matching");

    }
   // @After
    public void end() {
        driver.quit();
    }
}
