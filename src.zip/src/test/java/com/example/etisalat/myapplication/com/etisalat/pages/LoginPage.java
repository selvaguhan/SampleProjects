package com.example.etisalat.myapplication.com.etisalat.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class LoginPage {

   /* WebDriver driver;
    public LoginPage(WebDriver driver){
        this.driver= driver;
    }*/

    @FindBy(xpath = "//android.widget.TextView[@text='My Accounts']")
    public WebElement myAccountsTab;

    @FindBy(xpath = "//android.widget.TextView[@text='Add Accounts']")
    public WebElement addAccountsTab;

    @FindBy(id = "com.Etisalat.ETIDA:id/et_usename")
    @CacheLookup
    public WebElement userNameTxt;

    @FindBy(id = "com.Etisalat.ETIDA:id/btn_logout")
    @CacheLookup
    public WebElement logoutBtn;

    public void logOut(){
        logoutBtn.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/tv_logout_ok")
    @CacheLookup
    public WebElement logoutOkBtn;

    public void logOutOkBtn(){
        logoutOkBtn.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/et_password")
    @CacheLookup
    public WebElement passWordTxt;

    @FindBy(id = "com.Etisalat.ETIDA:id/tv_login")
    @CacheLookup
    public WebElement loginBtn;

    @FindBy(id = "com.Etisalat.ETIDA:id/tv_notow")
    @CacheLookup
    public WebElement notNowBtn;



    public void login(String usrName,String passWord){
        userNameTxt.sendKeys(usrName);
        passWordTxt.sendKeys(passWord);
        //driver.hidek
        // loginBtn.click();
    }

}
