package com.example.etisalat.myapplication.com.etisalat.myetisalat.billsandpayments;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;

public class TC_007ViewBillsTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void tc_007ViewBillsTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.billsAndPaymentsTab);
        navigationScreen.clickOnBillsAndPaymentsTab();

        waitForElement(navigationScreen.viewBillsTab);
        navigationScreen.clickOnViewBillsTab();

       /* waitForElement(myEtisalatAppPages.payTotalAmountBtn);
        myEtisalatAppPages.clickOnPayTotalAmountBtn();

        waitForElement(myEtisalatAppPages.totalDueAmountTxt);
        myEtisalatAppPages.enterTotalDueAmount("10");

        waitForElement(myEtisalatAppPages.rechargeNextBtn);
        myEtisalatAppPages.clickOnRechargeNextBtn();

        waitForElement(homePage.payWithNewCardChk1);
        homePage.clickOnPayWithNewCardChk1();

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();

        waitForElement(homePage.cardNumberTxt);
        homePage.enterCardNumber("5555555555554444");

        waitForElement(homePage.viewDropDownExpiryYear);
        homePage.clickOnViewExpiryYearDropDown();

        waitForElement(homePage.expiryYear);
        homePage.clickOnExpiryYear();

        waitForElement(homePage.cvvTxt);
        homePage.enterCVVNo("123");

        waitForElement(homePage.payBtn);
        homePage.clickOnPayBtn();

        waitForElement(homePage.paymentHeadingTitle);
        String payMentText =homePage.paymentHeadingTitle.getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"PAYMENT SUCCESSFUL");*/

    }

    @After
    public void end() {
        driver.quit();
    }
}
