package com.example.etisalat.myapplication.com.etisalat.tests;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import java.net.MalformedURLException;

public class PrepaidRechargeWithNewCardTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void prepaidRechargeWithNewCardTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.rechargeAndPayTab);
        navigationScreen.clickOnRechargeAndPayTab();

        waitForElement(navigationScreen.rechargeTab);
        navigationScreen.clickOnRechargeTab();

        waitForElement(navigationScreen.rechargeAmountTxt);
        navigationScreen.enterPrepaidRechargeAmount("10");

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.payWithNewCardCheckBox);
        homePage.clickOnPayWithNewCardCheckBox();

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();

        waitForElement(homePage.cardNumberTxt);
        homePage.enterCardNumber("5555555555554444");

        waitForElement(homePage.viewDropDownExpiryYear);
        homePage.clickOnViewExpiryYearDropDown();

        waitForElement(homePage.expiryYear);
        homePage.clickOnExpiryYear();

        /*waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();*/

        waitForElement(homePage.cvvTxt);
        homePage.enterCVVNo("123");

        waitForElement(homePage.payBtn);
        homePage.clickOnPayBtn();

        waitForElement(homePage.paymentHeadingTitle);
        String payMentText =homePage.paymentHeadingTitle.getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"Recharge successful");

    }
    //@After
    public void end() {
        driver.quit();
    }
}
