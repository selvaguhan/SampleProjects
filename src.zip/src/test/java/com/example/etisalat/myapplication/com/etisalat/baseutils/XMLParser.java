package com.example.etisalat.myapplication.com.etisalat.baseutils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import java.io.IOException;
import java.io.StringReader;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

public class XMLParser {

    public Document getDocument(SOAPMessage soapMsg) throws SAXException, IOException, ParserConfigurationException {

        // Get all elements with the requested element tag from the SOAP message
        SOAPBody soapBody = null;
        try {
            soapBody = soapMsg.getSOAPBody();
        } catch (SOAPException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        NodeList elements = soapBody.getElementsByTagName("out");

        String values=elements.item(0).getTextContent().trim();

        final String xmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n"+
                "<ns0:AccountDetailsResponse>"+values+"</ns0:AccountDetailsResponse>";



        Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .parse(new InputSource(new StringReader(xmlStr)));



        return doc;


    }

    public void parseXmlString(String xmlStr){

        try{
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = db.parse(new InputSource(new StringReader(xmlStr)));
            System.out.println("gthe first node::"+doc.getFirstChild().getNodeName());

            NodeList testPlanNodeList = doc.getElementsByTagName("ns2:testplan");

            String tt = doc.getFirstChild().getNextSibling().getNodeName();
            System.out.println("gthe first node's all  next sibling::"+tt);
           /* for(int i=0;i<lst.getLength();i++){

                if(lst.item(i).getNodeName().equalsIgnoreCase("ns0:AccountBalance")){
                    System.out.println("the value of the node is::"+lst.item(i).getNodeValue());
                }
            }*/
        }catch (Exception e){

        }

    }

    public  String getTagValue(SOAPMessage soapMsg,String tageName) throws SAXException, IOException, ParserConfigurationException  {
        // Get all elements with the requested element tag from the SOAP message
        SOAPBody soapBody = null;
        try {
            soapBody = soapMsg.getSOAPBody();
        } catch (SOAPException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        NodeList elements = soapBody.getElementsByTagName(tageName);
        String values=elements.item(0).getTextContent().trim();
        return values;
    }
}


