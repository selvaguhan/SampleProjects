package com.example.etisalat.myapplication.com.etisalat.tests;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.SwypPages;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

public class DemoSwypTest extends BaseTest {

    SwypPages swypPages;

    @Before
    public  void setUp(){
        launchSwypApplication();
    }

    @Test
    public void test(){

        swypPages = PageFactory.initElements(driver,SwypPages.class);

        /*waitForElement(swypPages.skipBtn);
        swypPages.skipBtn.click();

        waitForElement(swypPages.agreeBtn);
        swypPages.agreeBtn.click();*/

        waitForElement(swypPages.loginBtn);
        swypPages.loginBtn.click();

        waitForElement(swypPages.usrNmeTxt);
        swypPages.usrNmeTxt.clear();
        swypPages.usrNmeTxt.sendKeys("0543931970");

        waitForElement(swypPages.passwordTxt);
        swypPages.passwordTxt.clear();
        swypPages.passwordTxt.sendKeys("Test@123");
        swypPages.loginBtn.click();

        //com.indy:id/createAccoutBtn

    }
}
