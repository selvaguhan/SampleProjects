package com.example.etisalat.myapplication.com.etisalat.baseutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.StringWriter;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class SoapApiUtils {

    public SOAPMessage createSOAPRequest(String strPath) throws Exception {

        // Create a SOAP message from the XML file located at the given path
        FileInputStream fis = new FileInputStream(new File(strPath));
        MessageFactory factory = MessageFactory.newInstance();
        MimeHeaders mh = new MimeHeaders();
        mh.setHeader("Content-Type", "text/xml;charset=UTF-8");
        mh.setHeader("soapaction", "/WSDL/GetINAccountDetails/GetINAccountDetails_1_Abstract-service6.serviceagent/PortTypeEndpoint6/Operation");
        SOAPMessage message = factory.createMessage(mh, fis);
        System.out.println("Soap Request File is ");
        printSoapMessage(message);

        return message;
    }


    public SOAPMessage getSOAPResponse(SOAPMessage soapRequest, String strEndpoint)   {

        // Send the SOAP request to the given endpoint and return the corresponding response
        SOAPConnectionFactory soapConnectionFactory = null;
        try {
            soapConnectionFactory = SOAPConnectionFactory.newInstance();
        } catch (UnsupportedOperationException | SOAPException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        SOAPConnection soapConnection = null;
        try {
            soapConnection = soapConnectionFactory.createConnection();
        } catch (SOAPException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        SOAPMessage soapResponse = null;
        try {
            soapResponse = soapConnection.call(soapRequest, strEndpoint);
        } catch (SOAPException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println("Response file is ");
        //printSoapMessage(soapResponse);
        return soapResponse;
    }

    public String  printSoapMessage(SOAPMessage message)
    {
        final StringWriter sw = new StringWriter();

        try {
            TransformerFactory.newInstance().newTransformer().transform(
                    new DOMSource(message.getSOAPPart()),
                    new StreamResult(sw));
        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }

        System.out.println(sw.toString());
        System.out.println(sw);
        return sw.toString();
    }
}
