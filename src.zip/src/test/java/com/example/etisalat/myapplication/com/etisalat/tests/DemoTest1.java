package com.example.etisalat.myapplication.com.etisalat.tests;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import java.net.MalformedURLException;

public class DemoTest1 extends BaseTest {

    HomePage homePage;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void testFirstCalculator() {

        homePage = PageFactory.initElements(driver,HomePage.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(homePage.billsAndPayments);
        homePage.clickOnBillsAndPaymentTab();

        waitForElement(homePage.viewAndPayBills);
        homePage.clickOnViewAndPayBills();

        waitForElement(homePage.postPaidRadioBtn);
        homePage.clickOnPostPaidRadioBtn();

        waitForElement(homePage.paySelectedBtn);
        homePage.clickOnPaySelectedBtn();

        waitForElement(homePage.priceTxt);
        homePage.ënterBillPaymentAmount("10.00");

        waitForElement(homePage.rechargeNextBtn);
        homePage.clickOnRechargeNextBtn();

        waitForElement(homePage.lastUsedCheckBox);
        homePage.clickOnlastUsedCheckBox();

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();

        waitForElement(homePage.cvvTxt);
        homePage.enterCVVNo("123");

        waitForElement(homePage.payBtn);
        homePage.clickOnPayBtn();

        waitForElement(homePage.paymentHeadingTitle);
        String payMentText =homePage.paymentHeadingTitle.getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"PAYMENT SUCCESSFUL");

    }
    //@After
    public void end() {
        driver.quit();
    }
}
