package com.example.etisalat.myapplication.com.etisalat.myetisalat.usage.tests;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

public class UsageDataTabTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;

    @Before
    public void setUp(){
        launchAndroidApplication();
    }

    @Test
    public void usageDataTabTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.usageTab);
        navigationScreen.clickOnUsageTab();

        waitForElement(myEtisalatAppPages.dataTab);
        myEtisalatAppPages.clickOnDataTab();

        waitForElement(myEtisalatAppPages.balanceDataUsage);
        String dataBalance = myEtisalatAppPages.getBalenceData();
        System.out.println("the retrived latest balance from the application::"+dataBalance);

        String addons = myEtisalatAppPages.getAddons();
        System.out.println("the retrived addons list from the application::"+addons);
        Assert.assertEquals("did not matching","My Plans & Add-Ons",addons);
    }
    @After
    public void teardown(){
        driver.quit();
    }
}
