package com.example.etisalat.myapplication.com.etisalat.myetisalat.etisalatshop;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.DBUtils;
import com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs.AutoConfigs;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.PageFactory;
import java.net.MalformedURLException;
import java.sql.ResultSet;
import java.util.ArrayList;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

//postpaid account
public class TC_024PurchaseWithAddToBillTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    DBUtils dbUtils;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_024PurchaseWithAddToBillTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages = PageFactory.initElements(driver,MyEtisalatAppPages.class);
        dbUtils = new DBUtils();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.etisalatShopTab);
        navigationScreen.etisalatShopTab.click();

/*
        waitForElement(navigationScreen.postPaidAddOnsTab);
        navigationScreen.postPaidAddOnsTab.click();*/

       /* driver.scrollToExact("DATA");
        waitForElement(navigationScreen.dataTab);
        navigationScreen.dataTab.click();

        waitForElement(myEtisalatAppPages.featuredTab);
        myEtisalatAppPages.featuredTab.click();


        driver.scrollToExact("INTERNATIONAL MINUTES ADD-ON");
        waitForElement(myEtisalatAppPages.internationalMinAddOn);
        myEtisalatAppPages.internationalMinAddOn.click();*/

        waitForElement(navigationScreen.searchBtn);
        navigationScreen.searchBtn.click();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        navigationScreen.searchTxt.sendKeys("3 GB monthly data plus package");

        try{
            Thread.sleep(1000);
        }catch (Exception e){

        }

        clickOnSearchBtn();

       /* TouchAction touch1 = new TouchAction(driver);
        touch1.tap (980 , 1854).perform();*/


        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        driver.scrollToExact("3 GB MONTHLY DATA PLUS PACKAGE");
        waitForElement(myEtisalatAppPages.dataPackage3gb);
        myEtisalatAppPages.dataPackage3gb.click();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        driver.scrollToExact("Add to my bill");
        String tt = myEtisalatAppPages.deductBalanceChk.getAttribute("checked");
        if(tt.equalsIgnoreCase("true")){

        }else {
            myEtisalatAppPages.deductBalanceChk.click();

        }

        waitForElement(myEtisalatAppPages.buyBtn);
        myEtisalatAppPages.buyBtn.click();

        waitForElement(myEtisalatAppPages.logOutOkBtn);
        myEtisalatAppPages.logOutOkBtn.click();

/*

        waitForElement(myEtisalatAppPages.costTitle);
        String costTitle= myEtisalatAppPages.costTitle.getText().trim().toString();
        Assert.assertEquals("Thank you",costTitle);*/

        try{
            Thread.sleep(60000);
        }catch (Exception e){

        }

        ArrayList<String> attributesList = AutoConfigs.getSRAttributesList();

        ResultSet rs = dbUtils.fetchDataFromCBCMDB(AutoConfigs.dbUATENV, "select subrequest_id,created_date from T_SOH_SUBREQUEST where account_number='0563986630' AND CREATED_DATE>SYSDATE-1 order by created_date desc");

        ArrayList<String> resultList = dbUtils.iterateFirstRowResultSetWithMultiColumAttribute(rs,attributesList);
        System.out.println("the whole result set ::"+resultList);

        String subRequestId=resultList.get(0);
        System.out.println("the sub request id ::"+subRequestId);

        System.out.println("service required date::"+resultList.get(1));
        getCurrentDate();
        Assert.assertTrue(resultList.get(1).contains(getCurrentDate()));

/*        ResultSet res1 = dbUtils.fetchDataFromCBCMDB(AutoConfigs.dbPDENV,AutoConfigs.get_transaction_t_pay_prepayment_dtl(subRequestId));

        String transactionId = dbUtils.iterateResultSet(res1,"transaction_id");
        System.out.println("the transaction id::"+transactionId);

        ResultSet res2 = dbUtils.fetchDataFromCBCMDB(AutoConfigs.dbPDENV,AutoConfigs.get_t_pay_payment_transaction(transactionId));

        String total_payment_amount_syst_curr = dbUtils.iterateResultSet(res2,"total_payment_amount_syst_curr");
        System.out.println("the total_payment_amount_syst_curr::"+total_payment_amount_syst_curr);
        org.testng.Assert.assertEquals(total_payment_amount_syst_curr,"30");*/

    }

  /*  @After
    public void end() {
        driver.quit();
    }*/
}
