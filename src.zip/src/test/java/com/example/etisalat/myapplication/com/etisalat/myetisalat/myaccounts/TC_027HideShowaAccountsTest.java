package com.example.etisalat.myapplication.com.etisalat.myetisalat.myaccounts;
import com.example.etisalat.myapplication.com.etisalat.baseutils.AppInstallAndUninstallTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import java.net.MalformedURLException;

public class TC_027HideShowaAccountsTest extends BaseTest {
    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_027HideShowaAccountsTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        driver.swipe(489,1566,0,0,3000);

       //driver.scrollToExact("My Accounts");
        waitForElement(navigationScreen.myAccountTab);
        navigationScreen.clickOnMyAccountTab();

        driver.scrollToExact("HIDE / SHOW ACCOUNTS");
        waitForElement(myEtisalatAppPages.hideShowBtn);
        myEtisalatAppPages.clickOnHideShowBtn();

        waitForElement(myEtisalatAppPages.hideToggleBtn);
        myEtisalatAppPages.clickOnHideToggleBtn();

        waitForElement(myEtisalatAppPages.navigateBack);
        myEtisalatAppPages.clickOnNavigateBack();

        String tt = myEtisalatAppPages.accNum.getText();

        Assert.assertTrue(!tt.contains("054 393 1916"));

        driver.scrollToExact("HIDE / SHOW ACCOUNTS");
        waitForElement(myEtisalatAppPages.hideShowBtn);
        myEtisalatAppPages.clickOnHideShowBtn();

        waitForElement(myEtisalatAppPages.hideToggleBtn);
        myEtisalatAppPages.clickOnHideToggleBtn();

        waitForElement(myEtisalatAppPages.navigateBack);
        myEtisalatAppPages.clickOnNavigateBack();

        String tt1 = myEtisalatAppPages.accNum.getText();

        Assert.assertTrue(tt1.contains("054 393 1916"));



    }
    @After
    public void tearDwon(){
        driver.quit();
    }
}
