package com.example.etisalat.myapplication.com.etisalat.myetisalat.billsandpayments;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;

public class TC_012MparkingTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_011TransactionHistoryTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.billsAndPaymentsTab);
        navigationScreen.clickOnBillsAndPaymentsTab();

        driver.scrollToExact("mParking");
        waitForElement(navigationScreen.mParkingTab);
        navigationScreen.mParkingTab.click();

        waitForElement(myEtisalatAppPages.selectEmirate);
        myEtisalatAppPages.selectEmirate.click();

        waitForElement(myEtisalatAppPages.plateNumberTxt);
        myEtisalatAppPages.plateNumberTxt.sendKeys("Dubai 3214");
        driver.hideKeyboard();

        waitForElement(myEtisalatAppPages.parkingZoneTxt);
        myEtisalatAppPages.parkingZoneTxt.sendKeys("asas");
        driver.hideKeyboard();

        waitForElement(myEtisalatAppPages.parkingDuration);
        myEtisalatAppPages.parkingDuration.click();

        waitForElement(myEtisalatAppPages.requestParkingTicket);
        myEtisalatAppPages.requestParkingTicket.click();

        waitForElement(myEtisalatAppPages.confirmaMessage);
        String confirmMsg=myEtisalatAppPages.confirmaMessage.getText().trim().toString();

        System.out.println("the retrived message from the Transaction History List:::===>"+confirmMsg);
        Assert.assertEquals(confirmMsg,"My Etisalat would like to send a message to 7275.");

        waitForElement(myEtisalatAppPages.sendBtn1);
        myEtisalatAppPages.sendBtn1.click();
    }

    @After
    public void end() {
        driver.quit();
    }

}
