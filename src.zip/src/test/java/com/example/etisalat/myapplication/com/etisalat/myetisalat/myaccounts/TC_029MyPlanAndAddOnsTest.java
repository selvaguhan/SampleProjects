package com.example.etisalat.myapplication.com.etisalat.myetisalat.myaccounts;

import com.example.etisalat.myapplication.com.etisalat.baseutils.AppInstallAndUninstallTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class TC_029MyPlanAndAddOnsTest extends BaseTest {

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;


    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_029MyPlanAndAddOnsTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);



        waitForElement(homePage.profileCoverId);
        homePage.profileCoverId.click();

        String profileName = navigationScreen.profileUsrName.getText();
        System.out.println("the profile name is::===>"+profileName);

        waitForElement(navigationScreen.myPlanAndAddOnsTab);
        navigationScreen.clickOnMyPlanAndAddOns();

        waitForElement(myEtisalatAppPages.myPlan1);
        String myplan = myEtisalatAppPages.myPlan1.getText();
        System.out.println("my plan::===>"+myplan);

        String myPlanAddOns=myEtisalatAppPages.getmyPlanAndAddOns();

        Assert.assertEquals("the text is not matching","My Add-Ons",myPlanAddOns);

        String myplanAdd = myEtisalatAppPages.myPlanAddOn1.getText();

        System.out.println("my plan add on::===>"+myplanAdd);
    }

    @After
    public void tearDwon(){
        driver.quit();
    }

}
