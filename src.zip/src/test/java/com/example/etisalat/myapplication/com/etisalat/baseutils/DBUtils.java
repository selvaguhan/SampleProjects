package com.example.etisalat.myapplication.com.etisalat.baseutils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import oracle.jdbc.pool.OracleDataSource;


public class DBUtils {

    Connection conn;
    java.sql.Statement st;

    String jdbcUrl1;
    String userid1;
    String password1;

    String jdbcUrl2;
    String userid2;
    String password2;

    public  DBUtils(){
    }

    ResultSet rs;

    public Connection getCBCMDBConnection(String dbEnv) throws SQLException {
        String url=null;
        String username=null;
        String password=null;
        String driverName = "oracle.jdbc.driver.OracleDriver";
        try{
            if(dbEnv.equalsIgnoreCase("RC")) {
                Class.forName(driverName);
                url = "jdbc:oracle:thin:@AU941:1527:CBCMRCDL";
                username = "cbcm_customer";
                password= "cbcm54321";

            }else if(dbEnv.equalsIgnoreCase("UAT")){
                Class.forName(driverName);
                url = "jdbc:oracle:thin:@au939:1526:CUSTUAT";
                username = "cbcm_uat";
                password= "la$v3gas";
            }else if(dbEnv.equalsIgnoreCase("PD")){
                Class.forName(driverName);
                url = "jdbc:oracle:thin:@au1372:1525:CBCMPD";
                username = "cbcm_customer";
                password= "cbcm54321";
            }
            conn = DriverManager.getConnection(url, username, password);
        }catch (Exception e){
            System.out.println("Unable to connect to the CBCM Data Base::"+e);
        }


        return conn;

    }

    public Connection getLoyaltyDBConnection(String dbEnv) throws SQLException {
        String url=null;
        String username=null;
        String password=null;
        String driverName = "oracle.jdbc.driver.OracleDriver";
        try{
            if(dbEnv.equalsIgnoreCase("RC")) {
                Class.forName(driverName);
                url = "jdbc:oracle:thin:@AU941:1527:CBCMRCDL";
                username = "cbcm_customer";
                password= "cbcm54321";

            }else if(dbEnv.equalsIgnoreCase("UAT")){
                Class.forName(driverName);
                url = "jdbc:oracle:thin:@au463:1521:LOYLTST";
                username = "BE_LOY";
                password= "BE_LOY1";
            }else if(dbEnv.equalsIgnoreCase("PD")){
                Class.forName(driverName);
                url = "jdbc:oracle:thin:@AU3056:1521:LOYLPD";
                username = "BE_LOY";
                password= "be_loy$123";
            }else if(dbEnv.equalsIgnoreCase("PD")){
                Class.forName(driverName);
                url = "jdbc:oracle:thin:@DX2775:1521:DIGIAPPPD";
                username = "digital_app";
                password= "DIGITAL_APP_321";
            }
            conn = DriverManager.getConnection(url, username, password);
        }catch (Exception e){
            System.out.println("Unable to connect to the CBCM Data Base::"+e);
        }


        return conn;

    }

    public Connection getDigitalDBConnection(String dbEnv) throws SQLException {
        String url=null;
        String username=null;
        String password=null;
        String driverName = "oracle.jdbc.driver.OracleDriver";
        try{
            if(dbEnv.equalsIgnoreCase("RC")) {
                Class.forName(driverName);
                url = "jdbc:oracle:thin:@AU941:1527:CBCMRCDL";
                username = "cbcm_customer";
                password= "cbcm54321";

            }else if(dbEnv.equalsIgnoreCase("UAT")){
                Class.forName(driverName);
                url = "jdbc:oracle:thin:@dx755:1521:DEVATG";
                username = "DIGITALAPP";
                password= "DIGITALAPP";
            }else if(dbEnv.equalsIgnoreCase("PD")){
                Class.forName(driverName);
                url = "jdbc:oracle:thin:@DX2775:1521:DIGIAPPPD";
                username = "digital_app";
                password= "DIGITAL_APP_321";
            }
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("the connection object::"+conn);
        }catch (Exception e){
            System.out.println("Unable to connect to the CBCM Data Base::"+e);
        }


        return conn;

    }

    public ResultSet fetchDataFromDataBase(String database,String dbEnv,String querry) {

        try {
            if(database.equalsIgnoreCase("CBCM")){
                System.out.println("the db connection==>"+getCBCMDBConnection(dbEnv));
            }else if(database.equalsIgnoreCase("Loyalty")){
                System.out.println("the db connection==>"+getLoyaltyDBConnection(dbEnv));
            }else if(database.equalsIgnoreCase("DIGITALAPP")){
                System.out.println("the db connection==>"+getDigitalDBConnection(dbEnv));
            }

            st = conn.createStatement();
            rs = st.executeQuery(querry);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public Connection getCSSDBConnection() throws SQLException{


        /*OracleDataSource ds;
        ds = new OracleDataSource();
        ds.setURL(jdbcUrl2);
        conn=ds.getConnection(userid2,password2);
        return conn;*/

        try{
            String driverName = "oracle.jdbc.driver.OracleDriver";
            Class.forName(driverName);
            // Create a connection to the database
            String serverName = "localhost";
            String serverPort = "1521";
            String sid = "orcl";
            String url = "jdbc:oracle:thin:@au931:1521:CSSRC";
            String username = "CSSRC";
            String password = "cssproject$123";
            conn = DriverManager.getConnection(url, username,     password);
        }catch (Exception e){

        }
        return conn;
    }

    public ResultSet fetchDataFromCSSDB(String querry) {
        try {
            System.out.println("the db connection==>"+getCSSDBConnection());
            st = conn.createStatement();
            rs = st.executeQuery(querry);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public ResultSet fetchDataFromCBCMDB(String dbEnv,String querry) {
        try {
            System.out.println("the db connection==>"+getCBCMDBConnection(dbEnv));
            st = conn.createStatement();
            rs = st.executeQuery(querry);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public void insertValuesIntoCSSDB(String querry) throws SQLException {
        conn=getCSSDBConnection();
        conn.setAutoCommit(false);
        PreparedStatement pstmt3 = conn.prepareStatement(querry);
        pstmt3.executeUpdate(querry);
        pstmt3.close();
        conn.commit();
        conn.close();
    }

    public void insertValuesIntoCBCMDb(String dbEnv,String querry) throws SQLException {
        conn=getCBCMDBConnection(dbEnv);
        conn.setAutoCommit(false);
        PreparedStatement pstmt3 = conn.prepareStatement(querry);
        pstmt3.executeUpdate(querry);
        pstmt3.close();
        conn.commit();
        conn.close();
    }

    public void executeQuerryWithPreparedSt(String dbEnv,String querry) throws SQLException {
        conn=getCBCMDBConnection(dbEnv);
        conn.setAutoCommit(false);
        PreparedStatement pstmt3 = conn.prepareStatement(querry);
        pstmt3.executeUpdate(querry);
        pstmt3.close();
        conn.commit();
        conn.close();
    }

    public void updateValuesIntoCSSDB(String querry) throws SQLException {
        conn=getCSSDBConnection();
        conn.setAutoCommit(false);
        PreparedStatement pstmt3 = conn.prepareStatement(querry);
        pstmt3.executeUpdate(querry);
        pstmt3.close();
        conn.commit();
        conn.close();
    }

    public void updateValuesIntoCBCMDB(String dbEnv,String querry) throws SQLException {
        conn=getCBCMDBConnection(dbEnv);
        conn.setAutoCommit(false);
        PreparedStatement pstmt3 = conn.prepareStatement(querry);
        pstmt3.executeUpdate(querry);
        pstmt3.close();
        conn.commit();
        conn.close();
    }

    public String iterateResultSet(ResultSet rs,String columAttribute) {
        String result=null;;
        try {
            while(rs.next()) {
                System.out.println("the status of the result set is ==>"+rs.getString(columAttribute));
                //rs.first();
                result= rs.getString(columAttribute);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try{
                if(rs != null){
                    rs.close();
                }
                if(st!= null){
                    st.close();
                }
                if(conn != null) {
                    conn.close();
                }
            }catch (Exception e){
                System.out.print("the exception in finallky block::"+e);
            }

        }

        return result;
    }

    public ArrayList<String> iterateFirstRowResultSetWithMultiColumAttribute(ResultSet rs,ArrayList columAttribute){
        ArrayList<String> result= new ArrayList<String>();

        try {
            if(rs.next()) {
                //rs.first();
                for(int i=0;i<columAttribute.size();i++){
                    String tt = columAttribute.get(i).toString().trim();
                   System.out.println("the status of the result set is ==>"+rs.getString(tt));
                    //rs.first();
                    result.add(rs.getString(tt));
                }

           }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try{
                if(rs != null){
                    rs.close();
                }
                if(st!= null){
                    st.close();
                }
                if(conn != null) {
                    conn.close();
                }
            }catch (Exception e){
                System.out.print("the exception in finallky block::"+e);
            }

        }

        return result;
    }

    public void closeDbUtils(){
        try{
            if(rs != null){
                rs.close();
            }
            if(st!= null){
                st.close();
            }
            if(conn != null) {
                conn.close();
            }
        }catch (Exception e){
            System.out.print("the exception in finallky block::"+e);
        }
    }
}
