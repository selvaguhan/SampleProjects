package com.example.etisalat.myapplication;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class SmilesDeviceDemo {

    AppiumDriver driver;
    Dimension size;

    @Before
    public void setUp() throws MalformedURLException {
        // Created object of DesiredCapabilities class.

        // Created object of DesiredCapabilities class.
        DesiredCapabilities capabilities = new DesiredCapabilities();

        // Set android deviceName desired capability. Set it Android Emulator.
        capabilities.setCapability("deviceName", "9ab45aa3");

        // Set browserName desired capability. It's Android in our case here.
        capabilities.setCapability("browserName", "Android");

        // Set android platformVersion desired capability. Set your emulator's android version.
        capabilities.setCapability("platformVersion", "P");

        // Set android platformName desired capability. It's Android in our case here.
        capabilities.setCapability("platformName", "Android");

        // Set android appPackage desired capability. It is com.android.calculator2 for calculator application.
        // Set your application's appPackage if you are using any other app.
        capabilities.setCapability("appPackage", "ae.etisalat.smiles");
        //package:/system/app/ExactCalculator/ExactCalculator.apk=com.android.calculator2
        // Set android appActivity desired capability. It is com.android.calculator2.Calculator for calculator application.
        // Set your application's appPackage if you are using any other app.
        capabilities.setCapability("appActivity", "ae.etisalat.smiles.activities.SplashActivity");

        // Created object of RemoteWebDriver will all set capabilities.
        // Set appium server address and port number in URL string.
        // It will launch calculator app in android device.
        //driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);


    }

    @Test
    public void testFirstCalculator() {


        // Click on DELETE/CLR button to clear result text box before running test.
        //driver.findElements(By.xpath("//android.widget.Button")).get(0).click();

        // Click on number 2 button.
        //By.xpath("//android.widget.EditText[@text='Email ID']")
        //driver.findElement(By.xpath("//android.widget.AppCompatTextView[contains(text(),'The Bagel Bar')]")).click();

        //driver.findElement(By.xpath("//android.widget.TextView[@text='The Bagel Bar']")).click();
        /*for(int i=0;i<4;i++)
        {
            try {
                Thread.sleep(2000);
            } catch (Exception e) {

            }
            if (driver.findElement(By.xpath("//android.widget.TextView[@text='Roxy Cinemas']")).isDisplayed())
            {
                driver.findElement(By.xpath("//android.widget.TextView[@text='Roxy Cinemas']")).click();
                break;
            }
            else
            {
                horizontalScroll();
            }

            driver.findElement(By.xpath("//android.widget.TextView[@text='The Bagel Bar']")).click();
        }*/

       /* driver.findElement(By.xpath("//android.widget.TextView[@text='Roxy Cinemas']")).click();
        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }*/

        driver.findElement(By.xpath("//android.widget.TextView[@text='Beauty Time Salon & Spa']")).click();
        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }

        /*driver.findElement(By.name("Ramadan Offers")).click();
        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }

        driver.findElement(By.name("APPLEBEES")).click();

        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }*/

        driver.findElement(By.xpath("//android.widget.Button[@text='GET NOW']")).click();

        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }

        driver.findElement(By.xpath("//android.widget.Button[@text='proceed']")).click();

        //driver.findElement(By.name("Ramadan Offers")).click();


        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

     public void horizontalScroll()
    {
        size=driver.manage().window().getSize();
        int x_start=(int)(size.width*0.60);
        int x_end=(int)(size.width*0.30);
        int y=130;
        driver.swipe(x_start,y,x_end,y,4000);
    }

    @After
    public void end() {
        driver.quit();
    }
}
