package com.example.etisalat.myapplication.com.etisalat.myetisalat.sharedCreditsAndData;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.DBUtils;
import com.example.etisalat.myapplication.com.etisalat.baseutils.SoapApiUtils;
import com.example.etisalat.myapplication.com.etisalat.baseutils.XMLParser;
import com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs.AutoConfigs;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.sql.ResultSet;
import java.util.ArrayList;

import javax.xml.soap.SOAPMessage;

import io.appium.java_client.android.AndroidKeyCode;

public class InternationalCreditTransferTest extends BaseTest {
    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    SoapApiUtils ss;
    XMLParser xmlParser;
    DBUtils dbUtils;

    @Before
    public void setUp(){
        launchAndroidApplication();
    }

    @Test
    public void internationalCreditTransferTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        ss = new SoapApiUtils();
        xmlParser=new XMLParser();
        dbUtils = new DBUtils();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        String accountBalPreRecharge=null,accountBalPostRecharge=null;
        try{
            SOAPMessage soapRequest=ss.createSOAPRequest("C:\\Users\\jekumar\\Desktop\\wsdl\\IN\\test13.xml");
            SOAPMessage response=ss.getSOAPResponse(soapRequest,"http://tibcononprd.etisalat.corp.ae:9061/GetINAccountDetails");
            accountBalPreRecharge=xmlParser.getTagValue(response,"ns0:AccountBalance");
            System.out.println("the account balance is ::"+accountBalPreRecharge);
        }catch (Exception e){

        }

        waitForElement(navigationScreen.shareCreditAndDataTab);
        navigationScreen.clickOnShareCreditAndDataTab();

        waitForElement(myEtisalatAppPages.internationalCreditTransferTab);
        myEtisalatAppPages.clickOnInternationalCreditTransferTab();

        waitForElement(myEtisalatAppPages.internationalMoblieNumberTxt);
        myEtisalatAppPages.enterInternationalMobileNumber("+919880766775");

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        /*waitForElement(myEtisalatAppPages.givenInterMobNumber);
        String interMob=myEtisalatAppPages.getGivenInterMobNumber();
        System.out.println("the retrieved given internationl mobile number from the application::"+interMob);
        Assert.assertEquals("did not matching","+919880766775",interMob)*/;

        waitForElement(myEtisalatAppPages.selectedCounty);
        String selectedCounty=myEtisalatAppPages.getSelectedCounty();
        System.out.println("the retrived selected country from the application::"+selectedCounty);
        Assert.assertEquals("did not matching","India",selectedCounty);

        waitForElement(myEtisalatAppPages.inr50);
        myEtisalatAppPages.clickOnINR50Tab();

        waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();

        waitForElement(myEtisalatAppPages.securityScreen);
        String securityCode =myEtisalatAppPages.getSecurityCode();

        System.out.println("the security code screen is:::===>"+securityCode);
        Assert.assertTrue(securityCode.contains("security code"));

        ArrayList<String> colAtrri= new ArrayList<String>();
        colAtrri.add("otp");

        ResultSet rs = dbUtils.fetchDataFromDataBase(AutoConfigs.databaseDigital,AutoConfigs.dbUATENV, "select  otp  from OTP order by created_date desc");

        ArrayList<String> otp = dbUtils.iterateFirstRowResultSetWithMultiColumAttribute(rs,colAtrri);

        System.out.println("the latest opt ::"+otp);

        myEtisalatAppPages.securityTxt.sendKeys(otp.get(0));

       driver.swipe(100,500,0,0,30);

        myEtisalatAppPages.proceedBtn.click();

        waitForElement(myEtisalatAppPages.successTitle);
        String text = myEtisalatAppPages.successTitle.getText();

        Assert.assertEquals("Thank you",text);

        try{
            SOAPMessage soapRequest=ss.createSOAPRequest("C:\\Users\\jekumar\\Desktop\\wsdl\\IN\\test13.xml");
            SOAPMessage response=ss.getSOAPResponse(soapRequest,"http://tibcononprd.etisalat.corp.ae:9061/GetINAccountDetails");
            accountBalPostRecharge=xmlParser.getTagValue(response,"ns0:AccountBalance");
            System.out.println("the account balance is ::"+accountBalPostRecharge);
        }catch (Exception e){

        }

        double finalAddedBalance = Double.parseDouble(accountBalPreRecharge)-3.83;

        org.testng.Assert.assertEquals(Double.toString(finalAddedBalance),accountBalPostRecharge);


    }
}
