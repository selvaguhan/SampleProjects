package com.example.etisalat.myapplication.com.etisalat.myetisalat.helpandsupport;

import com.example.etisalat.myapplication.com.etisalat.baseutils.AppInstallAndUninstallTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class TC_036ContactEtisalatTest extends BaseTest {
    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    AppInstallAndUninstallTest mmm;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void tc_036ContactEtisalatTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        mmm = new AppInstallAndUninstallTest();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        driver.swipe(489,1566,0,0,3000);
        //mmm.scrollDown(489,1566,0,0);

        //waitForElement(navigationScreen.helpAndSupportTab);
        navigationScreen.clickOnHelpAndSupportTab();

        waitForElement(myEtisalatAppPages.contactEtisalatTab);
        myEtisalatAppPages.clickOnContactEtisalatTab();

        waitForElement(myEtisalatAppPages.emailUsTab);
        String emailUs = myEtisalatAppPages.validateEmailUsTab();
        System.out.println("the retrieved  email us  from the application::"+emailUs);
        Assert.assertEquals("text is not matching","Email us",emailUs);

       /* waitForElement(myEtisalatAppPages.careEmailId);
        String careEmail = myEtisalatAppPages.validateCareEmailId();
        System.out.println("the retrieved  roaming email id  from the application::"+careEmail);
        Assert.assertEquals("text is not matching","care@etisalat.ae",careEmail);*/

/*        waitForElement(myEtisalatAppPages.roamingCareId);
        String roamingCareEmail = myEtisalatAppPages.validateRoamingCareEmailId();
        System.out.println("the retrieved  roaming email id  from the application::"+roamingCareEmail);
        Assert.assertEquals("text is not matching","roamingcare@etisalat.ae",roamingCareEmail);*/

        waitForElement(myEtisalatAppPages.callUsTab);
        String callUs = myEtisalatAppPages.validateCallUsTab();
        System.out.println("the retrieved  call us tab from the application::"+callUs);
        Assert.assertEquals("text is not matching","Call us",callUs);


        waitForElement(myEtisalatAppPages.otherContactNumbersTab);
        String otherContactNumbers = myEtisalatAppPages.validateOtherContactNumbersTab();
        System.out.println("the retrieved  Other contact numbers from the application::"+otherContactNumbers);
        Assert.assertEquals("text is not matching","Other contact numbers",otherContactNumbers);



    }

    @After
    public void tearDwon(){
        driver.quit();
    }

}
