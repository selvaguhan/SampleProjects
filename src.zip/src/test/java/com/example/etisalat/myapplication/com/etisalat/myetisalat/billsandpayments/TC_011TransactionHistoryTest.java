package com.example.etisalat.myapplication.com.etisalat.myetisalat.billsandpayments;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import java.net.MalformedURLException;

public class TC_011TransactionHistoryTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void tc_011TransactionHistoryTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();


        waitForElement(navigationScreen.rechargeAndPayTab);
        navigationScreen.clickOnRechargeAndPayTab();

        driver.scrollToExact("Transaction History");
        waitForElement(navigationScreen.transactionHistoryTab);
        navigationScreen.transactionHistoryTab.click();

        waitForElement(myEtisalatAppPages.allTab);
        String payBill=myEtisalatAppPages.allTab.getText().trim().toString();

        System.out.println("the retrived message from the Transaction History List:::===>"+payBill);
        Assert.assertTrue(payBill.equalsIgnoreCase("All"));

        waitForElement(myEtisalatAppPages.usageTab);
        String payBillDate=myEtisalatAppPages.usageTab.getText().trim().toString();

        System.out.println("the retrived message from the Transaction History List:::===>"+payBillDate);
        Assert.assertTrue(payBillDate.equalsIgnoreCase("USAGE"),"text is not matching");
    }

    @After
    public void end() {
        driver.quit();
    }
}
