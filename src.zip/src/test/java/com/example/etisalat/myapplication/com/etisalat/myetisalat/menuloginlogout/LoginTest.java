package com.example.etisalat.myapplication.com.etisalat.myetisalat.menuloginlogout;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.LoginPage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class LoginTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    LoginPage loginPage;


    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void loginTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        loginPage=PageFactory.initElements(driver,LoginPage.class);

        waitForElement(loginPage.userNameTxt);
        loginPage.login("takar","123456");
        driver.hideKeyboard();
        //driver.scrollTo("LOGIN");
        loginPage.loginBtn.click();

       /* waitForElement(loginPage.notNowBtn);
        loginPage.notNowBtn.click();*/

        waitForElement1(homePage.menuToggleElement);

        String tt = homePage.profileCoverId.getText();

        System.out.println("the retrived text is::"+tt);

        Assert.assertTrue(homePage.menuToggleElement.isDisplayed());



    }

    @After
    public void tearDwon(){
        driver.quit();
    }
}
