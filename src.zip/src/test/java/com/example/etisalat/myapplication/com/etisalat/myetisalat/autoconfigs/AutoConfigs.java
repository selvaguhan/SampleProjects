package com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs;

import java.util.ArrayList;

public class AutoConfigs {

    public static String dbUATENV="UAT";
    public static String dbRCENV="RC";
    public static String dbPDENV="PD";
    public  static  String database="Loyalty";
    public  static  String databaseDigital="DIGITALAPP";

    public static String amountToBePaid="13";


    public static String uatAccoutNumber="0543935081"; //uat account for postpaid
    public static String pdAccoutNumber="0543935609"; //pd account for postpaid
    public static String pdAreaCode="054";
    public static String pdProductNumber="3935609";

    public static String uatAreaCode="054";
    public static String uatProductNumber="3936849";//3936849

    public static String pdPrePaidAccoutNumber="0543935607";
    public static String pdPrePaidProductNumber="3935607";

    public static String paymentTransactionIdAttribute="payment_transaction_id";
    public static String allocatedAmountSysCurrAttribute="allocated_amount_sys_curr";
    public static String allocatedAmountPaidCurrAttribute="allocated_amount_paid_curr";

    public static String subrequestIdAttribute="subrequest_id";
    public static String createdDateAttribute="created_date";


    public static String  get_T_PAY_DTL_PAYMENT_TRANSACTION(String accountNo){
        String paymentDetailsQuerry ="select * from T_PAY_DTL_PAYMENT_TRANSACTION  WHERE  ACCOUNT_number='"+accountNo+"' order by created_date desc";
        return paymentDetailsQuerry;
    }

    public static String  get_SR_t_soh_subrequest(String areaCode,String productNumber){
        //select subrequest_id,created_date from t_soh_subrequest where area_code='054' and product_number='3936849'  order by created_date desc
        String getSRQuerry ="select subrequest_id,created_date from t_soh_subrequest where area_code='"+areaCode+"'"+" and product_number='"+productNumber+"'"+"  order by created_date desc";
        return getSRQuerry;
    }
    public static String  get_transaction_t_pay_prepayment_dtl(String subRequest){
        String getTransaction ="select * from t_pay_prepayment_dtl ps where ps.subrequest_id='"+subRequest+"' and modified_user_id='SYSTEM'";
        return getTransaction;
    }

    public static String  get_t_pay_payment_transaction(String transactionId){
        String getTransaction ="select * from t_pay_payment_transaction pk where pk.transaction_id='"+transactionId+"'";
        return getTransaction;
    }

    public static String  get_smilePoints_ACCOUNTS(String accountNumber){
        String getSmilePoints ="select  availablepoints  from  ACCOUNTS where  account_number='"+accountNumber+"' and number_status='ACT'";
        return getSmilePoints;
    }

    public static String  get_T_SOH_CHNNL_PIN_REGISTRATION(String productNumber){
        String getPinNumber ="select * from T_SOH_CHNNL_PIN_REGISTRATION t where t.account_number=97154'"+productNumber+"'";
        return getPinNumber;
    }
    public static String  delete_T_SOH_CHNNL_PIN_REGISTRATION(String productNumber){
        String getPinNumber ="DELETE from T_SOH_CHNNL_PIN_REGISTRATION t where t.account_number=97154'"+productNumber+"'";
        return getPinNumber;
    }



    public static ArrayList<String> getListOfAttributesToFetchDetails(){
        ArrayList<String> al = new ArrayList<String>();
        al.add(paymentTransactionIdAttribute);
        al.add(allocatedAmountSysCurrAttribute);
        al.add(allocatedAmountSysCurrAttribute);
        return al;
    }

    public static ArrayList<String> getSRAttributesList(){
        ArrayList<String> al = new ArrayList<String>();
        al.add(subrequestIdAttribute);
        al.add(createdDateAttribute);
        return al;
    }
}
