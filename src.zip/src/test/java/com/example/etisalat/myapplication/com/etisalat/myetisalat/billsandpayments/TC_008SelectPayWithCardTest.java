package com.example.etisalat.myapplication.com.etisalat.myetisalat.billsandpayments;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.DBUtils;
import com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs.AutoConfigs;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;
import java.sql.ResultSet;
import java.util.ArrayList;

public class TC_008SelectPayWithCardTest extends BaseTest {

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    DBUtils dbUtils;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_008SelectPayWithCardTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        dbUtils = new DBUtils();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.billsAndPaymentsTab);
        navigationScreen.clickOnBillsAndPaymentsTab();

        waitForElement(navigationScreen.payMyBillsTab);
        navigationScreen.payMyBillsTab.click();

        waitForElement(homePage.postPaidRadioBtn);
        homePage.clickOnPostPaidRadioBtn();

        waitForElement(homePage.paySelectedBtn);
        homePage.clickOnPaySelectedBtn();

        waitForElement(myEtisalatAppPages.totalDueAmountTxt);
        myEtisalatAppPages.enterTotalDueAmount(AutoConfigs.amountToBePaid);

        waitForElement(myEtisalatAppPages.rechargeNextBtn);
        myEtisalatAppPages.clickOnRechargeNextBtn();

        waitForElement(homePage.lastUsedCheckBox);
        homePage.clickOnlastUsedCheckBox();

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();

        waitForElement(homePage.cvvTxt);
        homePage.enterCVVNo("123");

        waitForElement(homePage.payBtn);
        homePage.clickOnPayBtn();

        waitForElement(homePage.paymentHeadingTitle);
        String payMentText =homePage.paymentHeadingTitle.getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"PAYMENT SUCCESSFUL");

        ArrayList<String> attributesList = AutoConfigs.getListOfAttributesToFetchDetails();

        ResultSet rs = dbUtils.fetchDataFromCBCMDB(AutoConfigs.dbUATENV, AutoConfigs.get_T_PAY_DTL_PAYMENT_TRANSACTION(AutoConfigs.uatAccoutNumber));
        ArrayList<String> resultList = dbUtils.iterateFirstRowResultSetWithMultiColumAttribute(rs,attributesList);
        System.out.println("the whole result set ::"+resultList);

        String transactionId11=resultList.get(0);
        System.out.println("the payment transaction id ::"+transactionId11);

        System.out.println("allocated_amount_sys_curr is ::"+resultList.get(1));
        Assert.assertEquals(resultList.get(1),AutoConfigs.amountToBePaid);

        System.out.println("the payment transaction id ::"+resultList);
        Assert.assertEquals(resultList.get(2),AutoConfigs.amountToBePaid);

        String querry1 ="select * from T_PAY_PAYMENT_TRANSACTION ppt where ppt.payment_transaction_id='"+transactionId11+"'";

        ResultSet res1 = dbUtils.fetchDataFromCBCMDB(AutoConfigs.dbUATENV,querry1);
        String result = dbUtils.iterateResultSet(res1,"total_payment_amount_paid_curr");
        System.out.println("the payment transaction id ::"+result);
        Assert.assertEquals(result,AutoConfigs.amountToBePaid);

    }

    @After
    public void end() {
        driver.quit();
        dbUtils.closeDbUtils();
    }
}
