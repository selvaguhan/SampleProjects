package com.example.etisalat.myapplication.com.etisalat.tests;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;

public class PrepaidRechargeTest extends BaseTest {

    HomePage homePage;
    NavigationScreen navigationScreen;



    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void prepaidRechargeTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.rechargeAndPayTab);
        navigationScreen.clickOnRechargeAndPayTab();

        waitForElement(navigationScreen.rechargeTab);
        navigationScreen.clickOnRechargeTab();

        waitForElement(navigationScreen.rechargeAmountTxt);
        navigationScreen.enterPrepaidRechargeAmount("10");

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.lastUsedCheckBox);
        homePage.clickOnlastUsedCheckBox();

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();

        waitForElement(homePage.cvvTxt);
        homePage.enterCVVNo("123");

        waitForElement(homePage.payBtn);
        homePage.clickOnPayBtn();

        waitForElement(homePage.paymentHeadingTitle);
        String payMentText =homePage.paymentHeadingTitle.getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"Recharge successful");

    }
    //@After
    public void end() {
        driver.quit();
    }
}
