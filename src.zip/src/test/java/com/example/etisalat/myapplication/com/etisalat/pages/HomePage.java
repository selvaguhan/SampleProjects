package com.example.etisalat.myapplication.com.etisalat.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import oracle.jdbc.pool.OracleDataSource;

public class HomePage {

    @FindBy(xpath = "//android.widget.TextView[@text='Help & Support']")
    public WebElement helpAndSupportTab;

    @FindBy(id = "com.Etisalat.ETIDA:id/profile_image")
    @CacheLookup
    public WebElement profileImageTab;

    @FindBy(xpath = "//android.widget.TextView[@resource-id='com.Etisalat.ETIDA:id/cover_title']")
    public WebElement profileCoverId;


    public void clickOnProfileImage(){
        profileImageTab.click();
    }

    @FindBy(xpath = "//android.widget.ImageButton[@resource-id='com.Etisalat.ETIDA:id/menu_toggle']")
    @CacheLookup
    public WebElement menuToggleElement;

    @FindBy(xpath = "//android.widget.TextView[@text='Etisalat Automation']")
    @CacheLookup
    public WebElement profileIdByText;

    public void clickOnProfileIdByText(){
        profileIdByText.click();
    }

    public void menuToggleTab(){
        menuToggleElement.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Bills and Payments']")
    @CacheLookup
    public WebElement billsAndPayments;

    public void clickOnBillsAndPaymentTab(){
        billsAndPayments.click();
    }


    @FindBy(xpath = "//android.widget.TextView[@text='View and Pay Bills']")
    @CacheLookup
    public WebElement viewAndPayBills;

    public void clickOnViewAndPayBills(){
        viewAndPayBills.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/cb_postpaid")
    @CacheLookup
    public WebElement postPaidRadioBtn;

    public void clickOnPostPaidRadioBtn(){
        postPaidRadioBtn.click();
    }

    @FindBy(xpath = "(//android.widget.CheckBox[@resource-id='com.Etisalat.ETIDA:id/cb_postpaid'])[position()=2]")
    @CacheLookup
    public WebElement postPaidRadioBtn1;

    @FindBy(xpath = "(//android.widget.CheckBox[@resource-id='com.Etisalat.ETIDA:id/cb_postpaid'])[position()=3]")
    @CacheLookup
    public WebElement postPaidRadioBtn3;

    @FindBy(xpath = "(//android.widget.CheckBox[@resource-id='com.Etisalat.ETIDA:id/cb_postpaid'])[position()=4]")
    @CacheLookup
    public WebElement postPaidRadioBtn4;

    @FindBy(xpath = "(//android.widget.CheckBox[@resource-id='com.Etisalat.ETIDA:id/cb_postpaid'])[position()=5]")
    @CacheLookup
    public WebElement postPaidRadioBtn5;

    public void clickOnPostPaidRadioBtn1(){
        postPaidRadioBtn1.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/et_mobile_number")
    @CacheLookup
    public WebElement collectCallMobleNoTxt;

    public void ënterCollectCall(String txt){
        collectCallMobleNoTxt.clear();
        collectCallMobleNoTxt.sendKeys(txt);
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Pay selected']")
    @CacheLookup
    public WebElement paySelectedBtn;

    public void clickOnPaySelectedBtn(){
        paySelectedBtn.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/tv_price")
    @CacheLookup
    public WebElement priceTxt;

    public void ënterBillPaymentAmount(String txt){
        priceTxt.clear();
        priceTxt.sendKeys(txt);
    }


    @FindBy(id = "com.Etisalat.ETIDA:id/btn_recahrgeSelect_next")
    @CacheLookup
    public WebElement rechargeNextBtn;

    public void clickOnRechargeNextBtn(){
        rechargeNextBtn.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/tv_call")
    @CacheLookup
    public WebElement callBtn;

    public void clickOnCallBtn(){
        callBtn.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/message")
    @CacheLookup
    public WebElement messagePopup;

    public String  getMessagePopup(){
        String mm =messagePopup.getText();
        return mm;

    }

    @FindBy(id = "com.Etisalat.ETIDA:id/message_text_view")
    @CacheLookup
    public WebElement messagePopup1;

    public String  getMessagePopup1(){
        String mm =messagePopup1.getText();
        return mm;

    }

    //@FindBy(id = "com.Etisalat.ETIDA:id/cb_lct_last_used_checkbox")


    @FindBy(id = "com.Etisalat.ETIDA:id/cb_lct_last_used_checkbox")
    @CacheLookup
    public WebElement lastUsedCheckBox;

    public void clickOnlastUsedCheckBox(){
        lastUsedCheckBox.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/cb_last_used_checkbox")
    @CacheLookup
    public WebElement lastUsedCheckBox1;

    @FindBy(xpath = "//android.widget.CheckBox[@resource-id='com.Etisalat.ETIDA:id/cb_reward_points' or @resource-id='com.Etisalat.ETIDA:id/cb_rewards_points_checkbox']")//com.Etisalat.ETIDA:id/cb_reward_points
    @CacheLookup
    public WebElement payWithSmilesPointsCheckBox;

    public void clickOnPayWithSmilesPointsCheckBox(){
        payWithSmilesPointsCheckBox.click();
    }


    @FindBy(id = "com.Etisalat.ETIDA:id/cb_lct_use_another_checkbox")
    @CacheLookup
    public WebElement payWithNewCardCheckBox;

    public void clickOnPayWithNewCardCheckBox(){
        payWithNewCardCheckBox.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/cb_lct_add_new_checkbox")
    @CacheLookup
    public WebElement payWithNewCardChk1;

    public void clickOnPayWithNewCardChk1(){
        payWithNewCardChk1.click();
    }

    @FindBy(xpath = "//android.widget.TextView[@text='Pay with last used card']")
    @CacheLookup
    public WebElement payWithLastUsedCard;


    @FindBy(id = "com.Etisalat.ETIDA:id/tv_next")
    @CacheLookup
    public WebElement nextBtn;

    public void clickOnNextBtn(){
        nextBtn.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/payButton")
    @CacheLookup
    public WebElement nextBtn1;

    public void clickOnNextBtn1(){
        nextBtn1.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/tv_ltc_next")
    @CacheLookup
    public WebElement nextBtn2;

    public void clickOnNextBtn2(){
        nextBtn2.click();
    }




    @FindBy(id = "com.Etisalat.ETIDA:id/okButton")//com.Etisalat.ETIDA:id/okButton
    @CacheLookup
    public WebElement okBtn;

    public void clickOnOkBtn(){
        okBtn.click();
    }


    @FindBy(id = "com.Etisalat.ETIDA:id/tv_ivr_detail")
    @CacheLookup
    public WebElement digitPinSuccess;

    @FindBy(xpath = "//android.widget.EditText[@resource-id='ValidationCode']")
    @CacheLookup
    public WebElement cvvTxt;

    public void enterCVVNo(String cvv){
        cvvTxt.sendKeys(cvv);
    }

    @FindBy(xpath = "//android.widget.EditText[@resource-id='cardNumber']")
    @CacheLookup
    public WebElement cardNumberTxt;

    public void enterCardNumber(String cardNumber){
        cardNumberTxt.sendKeys(cardNumber);
    }


    @FindBy(xpath = "//android.widget.EditText[@resource-id='CH_Name']")
    @CacheLookup
    public WebElement cardNametxt;


    @FindBy(xpath = "//android.widget.EditText[@text='2019']")
    @CacheLookup
    public WebElement viewDropDownExpiryYear;

    public void clickOnViewExpiryYearDropDown(){
        viewDropDownExpiryYear.click();
    }

    //android.view.View
    @FindBy(xpath = "//android.view.View[@text='2019']")
    @CacheLookup
    public WebElement expiryYear;

    public void clickOnExpiryYear(){
        expiryYear.click();
    }

    @FindBy(xpath = "//android.widget.Button[@content-desc = 'Pay' or @text='Pay']")
    @CacheLookup
    public WebElement payBtn;

    public void clickOnPayBtn(){
        payBtn.click();
    }

    @FindBy(id = "com.Etisalat.ETIDA:id/tv_payment_heading")
    @CacheLookup
    public WebElement paymentHeadingTitle;


    @FindBy(id = "com.Etisalat.ETIDA:id/btn_upgrade_ok")
    @CacheLookup
    public WebElement lastOkBtn;

    public void clickOnLastOkBtn(){
        lastOkBtn.click();
    }

}
