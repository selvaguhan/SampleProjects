package com.example.etisalat.myapplication.com.etisalat.myetisalat.etisalatshop;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.DBUtils;
import com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs.AutoConfigs;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;
import java.sql.ResultSet;
import java.util.ArrayList;

public class TC_023PurchaseWithPrepaidBalanceTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    DBUtils dbUtils;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_023PurchaseWithPrepaidBalanceTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages = PageFactory.initElements(driver,MyEtisalatAppPages.class);
        dbUtils = new DBUtils();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.etisalatShopTab);
        navigationScreen.etisalatShopTab.click();

        waitForElement(navigationScreen.searchBtn);
        navigationScreen.searchBtn.click();

       try{
        Thread.sleep(2000);
       }catch (Exception e){

       }

        navigationScreen.monthplan.click();

       // navigationScreen.dataTab.click();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

       /* myEtisalatAppPages.clickOnNavigateBack();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }*/

        //navigationScreen.exclusiveAppOffer.click();

        //driver.scrollToExact("Featured");
        //waitForElement(myEtisalatAppPages.featuredTab);

      /*  try{
            Thread.sleep(4000);
        }catch (Exception e){

        }*/
        //myEtisalatAppPages.featuredTab.click();


        driver.scrollToExact("250MB + 250MB Plus Month Plan");
        waitForElement(myEtisalatAppPages.dayPack250mb);
        myEtisalatAppPages.dayPack250mb.click();

        driver.scrollToExact("Deduct from balance");
        String tt = myEtisalatAppPages.deductBalanceChk.getAttribute("checked");
        if(tt.equalsIgnoreCase("true")){

        }else {
            myEtisalatAppPages.deductBalanceChk.click();

        }

        waitForElement(myEtisalatAppPages.buyBtn);
        myEtisalatAppPages.buyBtn.click();

        waitForElement(myEtisalatAppPages.logOutOkBtn);
        myEtisalatAppPages.logOutOkBtn.click();

        try{
            Thread.sleep(60000);
        }catch (Exception e){

        }

        ArrayList<String> attributesList = AutoConfigs.getSRAttributesList();


        //ResultSet rs = dbUtils.fetchDataFromCBCMDB(AutoConfigs.dbUATENV, AutoConfigs.get_SR_t_soh_subrequest(AutoConfigs.uatAreaCode,AutoConfigs.uatProductNumber));

        ResultSet rs = dbUtils.fetchDataFromCBCMDB(AutoConfigs.dbUATENV, "select subrequest_id,created_date from T_SOH_SUBREQUEST where account_number='0543936849' AND CREATED_DATE>SYSDATE-1 order by created_date desc");

        ArrayList<String> resultList = dbUtils.iterateFirstRowResultSetWithMultiColumAttribute(rs,attributesList);
        System.out.println("the whole result set ::"+resultList);

        String subRequestId=resultList.get(0);
        System.out.println("the sub request id ::"+subRequestId);
        Assert.assertTrue(!subRequestId.isEmpty());

        System.out.println("service required date::"+resultList.get(1));
        if (resultList.get(1).equalsIgnoreCase(getCurrentDate())){
            Assert.assertTrue(true);
        }

    }

/*    //@After
    public void end() {
        driver.quit();
    }*/
}
