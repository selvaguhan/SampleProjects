package com.example.etisalat.myapplication.com.etisalat.baseutils;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

public class AppInstallAndUninstallTest {


    public void installApk(String fileName){


        try {

            ProcessBuilder builder = new ProcessBuilder(
                    new String[]{"cmd.exe","/c","adb install -t C:\\Users\\etisalat\\Desktop\\sofwares\\testApkFile\\"+fileName}
            );
            builder.redirectErrorStream(true);

            Process p = builder.start();

            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true){
                line=r.readLine();
                if (line== null){
                    break;
                }
                System.out.println(line);
            }

        } catch (Exception e1) {

            System.err.println(e1);
        }

    }

    public void uninstallApk(String packageName){

        try {

            ProcessBuilder builder = new ProcessBuilder(
                    new String[]{"cmd.exe","/c","adb uninstall"+" "+packageName}
            );
            builder.redirectErrorStream(true);

            Process p = builder.start();

            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true){
                line=r.readLine();
                if (line== null){
                    break;
                }
                System.out.println(line);
            }

        } catch (Exception e1) {

            System.err.println(e1);
        }

    }

    public void scrollDown(int startx,int starty,int endx,int endy){


        try {

            ProcessBuilder builder = new ProcessBuilder(
                    new String[]{"cmd.exe","/c","adb shell input swipe "+startx+" "+starty+" "+endx+" "+endy}

            );
            builder.redirectErrorStream(true);

            Process p = builder.start();

            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true){
                line=r.readLine();
                if (line== null){
                    break;
                }
                System.out.println(line);
            }

        } catch (Exception e1) {

            System.err.println(e1);
        }

    }

    @Test
    public void test(){
        //installApk("Smiles_Ramadan_UAT.apk");
        //uninstallApk("ae.etisalat.smiles");

        //installApk("app-Sit-release.apk");
        uninstallApk("com.Etisalat.ETIDA");

        //installApk("app-debug.apk");
        //uninstallApk("com.indy");
    }
}
