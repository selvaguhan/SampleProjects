package com.example.etisalat.myapplication.com.etisalat.myetisalat.menuloginlogout;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.LoginPage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class TC_040LogoutTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    LoginPage loginPage;


    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_040LogoutTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        loginPage=PageFactory.initElements(driver,LoginPage.class);


        //driver.scrollToExact("Etisalat Automation");
        waitForElement(homePage.profileCoverId);
        homePage.profileCoverId.click();

        String profileName = navigationScreen.profileUsrName.getText();
        System.out.println("the profile name is::===>"+profileName);

        waitForElement(loginPage.logoutBtn);
        loginPage.logOut();

        waitForElement(loginPage.logoutOkBtn);
        loginPage.logOutOkBtn();

/*
        waitForElement(loginPage.userNameTxt);
        loginPage.userNameTxt.isDisplayed();
*/


    }

    @After
    public void tearDwon(){
        driver.quit();
    }
}
