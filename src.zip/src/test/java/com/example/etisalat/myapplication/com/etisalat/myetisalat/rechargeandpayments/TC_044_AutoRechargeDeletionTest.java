package com.example.etisalat.myapplication.com.etisalat.myetisalat.rechargeandpayments;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class TC_044_AutoRechargeDeletionTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;


    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void tc_043_AutoRechargeSubscriptionTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.rechargeAndPayTab);
        navigationScreen.clickOnRechargeAndPayTab();

        waitForElement(navigationScreen.autoRechargeTab);
        navigationScreen.clickOnAutoRechargeTab();

        waitForElement(navigationScreen.seeDetailsAndEditBtn);
        navigationScreen.clickOnSeeDetailsAndEditBtn();

        waitForElement(navigationScreen.deleteAutoPayBtn);
        navigationScreen.clickOnDeleteAutoPayBtn();

        waitForElement(myEtisalatAppPages.okBtn);
        myEtisalatAppPages.clickOnOkBtn();
    }

    // @After
    public void end() {
        driver.quit();
    }
}
