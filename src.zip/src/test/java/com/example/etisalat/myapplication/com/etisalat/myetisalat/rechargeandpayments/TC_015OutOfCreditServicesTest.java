package com.example.etisalat.myapplication.com.etisalat.myetisalat.rechargeandpayments;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;

public class TC_015OutOfCreditServicesTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_015OutOfCreditServicesTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(navigationScreen.rechargeAndPayTab);
        navigationScreen.clickOnRechargeAndPayTab();

        waitForElement(navigationScreen.outOfCreditServicesTab);
        navigationScreen.clickOnOutOfCreditServicesTab();

        waitForElement(navigationScreen.collectCall);
        navigationScreen.clickOnCollectCall();

        waitForElement(homePage.collectCallMobleNoTxt);
        homePage.ënterCollectCall("0543936194");

        waitForElement(homePage.callBtn);
        homePage.clickOnCallBtn();

        waitForElement(homePage.messagePopup);
        String mm = homePage.getMessagePopup();

        Assert.assertTrue(mm.contains("Thank you, the request is successful! We are contacting the number you provided you will get a call back if the person accepts."),"not matching");

        waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();
    }

    @After
    public void end() {
        driver.quit();
    }
}
