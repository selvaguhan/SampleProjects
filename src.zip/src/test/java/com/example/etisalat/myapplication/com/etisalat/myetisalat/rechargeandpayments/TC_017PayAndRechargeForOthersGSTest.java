package com.example.etisalat.myapplication.com.etisalat.myetisalat.rechargeandpayments;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.SoapApiUtils;
import com.example.etisalat.myapplication.com.etisalat.baseutils.XMLParser;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;

import javax.xml.soap.SOAPMessage;

import io.appium.java_client.android.AndroidKeyCode;

// for this postpaid
public class TC_017PayAndRechargeForOthersGSTest extends BaseTest{
    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    SoapApiUtils ss;
    XMLParser xmlParser;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void tc_017PayAndRechargeForOthersGSTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages = PageFactory.initElements(driver,MyEtisalatAppPages.class);
        ss = new SoapApiUtils();
        xmlParser=new XMLParser();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        String accountBalPreRecharge=null,accountBalPostRecharge=null;
        try{
            SOAPMessage soapRequest=ss.createSOAPRequest("C:\\Users\\jekumar\\Desktop\\wsdl\\IN\\test12.xml");
            SOAPMessage response=ss.getSOAPResponse(soapRequest,"http://tibcononprd.etisalat.corp.ae:9061/GetINAccountDetails");
            accountBalPreRecharge=xmlParser.getTagValue(response,"ns0:AccountBalance");
            System.out.println("the account balance is ::"+accountBalPreRecharge);
        }catch (Exception e){

        }

        waitForElement(navigationScreen.billsAndPaymentsTab);
        navigationScreen.billsAndPaymentsTab.click();

        waitForElement(navigationScreen.payAndRechargeForOthersTab);
        navigationScreen.clickOnPayAndRechargeForOthersTab();

        waitForElement(myEtisalatAppPages.localMoblieNumberTxt);
        myEtisalatAppPages.enterLocalMobileNumber("0543931693");

        driver.pressKeyCode(AndroidKeyCode.ENTER);

        waitForElement(homePage.nextBtn2);
        homePage.clickOnNextBtn2();

        waitForElement(myEtisalatAppPages.aed10);
        //myEtisalatAppPages.enterTransferAmount("10");
        myEtisalatAppPages.clickOnAed10Tab();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        myEtisalatAppPages.clickOnAed10Tab();

        waitForElement(homePage.nextBtn2);
        homePage.clickOnNextBtn2();

       if(homePage.payWithLastUsedCard.isDisplayed()) {

           waitForElement(homePage.lastUsedCheckBox);
           homePage.clickOnlastUsedCheckBox();

           waitForElement(homePage.nextBtn);
           homePage.clickOnNextBtn();

           waitForElement(homePage.okBtn);
           homePage.clickOnOkBtn();

           waitForElement(homePage.cvvTxt);
           homePage.enterCVVNo("123");

       }else{
           waitForElement(homePage.payWithNewCardCheckBox);
           homePage.clickOnPayWithNewCardCheckBox();

           waitForElement(homePage.nextBtn);
           homePage.clickOnNextBtn();

           waitForElement(homePage.okBtn);
           homePage.clickOnOkBtn();

           waitForElement(homePage.cardNumberTxt);
           homePage.enterCardNumber("4085650049569462");

           waitForElement(homePage.viewDropDownExpiryYear);
           homePage.clickOnViewExpiryYearDropDown();

           waitForElement(homePage.expiryYear);
           homePage.clickOnExpiryYear();

           waitForElement(homePage.cvvTxt);
           homePage.enterCVVNo("123");

       }

        waitForElement(homePage.payBtn);
        homePage.clickOnPayBtn();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

       waitForElement(myEtisalatAppPages.successTitle);
       String mm = myEtisalatAppPages.successTitle.getText();

        System.out.println("the retrived payme message is:::===>"+mm);
        Assert.assertEquals(mm,"Thank you");


        try{
            Thread.sleep(5000);
        }catch (Exception e){

        }

/*        waitForElement(homePage.okBtn);
         homePage.clickOnOkBtn();
        waitForElement(myEtisalatAppPages.dataTab);*/

        try{
            SOAPMessage soapRequest=ss.createSOAPRequest("C:\\Users\\jekumar\\Desktop\\wsdl\\IN\\test12.xml");
            SOAPMessage response=ss.getSOAPResponse(soapRequest,"http://tibcononprd.etisalat.corp.ae:9061/GetINAccountDetails");
            accountBalPostRecharge=xmlParser.getTagValue(response,"ns0:AccountBalance");
            System.out.println("the account balance is ::"+accountBalPostRecharge);
        }catch (Exception e){

        }

        double finalAddedBalance = Double.parseDouble(accountBalPreRecharge)+10;



        Assert.assertEquals(Double.toString(finalAddedBalance),accountBalPostRecharge);



    }

    @After
    public void end() {
        driver.quit();
    }
}
