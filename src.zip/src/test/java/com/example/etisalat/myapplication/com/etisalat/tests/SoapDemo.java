package com.example.etisalat.myapplication.com.etisalat.tests;

import com.example.etisalat.myapplication.com.etisalat.baseutils.SoapApiUtils;
import com.example.etisalat.myapplication.com.etisalat.baseutils.XMLParser;

import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import javax.xml.soap.SOAPMessage;

public class SoapDemo {

    SoapApiUtils ss;
    XMLParser xmlParser;
    @Test
    public void soapDemo(){
        ss = new SoapApiUtils();
        xmlParser=new XMLParser();
       try{

           SOAPMessage soapRequest=ss.createSOAPRequest("C:\\Users\\jekumar\\Desktop\\wsdl\\IN\\test12.xml");
           SOAPMessage response=ss.getSOAPResponse(soapRequest,"http://tibcononprd.etisalat.corp.ae:9061/GetINAccountDetails");
           String accountBal=xmlParser.getTagValue(response,"ns0:AccountBalance");
           System.out.println("the account balance is ::"+accountBal);
       }catch (Exception e){

       }
    }
}
