package com.example.etisalat.myapplication.com.etisalat.myetisalat.helpandsupport;

import com.example.etisalat.myapplication.com.etisalat.baseutils.AppInstallAndUninstallTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.PageFactory;
import java.net.MalformedURLException;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class LiveChatTest extends BaseTest {

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    AppInstallAndUninstallTest mmm;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void liveChatTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        mmm = new AppInstallAndUninstallTest();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        driver.swipe(489,1566,0,0,3000);

        //waitForElement(navigationScreen.helpAndSupportTab);
        navigationScreen.clickOnHelpAndSupportTab();

        waitForElement(myEtisalatAppPages.liveChatTab);
        myEtisalatAppPages.clickOnLiveChatTab();

        waitForElement(myEtisalatAppPages.howCanHelpYou);
        String liveMsg = myEtisalatAppPages.validateTheLiveChatMessage();
        System.out.println("the retrived latest calls balance from the application::"+liveMsg);
        Assert.assertEquals("text is not matching","How can we help you?",liveMsg);

        waitForElement(myEtisalatAppPages.questionTxt);
        String mm=myEtisalatAppPages.validateAskQuestion();
        System.out.println("the retrived text from the application::"+mm);
        Assert.assertEquals("text is not matching","Type your question here",mm);
/*
        waitForElement(myEtisalatAppPages.sendBtn);
        myEtisalatAppPages.clickOnSendBtn();

        waitForElement(myEtisalatAppPages.welcomeToLiveChat);
        String msg = myEtisalatAppPages.validateLiveChatScreen();
        System.out.println("the retrived latest calls balance from the application::"+msg);
        Assert.assertEquals("text is not matching","Etisalat: Welcome to Etisalat",msg);*/



    }

    @After
    public void tearDwon(){
        driver.quit();
    }
}
