package com.example.etisalat.myapplication.com.etisalat.tests;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.SwypPages;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

public class CreateAccountSwypTest extends BaseTest{

    SwypPages swypPages;

    @Before
    public  void setUp(){
        launchSwypApplication();
    }

    @Test
    public void test(){

        swypPages = PageFactory.initElements(driver,SwypPages.class);

        waitForElement(swypPages.getSIMBtn);
        swypPages.getSIMBtn.click();

        /*waitForElement(swypPages.continueSignUpBtn);
        swypPages.continueSignUpBtn.click();*/

        waitForElement(swypPages.fullNameTxt);
        swypPages.fullNameTxt.sendKeys("Moin Ulla Khan");
        driver.hideKeyboard();

        waitForElement(swypPages.emailIdTxt);
        swypPages.emailIdTxt.sendKeys("jekumar@etisalat.ae");
        driver.hideKeyboard();

        waitForElement(swypPages.nextBtn);
        swypPages.nextBtn.click();

        waitForElement(swypPages.daySpinDropDownBtn);
        swypPages.daySpinDropDownBtn.click();

        waitForElement(swypPages.yearPicker);
        swypPages.yearPicker.click();

        //waitForElement(swypPages.selectYear);
        try {
            Thread.sleep(3000);
        }catch (Exception e){
            System.out.println("The exception caught::"+e);
        }
        driver.scrollTo("1992");
        swypPages.selectYear.click();

        waitForElement(swypPages.nextMonthBtn);
        swypPages.nextMonthBtn.click();

        waitForElement(swypPages.dayDate);
        swypPages.dayDate.click();

        waitForElement(swypPages.dialogOkBtn);
        swypPages.dialogOkBtn.click();

        waitForElement(swypPages.nextBtn);
        swypPages.nextBtn.click();

        waitForElement(swypPages.acceptBtn);
        swypPages.acceptBtn.click();

        waitForElement(swypPages.confirmBtn);
        swypPages.confirmBtn.click();

       /* waitForElement(swypPages.searchNumberBtn);
        swypPages.searchNumberBtn.click();

        waitForElement(swypPages.mobileNoTxt);
        swypPages.mobileNoTxt.click();
        swypPages.mobileNoTxt.sendKeys("6200258");
        driver.hideKeyboard();

        try {
            Thread.sleep(6000);
        }catch (Exception e){
            System.out.println("The exception caught::"+e);
        }*/

        waitForElement(swypPages.numberIDTextView);
        String selectedNumber = swypPages.numberIDTextView.getText();
        System.out.println("the number from the list we have retrived::==>"+selectedNumber);

        String areCode = selectedNumber.substring(0,3);
        System.out.println("the area code spilted::==>"+areCode);

        String phoneNumber = selectedNumber.substring(3,10);
        System.out.println("the phone number splited::==>"+phoneNumber);

        swypPages.numberIDTextView.click();

        waitForElement(swypPages.nextBtn);
        swypPages.nextBtn.click();

        waitForElement(swypPages.usrNmeTxt);
        swypPages.usrNmeTxt.sendKeys("0541324321");

        waitForElement(swypPages.selectCitySpinner);
        swypPages.selectCitySpinner.click();
        driver.scrollTo("Dubai");
        swypPages.selectCity.click();

        waitForElement(swypPages.enterAreaNameTxt);
        swypPages.enterAreaNameTxt.sendKeys("Jafiliya");
        driver.hideKeyboard();

        waitForElement(swypPages.nextBtn1);
        swypPages.nextBtn1.click();

        waitForElement(swypPages.mapAddressTxt);
        swypPages.mapAddressTxt.sendKeys("Jafiliya");
        driver.hideKeyboard();

        waitForElement(swypPages.nextBtn);
        swypPages.nextBtn.click();

        waitForElement(swypPages.eidCode1Txt);
        swypPages.eidCode1Txt.sendKeys("784");

        waitForElement(swypPages.eidCode2Txt);
        swypPages.eidCode2Txt.sendKeys("1992");

        waitForElement(swypPages.eidCode3Txt);
        swypPages.eidCode3Txt.sendKeys("5839706");

        waitForElement(swypPages.eidCode4Txt);
        swypPages.eidCode4Txt.sendKeys("8");

        waitForElement(swypPages.verifyBtn);
        swypPages.verifyBtn.click();

        waitForElement(swypPages.swipeOut);
        driver.swipe(170,1809,902,54,30);

        waitForElement(swypPages.cashOnDeliveryRadioBtn);
        swypPages.cashOnDeliveryRadioBtn.click();

        waitForElement(swypPages.nextBtn);
        swypPages.nextBtn.click();

    }
}
