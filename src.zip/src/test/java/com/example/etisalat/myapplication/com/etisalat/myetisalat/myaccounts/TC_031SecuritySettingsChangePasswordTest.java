package com.example.etisalat.myapplication.com.etisalat.myetisalat.myaccounts;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class TC_031SecuritySettingsChangePasswordTest extends BaseTest{
    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;


    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_031SecuritySettingsChangePasswordTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);

        waitForElement(homePage.profileCoverId);
        homePage.profileCoverId.click();

        String profileName = navigationScreen.profileUsrName.getText();
        System.out.println("the profile name is::===>"+profileName);

        driver.scrollToExact("Security Settings");
        waitForElement(navigationScreen.securitySettingsTab);
        navigationScreen.clickOnSecuritySettingsTab();


        waitForElement(myEtisalatAppPages.changePasswordTab);
        myEtisalatAppPages.clickOnChangePasswordTab();

        try{
            Thread.sleep(5000);
        }catch (Exception e){

        }

        waitForElement(myEtisalatAppPages.currentPasswordTxt);
        myEtisalatAppPages.enterCurrentPassword("123456");

        try{
            Thread.sleep(5000);
        }catch (Exception e){

        }

        waitForElement(myEtisalatAppPages.newPasswordTxt);
        myEtisalatAppPages.enterNewPassword("654321");
        driver.hideKeyboard();

        try{
            Thread.sleep(5000);
        }catch (Exception e){

        }

        waitForElement(myEtisalatAppPages.confirmPasswordTxt);
        myEtisalatAppPages.enterConfirmPassword("654321");
        driver.hideKeyboard();

        waitForElement(myEtisalatAppPages.submitBtn);
        myEtisalatAppPages.submitBtn.click();

    }

    @After
    public void tearDwon(){
        driver.quit();
    }

}
