package com.example.etisalat.myapplication.com.etisalat.myetisalat.sharedCreditsAndData;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.DBUtils;
import com.example.etisalat.myapplication.com.etisalat.baseutils.SoapApiUtils;
import com.example.etisalat.myapplication.com.etisalat.baseutils.XMLParser;
import com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs.AutoConfigs;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.sql.ResultSet;
import java.util.ArrayList;

import javax.xml.soap.SOAPMessage;

public class DataTransferTest extends BaseTest {

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    SoapApiUtils ss;
    XMLParser xmlParser;
    DBUtils dbUtils;

    @Before
    public void setUp(){
        launchAndroidApplication();
    }

    @Test
    public void dataTransferTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        ss = new SoapApiUtils();
        xmlParser=new XMLParser();
        dbUtils = new DBUtils();


        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        String fromAccountBalPreDataTransfer=null,fromAccountBalPostDataTransfer=null;
        String toAccountBalPreDataTransfer=null,toAccountBalPostDataTransfer=null;

       /* try{
            SOAPMessage soapRequest=ss.createSOAPRequest("C:\\Users\\jekumar\\Desktop\\wsdl\\IN\\test12.xml");
            SOAPMessage response=ss.getSOAPResponse(soapRequest,"http://tibcononprd.etisalat.corp.ae:9061/GetINAccountDetails");
            fromAccountBalPreDataTransfer=xmlParser.getTagValue(response,"ns0:AccountBalance");
            System.out.println("the account balance is ::"+fromAccountBalPreDataTransfer);

            SOAPMessage soapRequest1=ss.createSOAPRequest("C:\\Users\\jekumar\\Desktop\\wsdl\\IN\\test13.xml");
            SOAPMessage response1=ss.getSOAPResponse(soapRequest1,"http://tibcononprd.etisalat.corp.ae:9061/GetINAccountDetails");
            toAccountBalPreDataTransfer=xmlParser.getTagValue(response1,"ns0:AccountBalance");
            System.out.println("the account balance is ::"+toAccountBalPreDataTransfer);

        }catch (Exception e){

        }*/

        waitForElement(navigationScreen.shareCreditAndDataTab);
        navigationScreen.clickOnShareCreditAndDataTab();

        waitForElement(myEtisalatAppPages.dataTransferTab);
        myEtisalatAppPages.clickOnDataTransferTab();

        waitForElement(myEtisalatAppPages.recipientMobNumberTxt);
        myEtisalatAppPages.enterRecipientPhoneNumber("0543931916");

        driver.swipe(100,500,0,0,30);

        waitForElement(myEtisalatAppPages.mb100Data);
        myEtisalatAppPages.clickOn100MbData();

        waitForElement(homePage.nextBtn);
        homePage.clickOnNextBtn();

        waitForElement(homePage.okBtn);
        homePage.clickOnOkBtn();

        waitForElement(myEtisalatAppPages.securityScreen);
        String securityCode =myEtisalatAppPages.getSecurityCode();

        System.out.println("the security code screen is:::===>"+securityCode);
        Assert.assertTrue(securityCode.contains("security code"));

        ArrayList<String> colAtrri= new ArrayList<String>();
        colAtrri.add("otp");

        ResultSet rs = dbUtils.fetchDataFromDataBase(AutoConfigs.databaseDigital,AutoConfigs.dbUATENV, "select  otp  from OTP order by created_date desc");

        ArrayList<String> otp = dbUtils.iterateFirstRowResultSetWithMultiColumAttribute(rs,colAtrri);


        System.out.println("the latest opt ::"+otp);

        myEtisalatAppPages.securityTxt.sendKeys(otp.get(0));

        driver.swipe(100,500,0,0,30);

        myEtisalatAppPages.proceedBtn.click();

        waitForElement(myEtisalatAppPages.successTitle);
        String text = myEtisalatAppPages.successTitle.getText();

        Assert.assertEquals("Thank you",text);

        waitForElement(myEtisalatAppPages.deductedBalanceAmount);
        String deductedbal = myEtisalatAppPages.deductedBalanceAmount.getText();
        System.out.println("the deducted balance is ::"+deductedbal);


        /*//vadating against to the IN Web Application
        try{
            SOAPMessage soapRequest=ss.createSOAPRequest("C:\\Users\\jekumar\\Desktop\\wsdl\\IN\\test12.xml");
            SOAPMessage response=ss.getSOAPResponse(soapRequest,"http://tibcononprd.etisalat.corp.ae:9061/GetINAccountDetails");
            fromAccountBalPostDataTransfer=xmlParser.getTagValue(response,"ns0:AccountBalance");
            System.out.println("the account balance is ::"+fromAccountBalPostDataTransfer);

            SOAPMessage soapRequest1=ss.createSOAPRequest("C:\\Users\\jekumar\\Desktop\\wsdl\\IN\\test13.xml");
            SOAPMessage response1=ss.getSOAPResponse(soapRequest1,"http://tibcononprd.etisalat.corp.ae:9061/GetINAccountDetails");
            toAccountBalPostDataTransfer=xmlParser.getTagValue(response1,"ns0:AccountBalance");
            System.out.println("the account balance is ::"+toAccountBalPostDataTransfer);
        }catch (Exception e){

        }

        int finalAddedBalanceFromAccount = Integer.parseInt(fromAccountBalPostDataTransfer)-50;//exact amount need to update
        org.testng.Assert.assertEquals(Integer.toString(finalAddedBalanceFromAccount),fromAccountBalPostDataTransfer);

        int finalAddedBalanceToAccount = Integer.parseInt(toAccountBalPostDataTransfer)+50;//exact amount need to update
        org.testng.Assert.assertEquals(Integer.toString(finalAddedBalanceToAccount),toAccountBalPostDataTransfer);*/
    }
}
