package com.example.etisalat.myapplication.com.etisalat.tests;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.LoginPage;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;

import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;


public class LoginTest1 extends BaseTest {

    HomePage homePage;
    NavigationScreen navigationScreen;
    LoginPage loginPage;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void loginTest(){
        homePage = PageFactory.initElements(driver,HomePage.class);
        loginPage = PageFactory.initElements(driver,LoginPage.class);
        loginPage.login("venkat","123456");
        driver.hideKeyboard();
        //driver.scrollTo("LOGIN");
        loginPage.loginBtn.click();

        waitForElement(loginPage.notNowBtn);
        loginPage.notNowBtn.click();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(By.xpath("//android.widget.TextView[@text='Bills and Payments']"));
        driver.findElement(By.xpath("//android.widget.TextView[@text='Bills and Payments']")).click();

        waitForElement(By.xpath("//android.widget.TextView[@text='View and Pay Bills']"));
        driver.findElement(By.xpath("//android.widget.TextView[@text='View and Pay Bills']")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/cb_postpaid"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/cb_postpaid")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/btn_recahrgeSelect_next"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/btn_recahrgeSelect_next")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/tv_price"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_price")).clear();
        driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_price")).sendKeys("10.00");

        waitForElement(By.id("com.Etisalat.ETIDA:id/btn_recahrgeSelect_next"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/btn_recahrgeSelect_next")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/cb_reward_points"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/cb_reward_points")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/tv_next"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_next")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/payButton"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/payButton")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/okButton"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/okButton")).click();

        waitForElement(homePage.paymentHeadingTitle);
        String payMentText =homePage.paymentHeadingTitle.getText();

        System.out.println("the retrived payment message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"PAYMENT SUCCESSFUL");

        //waitForElement(By.id("com.Etisalat.ETIDA:id/btn_upgrade_ok"));
        /*driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("
                + "new UiSelector().textContains(\"OK\"));"));*/
        driver.scrollTo("OK");
        driver.findElement(By.xpath("//android.widget.Button[@text='OK']")).click();

        /*TouchAction touchAction = new TouchAction(driver);
        touchAction.tap(driver.findElement(By.xpath("//android.widget.Button[@text='OK']"))).perform();*/

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(loginPage.myAccountsTab);
        driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("
                + "new UiSelector().textContains(\"My Accounts\"));"));

        waitForElement(loginPage.myAccountsTab);
        loginPage.myAccountsTab.click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/tv_ma_name"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_ma_name")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/btn_logout"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/btn_logout")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/tv_logout_ok"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_logout_ok")).click();

    }

    /*@After
    public void end() {
         driver.quit();
    }*/
}
