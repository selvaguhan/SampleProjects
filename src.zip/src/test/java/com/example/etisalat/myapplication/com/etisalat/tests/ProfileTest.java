package com.example.etisalat.myapplication.com.etisalat.tests;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class ProfileTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void profileTest() {

        homePage = PageFactory.initElements(driver, HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);

        waitForElement(homePage.profileImageTab);
        homePage.clickOnProfileImage();

        waitForElement(navigationScreen.myInfoLnk);
        navigationScreen.clickOnMyInfoLnk();

        String profileName = navigationScreen.profileUsrName.getText();
        System.out.println("the profile name is::===>"+profileName);

        Assert.assertEquals("venkat",profileName);
    }
}
