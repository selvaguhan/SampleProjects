package com.example.etisalat.myapplication.com.etisalat.myetisalat.myaccounts;

import com.example.etisalat.myapplication.com.etisalat.baseutils.AppInstallAndUninstallTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.DBUtils;
import com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs.AutoConfigs;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;
import java.sql.ResultSet;
import java.util.ArrayList;

public class TC_041_SetupPINTest extends BaseTest {

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    AppInstallAndUninstallTest mmm;
    DBUtils dbUtils;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_041_SetupPINTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        mmm = new AppInstallAndUninstallTest();
        dbUtils = new DBUtils();

       /* waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();*/

        waitForElement(homePage.profileCoverId);
        homePage.profileCoverId.click();

        driver.scrollToExact("Account settings");
        waitForElement(navigationScreen.accountSettings);
        navigationScreen.accountSettings.click();

        waitForElement(navigationScreen.digit4Pin);
        navigationScreen.digit4Pin.click();

       /* if(navigationScreen.digit4PinTxt.getText().equalsIgnoreCase("Existing 4 Digit PIN")){
            try{
                dbUtils.executeQuerryWithPreparedSt(AutoConfigs.dbPDENV,AutoConfigs.delete_T_SOH_CHNNL_PIN_REGISTRATION(AutoConfigs.pdProductNumber));
            }catch (Exception e){
                System.out.println("the exception is ::"+e);
            }

        }
*/

        waitForElement(navigationScreen.digit4PinTxt);
        navigationScreen.digit4PinTxt.sendKeys("1234");

        try{
            Thread.sleep(5000);
        }catch (Exception e){

        }
        waitForElement(navigationScreen.continueBtn);
        navigationScreen.continueBtn.click();

        try{
            Thread.sleep(5000);
        }catch (Exception e){

        }

        waitForElement(navigationScreen.digit4PinTxt);
        navigationScreen.digit4PinTxt.sendKeys("1234");

        try{
            Thread.sleep(5000);
        }catch (Exception e){

        }

        waitForElement(navigationScreen.continueBtn);
        navigationScreen.continueBtn.click();

        waitForElement(homePage.okBtn);
        homePage.okBtn.click();

        waitForElement(homePage.digitPinSuccess);
        String successTitle = homePage.digitPinSuccess.getText().trim().toString();

        Assert.assertEquals("4 DIGIT PIN CREATED SUCCESSFULLY",successTitle);

        try{
            Thread.sleep(60000);
        }catch (Exception e){

        }

        ArrayList<String> attributesList = new ArrayList<String>();
        attributesList.add("new_pin_number");
        attributesList.add("old_pin_number");

        ResultSet rs1 = dbUtils.fetchDataFromDataBase("cbcm",AutoConfigs.dbUATENV, "select * from T_SOH_CHNNL_PIN_REGISTRATION t where t.account_number=971543935128");
        ArrayList<String> resultList = dbUtils.iterateFirstRowResultSetWithMultiColumAttribute(rs1,attributesList);
        System.out.println("the whole result set ::"+resultList);

        String newPin=resultList.get(0);
        System.out.println("the new pin::"+newPin);
        org.testng.Assert.assertEquals(newPin,"1234");

        String oldPin=resultList.get(1);
        System.out.println("the old pin ::"+oldPin);
        org.testng.Assert.assertEquals(oldPin,"1234");


    }

    @After
    public void tearDwon(){
        driver.quit();
    }
}
