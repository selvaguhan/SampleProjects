package com.example.etisalat.myapplication.com.etisalat.myetisalat.myaccounts;

import com.example.etisalat.myapplication.com.etisalat.baseutils.AppInstallAndUninstallTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.DBUtils;
import com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs.AutoConfigs;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;
import java.sql.ResultSet;
import java.util.ArrayList;

public class TC_042_ChangePINTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    AppInstallAndUninstallTest mmm;
    DBUtils dbUtils;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_042_ChangePINTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        mmm = new AppInstallAndUninstallTest();
        dbUtils = new DBUtils();

        waitForElement(homePage.profileCoverId);
        homePage.profileCoverId.click();

        String profileName = navigationScreen.profileUsrName.getText();
        System.out.println("the profile name is::===>"+profileName);

        waitForElement(navigationScreen.accountSettingsTab);
        navigationScreen.clickOnAccountSettingsTab();


        waitForElement(myEtisalatAppPages.digitPin4);
        myEtisalatAppPages.clickOn4DigitPin();

        waitForElement(myEtisalatAppPages.existing4DigitPinTxt);
        myEtisalatAppPages.enterExisting4DigitPin("1234");

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        waitForElement(myEtisalatAppPages.continueBtn);
        myEtisalatAppPages.clickOnContinueBtn();

        waitForElement(myEtisalatAppPages.newPinTxt);
        myEtisalatAppPages.enterNewPin("4321");

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        waitForElement(myEtisalatAppPages.changeBtn);
        myEtisalatAppPages.clickOnChangeBtn();

        waitForElement(myEtisalatAppPages.okBtn);
        myEtisalatAppPages.clickOnOkBtn();

        waitForElement(myEtisalatAppPages.pinChangedSuccessfully);
        String mm=myEtisalatAppPages.getPinChangeSuccessfullyMsg();

        Assert.assertEquals("text is not matching","4 DIGIT PIN CHANGED SUCCESSFULLY",mm);

        waitForElement(myEtisalatAppPages.btnOk_btn);
        myEtisalatAppPages.clickOnBtnOk();
        //waitForElement(myEtisalatAppPages.dataTab);

        try{
            Thread.sleep(60000);
        }catch (Exception e){

        }

        ArrayList<String> attributesList = new ArrayList<String>();
        attributesList.add("new_pin_number");
        attributesList.add("old_pin_number");

        ResultSet rs1 = dbUtils.fetchDataFromDataBase("cbcm", AutoConfigs.dbUATENV, "select * from T_SOH_CHNNL_PIN_REGISTRATION t where t.account_number=971543935128");
        ArrayList<String> resultList = dbUtils.iterateFirstRowResultSetWithMultiColumAttribute(rs1,attributesList);
        System.out.println("the whole result set ::"+resultList);

        String newPin=resultList.get(0);
        System.out.println("the new pin::"+newPin);
        org.testng.Assert.assertEquals(newPin,"1234");

        String oldPin=resultList.get(1);
        System.out.println("the old pin ::"+oldPin);
        org.testng.Assert.assertEquals(oldPin,"1234");

    }

    //@After
    public void tearDwon(){
        driver.quit();
    }
}
