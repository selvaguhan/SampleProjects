package com.example.etisalat.myapplication.com.etisalat.tests;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.DBUtils;
import com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs.AutoConfigs;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DBDemo extends BaseTest{
    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    DBUtils dbUtils;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void dBDemo() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages = PageFactory.initElements(driver,MyEtisalatAppPages.class);
        dbUtils = new DBUtils();


        ArrayList<String> colAtrri= new ArrayList<String>();
        colAtrri.add("subrequest_id");



        ResultSet rs = dbUtils.fetchDataFromDataBase("CBCM",AutoConfigs.dbUATENV, "select subrequest_id,created_date from t_soh_subrequest where area_code='054' and product_number='3936849'  order by created_date desc");

        ArrayList<String> otp = dbUtils.iterateFirstRowResultSetWithMultiColumAttribute(rs,colAtrri);


        System.out.println("the latest opt ::"+otp);

    }
}
