package com.example.etisalat.myapplication.com.etisalat.tests;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;


public class MyEtisalatDemoTest extends BaseTest{

    @BeforeTest
    public void setUp()  {
        launchAndroidApplication();
    }

    @org.testng.annotations.Test
    public void testMyEtisalatDemoTest() {

        waitForElement(By.id("com.Etisalat.ETIDA:id/menu_toggle"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/menu_toggle")).click();

        waitForElement(By.xpath("//android.widget.TextView[@text='Bills and Payments']"));
        driver.findElement(By.xpath("//android.widget.TextView[@text='Bills and Payments']")).click();

        waitForElement(By.xpath("//android.widget.TextView[@text='View and Pay Bills']"));
        driver.findElement(By.xpath("//android.widget.TextView[@text='View and Pay Bills']")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/cb_postpaid"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/cb_postpaid")).click();

        waitForElement(By.xpath("//android.widget.TextView[@text='Pay selected']"));
        driver.findElement(By.xpath("//android.widget.TextView[@text='Pay selected']")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/tv_price"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_price")).clear();
        driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_price")).sendKeys("10.00");

        waitForElement(By.id("com.Etisalat.ETIDA:id/btn_recahrgeSelect_next"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/btn_recahrgeSelect_next")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/cb_lct_last_used_checkbox"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/cb_lct_last_used_checkbox")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/tv_next"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_next")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/okButton"));
        driver.findElement(By.id("com.Etisalat.ETIDA:id/okButton")).click();

        waitForElement(By.xpath("//android.widget.EditText[@resource-id='ValidationCode']"));
        driver.findElement(By.xpath("//android.widget.EditText[@resource-id='ValidationCode']")).sendKeys("123");

        waitForElement(By.xpath("//android.widget.Button[@content-desc = 'Pay']"));
        driver.findElement(By.xpath("//android.widget.Button[@content-desc = 'Pay']")).click();

        waitForElement(By.id("com.Etisalat.ETIDA:id/tv_payment_heading"));
        String payMentText =driver.findElement(By.id("com.Etisalat.ETIDA:id/tv_payment_heading")).getText();

        System.out.println("the retrived payme message is:::===>"+payMentText);
        Assert.assertEquals(payMentText,"PAYMENT SUCCESSFUL");
    }

    @AfterTest
    public void end() {
        driver.quit();
    }
}
