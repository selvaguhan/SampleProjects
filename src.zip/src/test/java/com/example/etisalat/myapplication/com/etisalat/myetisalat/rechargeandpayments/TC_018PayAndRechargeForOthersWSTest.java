package com.example.etisalat.myapplication.com.etisalat.myetisalat.rechargeandpayments;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.DBUtils;
import com.example.etisalat.myapplication.com.etisalat.baseutils.SoapApiUtils;
import com.example.etisalat.myapplication.com.etisalat.baseutils.XMLParser;
import com.example.etisalat.myapplication.com.etisalat.myetisalat.autoconfigs.AutoConfigs;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.net.MalformedURLException;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.xml.soap.SOAPMessage;

import io.appium.java_client.android.AndroidKeyCode;

// prepaid with deduct it from balance

public class TC_018PayAndRechargeForOthersWSTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    SoapApiUtils ss;
    DBUtils dbUtils;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void tc_018PayAndRechargeForOthersWSTest() {

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages = PageFactory.initElements(driver,MyEtisalatAppPages.class);
        ss = new SoapApiUtils();
        dbUtils = new DBUtils();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();


        waitForElement(navigationScreen.rechargeAndPayTab);
        navigationScreen.clickOnRechargeAndPayTab();

        waitForElement(navigationScreen.payAndRechargeForOthersTab);
        navigationScreen.clickOnPayAndRechargeForOthersTab();

        waitForElement(myEtisalatAppPages.localMoblieNumberTxt);
        myEtisalatAppPages.enterLocalMobileNumber("0543936701");

        driver.pressKeyCode(AndroidKeyCode.ENTER);

        waitForElement(homePage.nextBtn2);
        homePage.clickOnNextBtn2();

        waitForElement(myEtisalatAppPages.aed50);
        myEtisalatAppPages.clickOnAed50Tab();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        myEtisalatAppPages.clickOnAed50Tab();

        waitForElement(homePage.nextBtn2);
        homePage.clickOnNextBtn2();

        if(homePage.payWithLastUsedCard.isDisplayed()) {

            waitForElement(homePage.lastUsedCheckBox);
            homePage.clickOnlastUsedCheckBox();

            waitForElement(homePage.nextBtn);
            homePage.clickOnNextBtn();

            waitForElement(homePage.okBtn);
            homePage.clickOnOkBtn();

            waitForElement(homePage.cvvTxt);
            homePage.enterCVVNo("123");

        }else{
            waitForElement(homePage.payWithNewCardCheckBox);
            homePage.clickOnPayWithNewCardCheckBox();

            waitForElement(homePage.nextBtn);
            homePage.clickOnNextBtn();

            waitForElement(homePage.okBtn);
            homePage.clickOnOkBtn();

            waitForElement(homePage.cardNumberTxt);//4085650049569462
            homePage.enterCardNumber("4085650049729462");//4085650049729462

            waitForElement(homePage.viewDropDownExpiryYear);
            homePage.clickOnViewExpiryYearDropDown();

            waitForElement(homePage.expiryYear);
            homePage.clickOnExpiryYear();

            waitForElement(homePage.cvvTxt);
            homePage.enterCVVNo("123");

        }

        waitForElement(homePage.payBtn);
        homePage.clickOnPayBtn();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        waitForElement(myEtisalatAppPages.successTitle);
        String mm = myEtisalatAppPages.successTitle.getText();

        System.out.println("the retrived payme message is:::===>"+mm);
        Assert.assertEquals(mm,"Thank you");

        ArrayList<String> attributesList = AutoConfigs.getListOfAttributesToFetchDetails();

        ResultSet rs = dbUtils.fetchDataFromCBCMDB(AutoConfigs.dbUATENV, AutoConfigs.get_T_PAY_DTL_PAYMENT_TRANSACTION(AutoConfigs.uatAccoutNumber));
        ArrayList<String> resultList = dbUtils.iterateFirstRowResultSetWithMultiColumAttribute(rs,attributesList);
        System.out.println("the whole result set ::"+resultList);




    }
    @After
    public void end() {
        driver.quit();
    }
}
