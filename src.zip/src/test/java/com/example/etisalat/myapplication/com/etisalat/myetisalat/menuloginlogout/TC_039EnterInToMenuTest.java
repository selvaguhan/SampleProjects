package com.example.etisalat.myapplication.com.etisalat.myetisalat.menuloginlogout;

import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class TC_039EnterInToMenuTest extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;


    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();
    }

    @Test
    public void tc_039EnterInToMenuTest(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);


        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        waitForElement(myEtisalatAppPages.homeTab);
        String home=myEtisalatAppPages.getHomeTab();

        Assert.assertEquals("text is not matching","Home",home);

    }

    @After
    public void tearDwon(){
        driver.quit();
    }



}
