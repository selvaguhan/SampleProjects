package com.example.etisalat.myapplication.com.etisalat.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class SwypPages {


    @FindBy(id = "com.indy:id/skipBtnText")
    @CacheLookup
    public WebElement skipBtn;

    @FindBy(id = "com.indy:id/agree_btn")
    @CacheLookup
    public WebElement agreeBtn;


    @FindBy(id = "com.indy:id/loginBtn")
    @CacheLookup
    public WebElement loginBtn;

    @FindBy(id = "com.indy:id/mobileNo")
    @CacheLookup
    public WebElement usrNmeTxt;

    @FindBy(id = "com.indy:id/password")
    @CacheLookup
    public WebElement passwordTxt;

    @FindBy(id = "com.indy:id/createAccoutBtn")
    @CacheLookup
    public WebElement createAccountBtn;


    @FindBy(id = "com.indy:id/mobileNo")
    @CacheLookup
    public WebElement mobileNoTxt;

    @FindBy(id = "com.indy:id/continueBtn")
    @CacheLookup
    public WebElement continueBtn;

    @FindBy(id = "com.indy:id/yesBtn")
    @CacheLookup
    public WebElement yesBtn;

//////creating new account web elements

    //Get SIM
    @FindBy(id = "com.indy:id/buynow")
    @CacheLookup
    public WebElement getSIMBtn;

    @FindBy(id = "com.indy:id/continueSignUpId")
    @CacheLookup
    public WebElement continueSignUpBtn;

    @FindBy(id = "com.indy:id/fullName")
    @CacheLookup
    public WebElement fullNameTxt;

    @FindBy(id = "com.indy:id/email")
    @CacheLookup
    public WebElement emailIdTxt;

    //Next
    @FindBy(id = "com.indy:id/nextBtn")
    @CacheLookup
    public WebElement nextBtn;

    @FindBy(id = "com.indy:id/daySpin")
    @CacheLookup
    public WebElement daySpinDropDownBtn;

    @FindBy(id = "android:id/date_picker_header_year")
    @CacheLookup
    public WebElement yearPicker;

    @FindBy(xpath = "//android.widget.TextView[@text='1992']")
    public WebElement selectYear;

    @FindBy(id = "android:id/prev")
    @CacheLookup
    public WebElement prevMonthBtn;

    @FindBy(id = "android:id/next")
    @CacheLookup
    public WebElement nextMonthBtn;


    @FindBy(xpath = "//android.view.View[@text='8']")
    public WebElement dayDate;

    @FindBy(id = "com.indy:id/dialogButtonOK")
    @CacheLookup
    public WebElement dialogOkBtn;

    //Accept
    @FindBy(id = "com.indy:id/acceptId")
    @CacheLookup
    public WebElement acceptBtn;

    //Confirm
    @FindBy(id = "com.indy:id/confirmBtn")
    @CacheLookup
    public WebElement confirmBtn;


    @FindBy(id = "com.indy:id/iv_search_number")
    @CacheLookup
    public WebElement searchNumberBtn;

    @FindBy(id = "com.indy:id/numberID")
    @CacheLookup
    public WebElement numberIDTextView;


    @FindBy(id = "com.indy:id/selectCitySpinner")
    @CacheLookup
    public WebElement selectCitySpinner;

    @FindBy(xpath = "//android.widget.CheckedTextView[@text='Dubai']")
    public WebElement selectCity;


    @FindBy(id = "com.indy:id/enterareaID")
    public WebElement enterAreaNameTxt;

    @FindBy(id = "com.indy:id/continueId")
    public WebElement nextBtn1;

    @FindBy(id = "com.indy:id/addressID")
    public WebElement mapAddressTxt;

    @FindBy(id = "com.indy:id/code_1")
    public WebElement eidCode1Txt;

    @FindBy(id = "com.indy:id/code_2")
    public WebElement eidCode2Txt;

    @FindBy(id = "com.indy:id/code_3")
    public WebElement eidCode3Txt;

    @FindBy(id = "com.indy:id/code_4")
    public WebElement eidCode4Txt;

    @FindBy(id = "com.indy:id/verfyBtn")
    public WebElement verifyBtn;

    @FindBy(id = "com.indy:id/myseek")
    public WebElement swipeOut;

    @FindBy(id = "com.indy:id/freeBtn")
    public WebElement cashOnDeliveryRadioBtn;
























}
