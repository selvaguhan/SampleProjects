package com.example.etisalat.myapplication.com.etisalat.baseutils;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;

public class BaseTest {

    Dimension size;
    public AndroidDriver driver;

    public AndroidDriver launchAndroidApplication() {

        //unInstall();

        try{
            // Created object of DesiredCapabilities class.
            DesiredCapabilities capabilities = new DesiredCapabilities();
            // Set android deviceName desired capability. Set it Android Emulator.
            //capabilities.setCapability("deviceName", "68466b20");//68466b20
            //capabilities.setCapability("deviceName", "19d7d534");
            capabilities.setCapability("deviceName", "LRT8CEVOWO7S59YL");

            // Set browserName desired capability. It's Android in our case here.
            capabilities.setCapability("browserName", "Android");
            // Set android platformVersion desired capability. Set your emulator's android version.
            capabilities.setCapability("platformVersion", "5.1");
            // Set android platformName desired capability. It's Android in our case here.
            capabilities.setCapability("platformName", "Android");

           /*capabilities.setCapability("unicodeKeyboard","false");
            capabilities.setCapability("resetKeyboard","false");*/

            // Set your application's appPackage if you are using any other app.
            capabilities.setCapability("appPackage", "com.Etisalat.ETIDA");
            // Set your application's appPackage if you are using any other app.

            //capabilities.setCapability("appActivity", "com.Etisalat.ETIDA.authentication.activities.LoginActivity");
            capabilities.setCapability("appActivity", "com.Etisalat.ETIDA.home.activities.SplashActivity");
            // Created object of RemoteWebDriver will all set capabilities.
            // Set appium server address and port number in URL string.
            // It will launch calculator app in android device.
            //driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
            driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        }catch (Exception e){
            System.out.println("the android driver unable to launch::==>"+e);
        }
        return  driver;

    }

    public AndroidDriver launchSwypApplication() {

        try{
            // Created object of DesiredCapabilities class.
            DesiredCapabilities capabilities = new DesiredCapabilities();
            // Set android deviceName desired capability. Set it Android Emulator.
            //capabilities.setCapability("deviceName", "68466b20");
            capabilities.setCapability("deviceName", "19d7d534");
            //capabilities.setCapability("deviceName", "MJWOWWINVKNNNVNJ");

            // Set browserName desired capability. It's Android in our case here.
            capabilities.setCapability("browserName", "Android");
            // Set android platformVersion desired capability. Set your emulator's android version.
            capabilities.setCapability("platformVersion", "P");
            // Set android platformName desired capability. It's Android in our case here.
            capabilities.setCapability("platformName", "Android");
            // Set your application's appPackage if you are using any other app.
            capabilities.setCapability("appPackage", "com.indy");
            // Set your application's appPackage if you are using any other app.
            capabilities.setCapability("appActivity", "com.indy.views.activites.SplashActivity");
            // Created object of RemoteWebDriver will all set capabilities.
            // Set appium server address and port number in URL string.
            // It will launch calculator app in android device.
            //driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
            driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        }catch (Exception e){
            System.out.println("the android driver unable to launch::==>"+e);
        }
        return  driver;

    }

    public void waitForElement(By by){
        try{
            WebDriverWait wait = new WebDriverWait(driver, 20);
            wait.until(ExpectedConditions.elementToBeClickable(by));
        }catch (Exception e){
            System.out.println("the element not able load::"+e);
        }

    }

    public void waitForElement(WebElement by){
        try{
            WebDriverWait wait = new WebDriverWait(driver, 60);
            wait.until(ExpectedConditions.elementToBeClickable(by));
        }catch (Exception e){
            System.out.println("the element not able load::"+e);
        }

    }

    public void waitForElement1(WebElement by){
        try{
            WebDriverWait wait = new WebDriverWait(driver, 90);
            wait.until(ExpectedConditions.elementToBeClickable(by));
        }catch (Exception e){
            System.out.println("the element not able load::"+e);
        }

    }

    public void waitForElement(WebDriver driver,By by){
        try{
            WebDriverWait wait = new WebDriverWait(driver, 60);
            wait.until(ExpectedConditions.elementToBeClickable(by));
        }catch (Exception e){
            System.out.println("the element not able load::"+e);
        }

    }

    public Boolean isElementPresent(String xpathExp){

       try
        {
            driver.findElement(By.xpath(xpathExp));
            //If element is found set the timeout back and return true
            driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
            return true;
        }
        catch (NoSuchElementException e)
        {
             return false;
        }
    }

    public void horizontalScroll()
    {
        size=driver.manage().window().getSize();
        int x_start=(int)(size.width*0.60);
        int x_end=(int)(size.width*0.30);
        int y=130;
        driver.swipe(x_start,y,x_end,y,4000);
    }


    public void scrollTo(String selector) {
        String selectorString = String.format("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView("+ selector +")");
        //driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains("+selector+").instance(0))");

        driver.findElement(MobileBy.AndroidUIAutomator(selectorString));
    }

    public void scrollAndClick(String visibleText) {
        driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""+visibleText+"\").instance(0))").click();
    }

    public String executeCommand(String cmd)
    {
        String commandresponse="";
        try
        {
            Runtime run = Runtime.getRuntime();
            Process proc=run.exec(cmd);
            BufferedReader stdInput = new BufferedReader(new
                    InputStreamReader(proc.getInputStream()));

            BufferedReader stdError = new BufferedReader(new
                    InputStreamReader(proc.getErrorStream()));

            String response=null;
            while ((response = stdInput.readLine()) != null)
            {
                if(response.length()>0)
                {
                    commandresponse=commandresponse+response;
                }
            }

            while ((response = stdError.readLine()) != null)
            {
                commandresponse=commandresponse+response;

            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        //System.out.println(commandresponse);
        return commandresponse;
    }

    public void unInstall(){
        String cmd = "adb shell getprop ro.build.version.release";

        String osVersion=executeCommand(cmd);

        if(osVersion.contains("7.0"))
        {
            //uninstall io.appium.settings
            cmd="adb uninstall  io.appium.settings";
            executeCommand(cmd);

            //uninstall io.appium.unlock
            cmd="adb uninstall  io.appium.unlock";
            executeCommand(cmd);

        }
    }

    public void scrollIntoViewTillElement(WebElement element) {
        ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", element);
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            System.out.println("unable to scoll element into view:==>"+e);
            e.printStackTrace();
        }
    }

    public String getCurrentDate(){

        LocalDate localDate = LocalDate.now();
        String date = DateTimeFormatter.ofPattern("yyy/MM/dd").format(localDate);
        System.out.println(date);
        String [] dat = date.split("/");
        String datefrmt = dat[0]+"-"+dat[1]+"-"+dat[2];
        System.out.println("the framed date is ::"+datefrmt);
        return datefrmt;

    }

    public void clickOnSearchBtn(){
        TouchAction touch1 = new TouchAction(driver);
        touch1.tap (980 , 1854).perform();
    }


}




