package com.example.etisalat.myapplication.com.etisalat.myetisalat.helpandsupport;

import com.example.etisalat.myapplication.com.etisalat.baseutils.AppInstallAndUninstallTest;
import com.example.etisalat.myapplication.com.etisalat.baseutils.BaseTest;
import com.example.etisalat.myapplication.com.etisalat.pages.HomePage;
import com.example.etisalat.myapplication.com.etisalat.pages.MyEtisalatAppPages;
import com.example.etisalat.myapplication.com.etisalat.pages.NavigationScreen;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.support.PageFactory;

import java.net.MalformedURLException;

public class TC_037OtherEtisalatApps extends BaseTest{

    HomePage homePage;
    NavigationScreen navigationScreen;
    MyEtisalatAppPages myEtisalatAppPages;
    AppInstallAndUninstallTest mmm;

    @Before
    public void setUp() throws MalformedURLException {
        launchAndroidApplication();

    }

    @Test
    public void tc_037OtherEtisalatApps(){

        homePage = PageFactory.initElements(driver,HomePage.class);
        navigationScreen= PageFactory.initElements(driver,NavigationScreen.class);
        myEtisalatAppPages=PageFactory.initElements(driver,MyEtisalatAppPages.class);
        mmm = new AppInstallAndUninstallTest();

        waitForElement(homePage.menuToggleElement);
        homePage.menuToggleTab();

        try{
            Thread.sleep(2000);
        }catch (Exception e){

        }

        driver.swipe(500,1500,30,0,2000);

        //waitForElement(navigationScreen.helpAndSupportTab);
        navigationScreen.clickOnHelpAndSupportTab();

        waitForElement(myEtisalatAppPages.otherEtisalatAppTab);
        myEtisalatAppPages.clickOnOtherEtisalatAppTab();

        waitForElement(myEtisalatAppPages.uaeRegionTab);
        myEtisalatAppPages.clickOnUAERegionTab();


        waitForElement(myEtisalatAppPages.uaeRegionApp);
        String uaeRegionApp = myEtisalatAppPages.validateUAERegionApp();
        System.out.println("the retrieved  roaming email id  from the application::"+uaeRegionApp);
        Assert.assertEquals("text is not matching","Smiles by Etisalat",uaeRegionApp);

        //navigating back to country list.
        myEtisalatAppPages.clickOnNavigateBack();
        waitForElement(myEtisalatAppPages.saudiArabiaTab);
        myEtisalatAppPages.clickOnsaudiArabiaTab();

        waitForElement(myEtisalatAppPages.saudiArabiaApp);
        String saudiArabiaApp = myEtisalatAppPages.validateSaudiArabiaApp();
        System.out.println("the retrieved  roaming email id  from the application::"+saudiArabiaApp);
        Assert.assertEquals("text is not matching","Diabetes Test",saudiArabiaApp);

        //navigating back to country list.
        myEtisalatAppPages.clickOnNavigateBack();
        waitForElement(myEtisalatAppPages.egyptTab);
        myEtisalatAppPages.clickOnEgyptTab();

        waitForElement(myEtisalatAppPages.egyptApp);
        String egyptApp = myEtisalatAppPages.validateEgyptApp();
        System.out.println("the retrieved  egypt from the country list::"+egyptApp);
        Assert.assertEquals("text is not matching","EasyMobile App",egyptApp);

        //navigating back to country list.
        myEtisalatAppPages.clickOnNavigateBack();
        waitForElement(myEtisalatAppPages.pakistanTab);
        myEtisalatAppPages.clickOnPakistanTab();

        waitForElement(myEtisalatAppPages.pakistanApp);
        String pakistanApp = myEtisalatAppPages.validatePakistanApp();
        System.out.println("the retrieved  pakistan  from the application::"+pakistanApp);
        Assert.assertEquals("text is not matching","TouchPTCL",pakistanApp);

        //navigating back to country list.
        myEtisalatAppPages.clickOnNavigateBack();
        waitForElement(myEtisalatAppPages.sriLankaTab);
        myEtisalatAppPages.clickOnSriLankaTab();

        waitForElement(myEtisalatAppPages.sriLankaApp);
        String sriLankaApp = myEtisalatAppPages.validateSriLankaApp();
        System.out.println("the retrieved  Sri Lanka  from the application::"+sriLankaApp);
        Assert.assertEquals("text is not matching","Etisalat GlobalTalk",sriLankaApp);
    }

    @After
    public void tearDwon(){
        driver.quit();
    }
}
